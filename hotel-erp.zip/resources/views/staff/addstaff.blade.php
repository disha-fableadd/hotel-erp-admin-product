@extends('layout.app')

@section('title', 'Add Staff')

@section('content')
<style>
    @media screen and (max-width: 768px) {
        .form-group {
            margin-bottom: 10px !important
        }
    }

    @media screen and (max-width: 375px) {
        .permission_class {
            font-size: 12px !important;
            font-weight: bold;
        }
    }
    @media screen and (max-width: 360px) {
        .permission_class {
            font-size: 11px !important;
            font-weight: bold;
        }
    }
    @media screen and (max-width: 344px) {
        .permission_class {
            font-size: 10px !important;
            font-weight: bold;
        }
    }
</style>
<div class="content">
    <div class="page-header">
        <div class="page-title">
            <h4>Add Staff</h4>

        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="customerForm" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <!-- Customer Name -->
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="form-group">
                            <label>Staff Name</label>
                            <input type="text" name="customer_name" id="customer_name" class="form-control">
                            <div class="text-danger error-customer_name"></div>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" id="email" class="form-control" autocomplete="off">
                            <div class="text-danger error-email"></div>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" id="password" class="form-control" autocomplete="off">
                            <div class="text-danger error-password"></div>
                        </div>
                    </div>

                    <!-- Roles -->
                    <!-- <div class="col-lg-3 col-sm-6 col-6">
                            <div class="form-group">
                                <label>Role</label>
                                <select name="role" id="role" class="form-control">
                                    <option value="" disabled selected>Select Role</option>
                                    <option value="sales-manager">Sales Manager</option>
                                    <option value="purchase-manager">Purchase Manager</option>
                                    <option value="inventory-manager">Inventory Manager</option>
                                </select>
                                <div class="text-danger error-role"></div>
                            </div>
                        </div> -->

                    <!-- Phone -->
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="text" name="phone" id="phone" class="form-control">
                            <div class="text-danger error-phone"></div>
                        </div>
                    </div>

                    <!-- Country -->
                    <div class="col-lg-3 col-sm-6 col-12">
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" name="country" id="country" class="form-control">
                            <div class="text-danger error-country"></div>
                        </div>
                    </div>

                    <!-- City -->
                    <div class="col-lg-3 col-sm-6 col-12">
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" name="city" id="city" class="form-control">
                            <div class="text-danger error-city"></div>
                        </div>
                    </div>

                    <!-- PAN Number -->
                    <div class="col-lg-3 col-sm-6 col-12">
                        <div class="form-group">
                            <label>PAN Number</label>
                            <input type="text" name="pan_number" id="pan_number" class="form-control">
                            <span class="text-danger error-pan_number"></span>
                        </div>
                    </div>

                    <!-- GST Number -->
                    <div class="col-lg-3 col-sm-6 col-12">
                        <div class="form-group">
                            <label>GST Number</label>
                            <input type="text" name="gst_number" id="gst_number" class="form-control">
                            <span class="text-danger error-gst_number"></span>
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="col-lg-6 col-12">
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" id="address" class="form-control"></textarea>
                            <div class="text-danger error-address"></div>
                        </div>
                    </div>

                    <!-- Avatar Upload -->
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Photo</label>
                            <div class="image-upload">
                                <input type="file" name="avatar" id="avatar" class="form-control">
                                <div class="image-uploads">
                                    <img src="{{ env('ImagePath') . '/admin/assets/img/icons/upload.svg' }}"
                                        alt="Upload Icon">
                                    <h4>Drag and drop a file to upload</h4>
                                </div>
                            </div>
                            <div class="text-danger error-avatar"></div>

                            <!-- Avatar Preview -->
                            <div id="avatar-preview-container" style="display: none; margin-top: 10px;">
                                <img id="avatar-preview" src="" alt="Avatar Preview"
                                    style="max-width: 150px; border-radius: 8px;">
                            </div>
                        </div>
                    </div>

                    <!-- Submit & Cancel Buttons -->
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-submit me-2">Submit</button>
                        <a href="{{ route('staff.list') }}" class="btn btn-cancel">Cancel</a>
                    </div>
                </div>
                <hr>
                <div class="text-danger error-permissions mt-2"></div>

                <div class="d-flex align-items-center mt-4">
                    <h5 class="fw-bold mb-0 me-3">PERMISSION:</h5>

                    <div class="form-check form-check-inline mb-0 permission_class">
                        <input class="form-check-input" type="radio" name="permission_type" id="withPermission"
                            value="1">
                        <label class="form-check-label" for="withPermission">With Permission</label>
                    </div>

                    <div class="form-check form-check-inline mb-0 permission_class">
                        <input class="form-check-input" type="radio" name="permission_type" id="withoutPermission"
                            value="0">
                        <label class="form-check-label" for="withoutPermission">Without Permission</label>
                    </div>
                </div>

                <!-- Permissions Section -->
                <div id="permissionsSection" style="display:none; margin-top:15px;">
                    <div class="form-group mb-3">
                        <label class="fw-normal">
                            <input type="checkbox" id="select_all_module"> Select All Module
                        </label>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle">
                            <thead class="table-light">
                                <tr class="text-center">
                                    <th class="text-start">Module Name</th>
                                    <th>View</th>
                                    <th>Insert</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                    <th>All</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($modules as $module)
                                @if($module->module !== 'Staff')
                                <tr>
                                    <td class="align-middle">
                                        <i class="fa fa-folder-open text-primary me-2"></i> {{ $module->module }}
                                        <input type="hidden" name="modules[{{ $module->id }}][module_id]"
                                            value="{{ $module->id }}">
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="modules[{{ $module->id }}][view]"
                                            class="permission-checkbox form-check-input">
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="modules[{{ $module->id }}][add]"
                                            class="permission-checkbox form-check-input">
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="modules[{{ $module->id }}][edit]"
                                            class="permission-checkbox form-check-input">
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="modules[{{ $module->id }}][delete]"
                                            class="permission-checkbox form-check-input">
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" class="check-all-row form-check-input">
                                    </td>
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </form>
        </div>
    </div>



</div>
@endsection

@push('js')
<script>
    $(document).ready(function() {
        $('input[name="permission_type"]').on('change', function() {
            if ($('#withPermission').is(':checked')) {
                $('#permissionsSection').slideDown();
            } else {
                $('#permissionsSection').slideUp();
                // Optional: uncheck all checkboxes when hiding
                $('#permissionsSection').find('input[type="checkbox"]').prop('checked', false);
            }
        });
    });
    $(document).ready(function() {
        var authToken = localStorage.getItem("authToken");

        // Handle form submission
        $("#customerForm").submit(function(e) {
            e.preventDefault();

            let formData = new FormData(this);
            $(".text-danger").html(""); // clear previous errors
            $(".error-permissions").html("");

            let hasError = false;

            // ✅ Permission check
            if (!$('input[name="permission_type"]:checked').length) {
                $(".error-permissions").html("** Please select With or Without Permission. **");
                hasError = true;
            }

            // ✅ Staff Name validation
            let customer_name = $("#customer_name").val().trim();
            if (customer_name === "") {
                $(".error-customer_name").html(" Staff name is required. ");
                hasError = true;
            } else if (customer_name.length < 3) {
                $(".error-customer_name").html(" Staff name must be at least 3 characters. ");
                hasError = true;
            }

            // ✅ Email validation
            let email = $("#email").val().trim();
            let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email === "") {
                $(".error-email").html(" Email is required. ");
                hasError = true;
            } else if (!emailPattern.test(email)) {
                $(".error-email").html(" Please enter a valid email address. ");
                hasError = true;
            }

            // ✅ Password validation
            let password = $("#password").val().trim();
            if (password === "") {
                $(".error-password").html(" Password is required. ");
                hasError = true;
            } else if (password.length < 6) {
                $(".error-password").html(" Password must be at least 6 characters. ");
                hasError = true;
            }

            // ✅ Phone validation
            let phone = $("#phone").val().trim();
            let phonePattern = /^[0-9]{10}$/; // only 10-digit numbers
            if (phone === "") {
                $(".error-phone").html(" Phone number is required. ");
                hasError = true;
            } else if (!phonePattern.test(phone)) {
                $(".error-phone").html(" Please enter a valid 10-digit phone number. ");
                hasError = true;
            }

            // Stop form submission if errors exist
            if (hasError) {
                return false;
            }

            const $btn = $("#submitCustomerBtn");
            const originalText = $btn.html();

            // Show spinner and disable button
            $btn.html('<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Saving...')
                .prop("disabled", true);

            if ($('#withPermission').is(':checked')) {
                let permissionSelected = $('.permission-checkbox:checked').length > 0;

                if (!permissionSelected) {
                    $(".error-permissions").html("** Please select at least one permission. **");
                    $btn.html(originalText).prop("disabled", false);
                    return false;
                } else {
                    $(".error-permissions").html("");
                }
            } else {
                // If "Without Permission" is selected, clear error
                $(".error-permissions").html("");
            }

            const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
            if (selectedSubAdminId) {
                formData.append("sub_admin_id", selectedSubAdminId);
            }
            $.ajax({
                url: "/api/createStaff", // Ensure API route is correct
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                    "Authorization": "Bearer " + authToken,
                },
                success: function(response) {
                    $btn.html(originalText).prop("disabled", false); // Restore button
                    if (response.status) {
                        Swal.fire({
                            title: "Success!",
                            text: "Staff added successfully!",
                            icon: "success",
                            confirmButtonText: "OK",
                            confirmButtonColor: "#ff9f43",
                        }).then(() => {
                            window.location.href = "/staff";
                        });
                    }
                },
                error: function(xhr) {
                    $btn.html(originalText).prop("disabled", false); // Restore button
                    if (xhr.status === 422) {
                        let errors = xhr.responseJSON.errors;
                        $.each(errors, function(key, value) {
                            $(".error-" + key).html(value[0]); // Show error below each field
                        });
                    } else {
                        Swal.fire({
                            title: "Error!",
                            text: "Something went wrong. Please try again.",
                            icon: "error",
                            confirmButtonText: "OK"
                        });
                    }
                },
            });
        });

        // Remove error message when user starts typing
        // $("input, select").on("input", function() {
        //     let fieldName = $(this).attr("name");
        //     $(".error-" + fieldName).html("");
        // });

        // // Handle File Input Change (Live Preview)
        // $("#avatar").change(function(event) {
        //     let reader = new FileReader();
        //     reader.onload = function(e) {
        //         $("#avatar-preview").attr("src", e.target.result);
        //         $("#avatar-preview-container").show();
        //     };
        //     reader.readAsDataURL(event.target.files[0]);
        // });

        // $('.permission-checkbox, .check-all-row, #select_all_module').prop('checked', true);

        // // Row-level "All"
        // $('.check-all-row').on('change', function() {
        //     let row = $(this).closest('tr');
        //     row.find('.permission-checkbox').prop('checked', $(this).is(':checked'));
        // });

        // // Global "Select All"
        // $('#select_all_module').on('change', function() {
        //     let checked = $(this).is(':checked');
        //     $('.permission-checkbox, .check-all-row').prop('checked', checked);
        // });
    });
</script>
<script>
    $(document).ready(function() {
        // When 'Select All Module' is clicked
        $('#select_all_module').on('change', function() {
            const isChecked = $(this).is(':checked');
            $('.permission-checkbox, .check-all-row').prop('checked', isChecked);
        });

        // When 'All' checkbox in each row is clicked
        $('.check-all-row').on('change', function() {
            const isChecked = $(this).is(':checked');
            const row = $(this).closest('tr');
            row.find('.permission-checkbox').prop('checked', isChecked);
        });

        // If any permission checkbox is changed manually, update the 'All' checkbox in that row
        $('.permission-checkbox').on('change', function() {
            const row = $(this).closest('tr');
            const allChecked = row.find('.permission-checkbox').length === row.find(
                '.permission-checkbox:checked').length;
            row.find('.check-all-row').prop('checked', allChecked);
        });

        // Sync master checkbox if all checkboxes are checked or unchecked
        function syncSelectAllModule() {
            const totalPermissions = $('.permission-checkbox').length;
            const totalChecked = $('.permission-checkbox:checked').length;
            $('#select_all_module').prop('checked', totalPermissions === totalChecked);
        }

        // Call sync function when any permission checkbox is changed
        $('.permission-checkbox, .check-all-row').on('change', syncSelectAllModule);
    });
</script>
@endpush