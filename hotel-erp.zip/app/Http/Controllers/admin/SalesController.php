<?php

namespace App\Http\Controllers\admin;

use App\Models\Table_no;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\PaymentStore;
use App\Models\TaxRate;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\QuantityType;
use App\Models\Setting;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SalesController extends Controller
{

    public function sales_list(Request $request)
    {
        $selectedSubAdminId = (session('selectedSubAdminId'));

        $years = Order::where('isDeleted', 0)
            ->selectRaw('YEAR(created_at) as year')
            ->distinct()
            ->orderByDesc('year')
            ->pluck('year');

        return view('sales/saleslist', compact('years'));
    }

    public function add_sales(Request $request)
    {

        return view('sales/add-sales');
    }
    public function edit_sales($id)
    {
        $user = auth()->user();
        $subAdminId = session('selectedSubAdminId');

        // 🔹 Decide branch_id based on role
        if ($user->role === 'staff' && $user->branch_id) {
            $branchIdToUse = $user->branch_id;
        } elseif ($user->role === 'admin' && !empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } else {
            $branchIdToUse = $user->id;
        }

        // 🔹 Load sales record
        $sales = Order::with(['order_items.product', 'order_items.product.quantityType' => function ($q) {
            $q->select('*'); // ensures all fields
        }])->find($id);
        if (!$sales) {
            return redirect()->route('sales.list')->with('error', 'Sales record not found.');
        }

        $update_id = $id;

        // 🔹 Load related data
        $usernames = User::where('role', 'customer')
            ->where('branch_id', $branchIdToUse)
            ->where('isDeleted', 0)
            ->get();

        $category = Category::where('isDeleted', 0)
            ->where('branch_id', $branchIdToUse)
            ->get();

        $quantity_type = QuantityType::where('isDeleted', 0)
            ->where('created_by', $branchIdToUse)
            ->get();

        $TaxRate = TaxRate::where('status', 'active')->where('isDeleted', 0)
            ->where('branch_id', $branchIdToUse)
            ->get();

        $products = Product::where('status', 'active')
            ->where('availablility', 'in_stock')
            ->where('branch_id', $branchIdToUse)
            ->get();

        // 🔹 Create products array with quantity type information
        $productsArray = $products->map(function ($product) {
            return [
                'id' => $product->id,
                'name' => $product->name,
                'category_id' => $product->category_id,
                'price' => $product->price,
                'quantity_type_id' => $product->quantity_type_id, // Add this
            ];
        });
        // dd($sales);
        $setting = Setting::where('branch_id', $branchIdToUse)->first();

        return view('sales/edit-sales', compact('sales', 'TaxRate', 'category', 'quantity_type', 'usernames', 'products', 'update_id', 'setting', 'productsArray'));
    }
    // public function sales_details($id)
    // {
    //     $setting = Setting::first();

    //     $currencySymbol = $setting->currency_symbol ?? '₹';
    //     $currencyPosition = $setting->currency_position ?? 'left';

    //     $sales = Order::find($id);

    //     if (!$sales) {
    //         return redirect()->route('sales.list')->with('error', 'Order not found.');
    //     }

    //     $compenyinfo = Setting::all();

    //     $taxIds = json_decode($sales->tax_id, true);
    //     $taxes = TaxRate::whereIn('id', $taxIds)->get();

    //     $orderItems = OrderItem::where('order_id', $id)->get();
    //     $totalAmount = $orderItems->sum('total_amount');

    //     $view_id = $id; // define view_id for blade

    //     return view('sales/sales-details', compact(
    //         'view_id',
    //         'sales',
    //         'taxes',
    //         'totalAmount',
    //         'compenyinfo',
    //         'setting',
    //         'currencySymbol',
    //         'currencyPosition'
    //     ));
    // }

    // public function sales_details($id)
    // {

    //     $setting = Setting::first();

    //     $currencySymbol = $setting->currency_symbol ?? '₹';
    //     $currencyPosition = $setting->currency_position ?? 'left';

    //     $sales = Order::find($id);

    //     if (!$sales) {
    //         return redirect()->route('sales.list')->with('error', 'Order not found.');
    //     }

    //     $compenyinfo = Setting::all();

    //     $taxIds = json_decode($sales->tax_id, true) ?? [];
    //     $taxes = TaxRate::whereIn('id', $taxIds)->get();

    //     $orderItems = OrderItem::where('order_id', $id)->get();
    //     $totalAmount = $orderItems->sum('total_amount');

    //     $view_id = $id; // define view_id for blade

    //     // ✅ Fetch customer/user details and push into $sales
    //     $user = $sales->user_id ? User::with('userDetail')->find($sales->user_id) : null;

    //     if ($user) {
    //         $sales->customer_role       = ucfirst($user->role ?? 'Customer');
    //         $sales->customer_name       = $user->name ?? 'Walk-in Customer';
    //         $sales->customer_email      = $user->email ?? '';
    //         $sales->customer_phone      = $user->phone ?? '';
    //         $sales->customer_address    = optional($user->userDetail)->address ?? '';
    //         $sales->customer_city       = optional($user->userDetail)->city ?? '';
    //         $sales->customer_country    = optional($user->userDetail)->country ?? '';
    //         $sales->customer_gst_number = optional($user->userDetail)->gst_number ?? '';
    //         $sales->customer_pan_number = optional($user->userDetail)->pan_number ?? '';
    //     } else {
    //         // default values if no user is linked
    //         $sales->customer_role       = 'Customer';
    //         $sales->customer_name       = 'Walk-in Customer';
    //         $sales->customer_email      = '';
    //         $sales->customer_phone      = '';
    //         $sales->customer_address    = '';
    //         $sales->customer_city       = '';
    //         $sales->customer_country    = '';
    //         $sales->customer_gst_number = '';
    //         $sales->customer_pan_number = '';
    //     }

    //     // dd($sales);

    //     return view('sales/sales-details', compact(
    //         'view_id',
    //         'sales',
    //         'TaxRate',
    //         'category',
    //         'usernames',
    //         'products',
    //         'update_id',
    //         'setting'
    //     ));
    // }

    public function sales_details($id)
    {
        $user = auth()->user();
        $subAdminId = session('selectedSubAdminId');

        // 🔹 Decide branch_id based on role
        if ($user->role === 'staff' && $user->branch_id) {
            $branchIdToUse = $user->branch_id;
        } elseif ($user->role === 'admin' && !empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } else {
            $branchIdToUse = $user->id;
        }

        // 🔹 Get branch-specific setting
        $setting = Setting::where('branch_id', $branchIdToUse)->first();
        $currencySymbol = $setting->currency_symbol ?? '₹';
        $currencyPosition = $setting->currency_position ?? 'left';

        // 🔹 Load sales with order items + products
        $sales = Order::with(['order_items.product'])->find($id);

        if (!$sales) {
            return redirect()->route('sales.list')->with('error', 'Order not found.');
        }

        // 🔹 Company info (branch-specific setting)
        $compenyinfo = $setting;

        // 🔹 Get taxes (safely handle null/empty tax_id)
        $taxIds = !empty($sales->tax_id) ? json_decode($sales->tax_id, true) : [];
        $taxes = !empty($taxIds)
            ? TaxRate::where('branch_id', $branchIdToUse)
            ->whereIn('id', $taxIds)
            ->where('isDeleted', 0)
            ->get()
            : collect();

        // 🔹 Order items & totals
        $orderItems = OrderItem::where('order_id', $id)->get();
        $totalAmount = $orderItems->sum('total_amount');

        $view_id = $id; // define view_id for blade
        $user = $sales->user_id ? User::with('userDetail')->find($sales->user_id) : null;

        if ($user) {
            $sales->customer_role       = ucfirst($user->role ?? 'Customer');
            $sales->customer_name       = $user->name ?? 'Walk-in Customer';
            $sales->customer_email      = $user->email ?? '';
            $sales->customer_phone      = $user->phone ?? '';
            $sales->customer_address    = optional($user->userDetail)->address ?? '';
            $sales->customer_city       = optional($user->userDetail)->city ?? '';
            $sales->customer_country    = optional($user->userDetail)->country ?? '';
            $sales->customer_gst_number = optional($user->userDetail)->gst_number ?? '';
            $sales->customer_pan_number = optional($user->userDetail)->pan_number ?? '';
        } else {
            // default values if no user is linked
            $sales->customer_role       = 'Customer';
            $sales->customer_name       = 'Walk-in Customer';
            $sales->customer_email      = '';
            $sales->customer_phone      = '';
            $sales->customer_address    = '';
            $sales->customer_city       = '';
            $sales->customer_country    = '';
            $sales->customer_gst_number = '';
            $sales->customer_pan_number = '';
        }
        // ✅ Check if payment already started for this order
        $hasPaymentStarted = PaymentStore::where('order_id', $view_id)
            ->where('isDeleted', 0)
            ->exists();
        return view('sales.sales-details', compact(
            'view_id',
            'sales',
            'taxes',
            'totalAmount',
            'compenyinfo',
            'setting',
            'currencySymbol',
            'currencyPosition',
            'hasPaymentStarted'
        ));
    }

    public function salse_invoice($id)
    {
        $user = auth()->user();
        $subAdminId = session('selectedSubAdminId');

        // 🔹 Decide branch_id based on role
        if ($user->role === 'staff' && $user->branch_id) {
            $branchIdToUse = $user->branch_id;
        } elseif ($user->role === 'admin' && !empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } else {
            $branchIdToUse = $user->id;
        }
        $view_id = $id;
        $sales = Order::find($view_id);
        $setting = Setting::where('branch_id', $branchIdToUse)->first(); // Get currency info
        // dd($setting);
        if (!$sales) {
            return redirect()->route('sales.list')->with('error', 'Order not found.');
        }

        $taxIds = json_decode($sales->tax_id, true);
        $taxes = TaxRate::where('branch_id', $branchIdToUse)->whereIn('id', $taxIds)->where('isDeleted', 0)->get();
        $orderItems = OrderItem::where('order_id', $view_id)->get();
        $totalAmount = $orderItems->sum('total_amount');

        $user = $sales->user_id ? User::with('userDetail')->find($sales->user_id) : null;

        $userAddress = $user && $user->userDetail ? $user->userDetail->address : null;

        // ✅ Check if payment already started for this order
        $hasPaymentStarted = PaymentStore::where('order_id', $view_id)
            ->where('isDeleted', 0)
            ->exists();

        return view('sales/salse-invoice', compact('view_id', 'sales', 'taxes', 'totalAmount', 'setting', 'userAddress', 'hasPaymentStarted'));
    }

    // public function salse_invoice_pdf($id)
    // {
    //     $view_id = $id;
    //     $sales = Order::find($view_id);
    //     $setting = Setting::first();

    //     if (!$sales) {
    //         return redirect()->route('sales.list')->with('error', 'Order not found.');
    //     }

    //     // Fetch user data (assuming 'user_id' in orders table)
    //     $user = $sales->user_id ? User::find($sales->user_id) : null;

    //     // Helper function for currency formatting
    //     $formatCurrency = function ($amount) use ($setting) {
    //         $amount = number_format($amount, 2);
    //         return $setting->currency_position === 'right'
    //             ? $amount . $setting->currency_symbol
    //             : $setting->currency_symbol . $amount;
    //     };

    //     // Fetch tax rates
    //     $taxIds = json_decode($sales->tax_id, true) ?? [];
    //     $taxes = TaxRate::whereIn('id', $taxIds)->get();

    //     // Fetch order items
    //     $orderItems = OrderItem::where('order_id', $view_id)->get();

    //     // Subtotal
    //     $subtotal = $orderItems->sum('total_amount');

    //     // Discount
    //     $discountPercent = $sales->discount ?? 0;
    //     $discountAmount = ($discountPercent / 100) * $subtotal;
    //     $afterDiscount = $subtotal - $discountAmount;

    //     // Calculate tax amounts
    //     $taxDetails = [];
    //     foreach ($taxes as $tax) {
    //         $taxAmount = ($tax->tax_rate / 100) * $afterDiscount;
    //         $taxDetails[] = [
    //             'name' => $tax->tax_name,
    //             'rate' => $tax->tax_rate,
    //             'amount' => $taxAmount,
    //             'formatted_amount' => $formatCurrency($taxAmount)
    //         ];
    //     }

    //     // Final total
    //     $finalTotal = $afterDiscount + collect($taxDetails)->sum('amount');

    //     // Prepare formatted values
    //     $formattedSubtotal = $formatCurrency($subtotal);
    //     $formattedDiscountAmount = $formatCurrency($discountAmount);
    //     $formattedAfterDiscount = $formatCurrency($afterDiscount);
    //     $formattedFinalTotal = $formatCurrency($finalTotal);

    //     // Retrieve customer data (assuming $sales has a customer_id relationship)
    //     $customer = $sales->customer ? $sales->customer->toArray() : [
    //         'name' => 'walk-in-customer',
    //         'email' => '',
    //         'phone' => '',
    //         'address' => optional($user->userDetail)->address ?? '',
    //     ];

    //     // Prepare data for view, now also including user data
    //     $pdfData = [
    //         'view_id' => $view_id,
    //         'sales' => $sales,
    //         'setting' => $setting,
    //         'orderItems' => $orderItems,
    //         'salesItems' => $orderItems,
    //         'customer' => [
    //             'name'    => $user->name ?? 'walk-in-customer',
    //             'email'   => $user->email ?? '',
    //             'phone'   => $user->phone ?? '',
    //             'address' => optional($user->userDetail)->address ?? 'arga',
    //         ],
    //         'user' => $user ? $user->toArray() : null,  // include user data
    //         'subtotal' => $formattedSubtotal,
    //         'discountAmount' => $formattedDiscountAmount,
    //         'afterDiscount' => $formattedAfterDiscount,
    //         'finalTotal' => $formattedFinalTotal,
    //         'taxDetails' => $taxDetails
    //     ];

    //     // Load and render PDF
    //     $pdf = PDF::loadView('sales.salse-invoice-pdf', $pdfData);

    //     return $pdf->stream('invoice_' . $view_id . '.pdf');
    // }

    public function salse_invoice_pdf($id)
    {
        $view_id = $id;
        $sales = Order::find($view_id);
        $user = Auth::user();
        $subAdminId = session('selectedSubAdminId') ?? $user->id;

        if ($user->role === 'staff' && $user->branch_id) {
            $setting = Setting::where('branch_id', $user->branch_id)->first();
        } else {
            $setting = Setting::where('branch_id', $subAdminId)->first();
        }

        if (!$sales) {
            return redirect()->route('sales.list')->with('error', 'Order not found.');
        }

        // Fetch user data (assuming 'user_id' in orders table)
        $user = $sales->user_id ? User::find($sales->user_id) : null;

        // Helper function for currency formatting
        $formatCurrency = function ($amount) use ($setting) {
            $amount = number_format($amount, 2);
            return $setting->currency_position === 'right'
                ? $amount . $setting->currency_symbol
                : $setting->currency_symbol . $amount;
        };

        // ✅ Subtotal
        $orderItems = OrderItem::with('product', 'quantityType')->where('order_id', $view_id)->get();
        $subtotal = $orderItems->sum('total_amount');

        // ✅ Discount
        $discountPercent = $sales->discount ?? 0;
        $discountAmount = ($discountPercent / 100) * $subtotal;
        $afterDiscount = $subtotal - $discountAmount;

        // ✅ Tax calculation only if gst_option = 'with'
        $taxDetails = [];
        if ($sales->gst_option === 'with_gst') {
            $taxIds = json_decode($sales->tax_id, true) ?? [];
            if (!empty($taxIds)) {
                $taxes = TaxRate::whereIn('id', $taxIds)->get();
                foreach ($taxes as $tax) {
                    $taxAmount = ($tax->tax_rate / 100) * $afterDiscount;
                    $taxDetails[] = [
                        'name' => $tax->tax_name,
                        'rate' => $tax->tax_rate,
                        'amount' => $taxAmount,
                        'formatted_amount' => $formatCurrency($taxAmount)
                    ];
                }
            }
        }

        // ✅ Final total
        $finalTotal = $afterDiscount + collect($taxDetails)->sum('amount');

        // ✅ Prepare formatted values
        $formattedSubtotal = $formatCurrency($subtotal);
        $formattedDiscountAmount = $formatCurrency($discountAmount);
        $formattedAfterDiscount = $formatCurrency($afterDiscount);
        $formattedFinalTotal = $formatCurrency($finalTotal);

        // ✅ Retrieve customer data
        $customer = $sales->customer ? $sales->customer->toArray() : [
            'name' => 'walk-in-customer',
            'email' => '',
            'phone' => '',
            'address' => optional($user->userDetail)->address ?? '',
        ];
         $paidAmount = PaymentStore::where('order_id', $sales->id)
            ->where('isDeleted', 0)
            ->sum('payment_amount');

        // ✅ Pending amount (single source of truth)
        $pendingAmount = $sales->remaining_amount ?? 0;

        // ✅ Prepare data for view
        $pdfData = [
            'view_id' => $view_id,
            'sales' => $sales,
            'setting' => $setting,
            'orderItems' => $orderItems,
            'salesItems' => $orderItems,
            'customer' => [
                'name' => $user->name ?? 'walk-in-customer',
                'email' => $user->email ?? '',
                'phone' => $user->phone ?? '',
                'address' => optional($user->userDetail)->address ?? 'arga',
            ],
            'user' => $user ? $user->toArray() : null,
            'subtotal' => $formattedSubtotal,
            'discountPercent' => $discountPercent,
            'discountAmount' => $formattedDiscountAmount,
            'afterDiscount' => (float) $afterDiscount,              // numeric
            'formattedAfterDiscount' => $formattedAfterDiscount,    // formatted
            'finalTotal' => $formattedFinalTotal,
            'taxDetails1' => $taxDetails,
            'paidAmount'             => $paidAmount,
            'pendingAmount'          => $pendingAmount,
            
        ];

        // ✅ Load and render PDF
        $pdf = PDF::loadView('sales.salse-invoice-pdf', $pdfData);

        return $pdf->stream('invoice_' . $view_id . '.pdf');
    }





    public function sales_report(Request $request)
    {
        $user         = Auth()->user();
        $branchId     = $user->id ?? null;
        $UserBranchId = $user->branch_id ?? null;
        $userRole     = $user->role ?? '';
        $subAdminId   = session('selectedSubAdminId');

        // Decide branch based on role
        if ($userRole === 'sub-admin') {
            $branchIdToUse = $branchId;
        } elseif ($userRole === 'admin' && $subAdminId) {
            $branchIdToUse = $subAdminId;
        } elseif ($userRole === 'staff') {
            $branchIdToUse = $UserBranchId;
        } else {
            $branchIdToUse = $branchId;
        }

        // Fetch customer
        if ($userRole === 'staff') {
            // Only customer created by this staff
            $customers = User::where('role', 'customer')
                ->where('created_by', $user->id)
                ->where('isDeleted', 0)
                ->orderBy('name')
                ->get();
        } else {
            // Admin / sub-admin sees all customer in branch
            $customers = User::where('role', 'customer')
                ->where('branch_id', $branchIdToUse)
                ->where('isDeleted', 0)
                ->orderBy('name')
                ->get();
        }

        // ✅ Fetch categories based on branch
        if ($userRole === 'staff') {
            $categories = Category::where('isDeleted', 0)
                ->where('branch_id', $UserBranchId)
                ->orderBy('name')
                ->get();
        } else {
            $categories = Category::where('isDeleted', 0)
                ->where('branch_id', $branchIdToUse)
                ->orderBy('name')
                ->get();
        }

        return view('sales/salesreport', compact('customers', 'categories'));
    }

    public function pos()
    {
        $user = auth()->user();
        $userRole = $user->role ?? '';
        $userId = $user->id ?? null;
        $branchId = $user->branch_id ?? null;
        $subAdminId = session('selectedSubAdminId');

        // 🔹 Decide which branch_id to use
        if ($userRole === 'sub-admin' && $userId) {
            $branchIdToUse = $userId;
        } elseif ($userRole === 'admin' && !empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } elseif ($userRole === 'staff' && $branchId) {
            $branchIdToUse = $branchId;
        } else {
            $branchIdToUse = $userId;
        }

        // 🔹 Get settings
        $setting = Setting::where('branch_id', $branchIdToUse)->first();
        $currency_symbol = $setting->currency_symbol ?? '₹';
        $currency_position = $setting->currency_position ?? 'left';

        // 🔹 Common queries
        $categories = Category::where('isDeleted', 0)
            ->where('branch_id', $branchIdToUse)
            ->get();

        $quantityTypes = QuantityType::where('isDeleted', 0)
            ->where('created_by', $branchIdToUse)
            ->get();

        $taxRates = TaxRate::where('status', 'active')->where('isDeleted', 0)
            ->where('branch_id', $branchIdToUse)
            ->where('isDeleted', 0)
            ->get();

        // $customers = User::where('role', 'customer')
        //     ->where('branch_id', $branchIdToUse)
        //     ->where('isDeleted', 0)
        //     ->get();
        // 🔹 Customers: filter by created_by if staff
        $customers = Table_no::get();


        // $customers = $customersQuery->get();

        // 🔹 Vendors only for Staff or default case
        $vendors = collect(); // empty collection if not needed
        if ($userRole === 'staff' || $userRole === 'admin' || $userRole === 'sub-admin') {
            $vendors = User::where('role', 'vendor')
                ->where('branch_id', $branchIdToUse)
                ->where('isDeleted', 0)
                ->get();
        }

        // 🔹 Create products array with quantity type information
    $products = Product::where('status', 'active')
        ->where('availablility', 'in_stock')
        ->where('branch_id', $branchIdToUse)
        ->get();
    
    $productsArray = $products->map(function ($product) {
        return [
            'id' => $product->id,
            'name' => $product->name,
            'category_id' => $product->category_id,
            'price' => $product->price,
            'quantity_type_id' => $product->quantity_type_id,
        ];
    })->toArray();

        return view('sales.pos', compact(
            'categories',
            // 'quantityTypes',
            'taxRates',
            'customers',
            'vendors',
            'currency_symbol',
            'currency_position',
            'setting',
            'productsArray'
        ));
    }
    // public function sale_report($ids)
    // {
    //     $idsArray = explode(',', $ids);
    //     $sales = OrderItem::with('product.category', 'invoice')->whereIn('id', $idsArray)->get();

    //     if ($sales->isEmpty()) {
    //         return redirect()->back()->with('error', 'No purchase data found.');
    //     }

    //     // Get settings
    //     $settings = Setting::first();
    //     $currencySymbol = $settings->currency_symbol ?? '₹';
    //     $currencyPosition = $settings->currency_position ?? 'left';

    //     $subtotal = $sales->sum('total_amount');

    //     // Get tax rates
    //     $taxRates = TaxRate::where('status', 'active')->get();
    //     $discountPercent = 0;
    //     $discountAmount = 0;

    //     // Get discount
    //     foreach ($sales as $sale) {
    //         if ($sale->invoice) {
    //             $discountPercent = $sale->invoice->discount ?? 0;
    //             $discountAmount += ($sale->total_amount * $discountPercent) / 100;
    //         }
    //     }

    //     $subtotalAfterDiscount = $subtotal - $discountAmount;

    //     // Calculate tax on discounted amount
    //     $taxDetails = [];
    //     $totalTaxAmount = 0;
    //     foreach ($taxRates as $tax) {
    //         $amount = $subtotalAfterDiscount * ($tax->tax_rate / 100);
    //         $taxDetails[] = [
    //             'name' => $tax->tax_name,
    //             'rate' => $tax->tax_rate,
    //             'amount' => $amount,
    //             'formatted_amount' => $currencyPosition === 'left'
    //                 ? $currencySymbol . number_format($amount, 2)
    //                 : number_format($amount, 2) . $currencySymbol,
    //         ];
    //         $totalTaxAmount += $amount;
    //     }

    //     $totalAmount = $subtotalAfterDiscount + $totalTaxAmount;

    //     // Format monetary values
    //     $formattedSubtotal = $currencyPosition === 'left'
    //         ? $currencySymbol . number_format($subtotal, 2)
    //         : number_format($subtotal, 2) . $currencySymbol;

    //     $formattedDiscountAmount = $currencyPosition === 'left'
    //         ? $currencySymbol . number_format($discountAmount, 2)
    //         : number_format($discountAmount, 2) . $currencySymbol;

    //     $formattedTotalAmount = $currencyPosition === 'left'
    //         ? $currencySymbol . number_format($totalAmount, 2)
    //         : number_format($totalAmount, 2) . $currencySymbol;

    //     return view('sales.sale_report', compact(
    //         'sales',
    //         'settings',
    //         'subtotal',
    //         'formattedSubtotal',
    //         'taxDetails',
    //         'discountAmount',
    //         'formattedDiscountAmount',
    //         'discountPercent',
    //         'totalTaxAmount',
    //         'totalAmount',
    //         'formattedTotalAmount',
    //         'currencySymbol',
    //         'currencyPosition'
    //     ));
    // }

    public function sale_report($ids)
    {
        $authUser = auth()->user();
        $subAdminId = session('selectedSubAdminId');

        // Decide branch_id based on role
        if ($authUser->role === 'staff' && $authUser->branch_id) {
            $branchIdToUse = $authUser->branch_id;
        } elseif ($authUser->role === 'admin' && !empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } else {
            $branchIdToUse = $authUser->id;
        }

        $idsArray = explode(',', $ids);

        // Eager load related models
        $sales = OrderItem::with('product.category', 'invoice', 'user.userDetail', 'quantityType')
            ->whereIn('id', $idsArray)
            ->get();

            // dd($sales);

        if ($sales->isEmpty()) {
            return redirect()->route('sales.index')->with('error', 'No sales data found.');
        }

        // Get settings
        $settings = Setting::where('branch_id', $branchIdToUse)->first();
        $currencySymbol = $settings->currency_symbol ?? '₹';
        $currencyPosition = $settings->currency_position ?? 'left';

        // Process each sale
        $totalAmount = 0;
        $discountAmount = 0;
        $taxDetails = [];
        // 🔹 GST / Tax Calculation
        // $taxDetails     = [];
        $totalTaxAmount = 0;

        foreach ($sales as $sale) {
            $rowTaxes     = [];
            $rowTaxAmount = 0;

            $rowGSTOption = $sale->invoice->gst_option ?? 'without_gst';
            $rowTaxIds    = $sale->invoice->tax_id ?? '[]';

            // Decode JSON tax array
            $rowTaxIdsArray = json_decode($rowTaxIds, true) ?: [];

            $rowTaxRates = collect();
            if ($rowGSTOption === 'with_gst' && ! empty($rowTaxIdsArray)) {
                $rowTaxRates = TaxRate::where('status', 'active')
                    ->where('branch_id', $branchIdToUse)
                    ->where('isDeleted', 0)
                    ->whereIn('id', $rowTaxIdsArray)
                    ->get();
            }

            $unitPrice = $sale->price;
            // Apply discount per unit
            if ($sale->invoice && $sale->invoice->discount) {
                $discountPercent = $sale->invoice->discount;
                $unitPrice -= ($unitPrice * $discountPercent) / 100;
            }

            // Calculate row taxes
            foreach ($rowTaxRates as $tax) {
                $taxBase = $unitPrice * $sale->quantity;
                $amount  = $taxBase * ($tax->tax_rate / 100);

                $rowTaxes[] = [
                    'name'   => $tax->tax_name,
                    'rate'   => $tax->tax_rate,
                    'amount' => $amount,
                ];

                $rowTaxAmount += $amount;

                // accumulate overall tax totals
                if (! isset($taxDetails[$tax->id])) {
                    $taxDetails[$tax->id] = [
                        'name'   => $tax->tax_name,
                        'rate'   => $tax->tax_rate,
                        'amount' => 0,
                    ];
                }
                $taxDetails[$tax->id]['amount'] += $amount;
            }

            // Attach to sale row
            $sale->rowGSTOption = $rowGSTOption;
            $sale->rowTaxes     = $rowTaxes;
            $sale->rowTaxAmount = $rowTaxAmount;

            // Final total per row = (unit price after discount × qty) + row taxes
            $sale->rowFinalTotal = ($unitPrice * $sale->quantity) + $rowTaxAmount;

            // $totalAmount += $rowTaxAmount;
            $totalAmount = $sales->sum('rowFinalTotal');
        }

        // Customer info (from first sale)
        $customer = $sales->first()->user ?? null;
        $userDetails = $customer ? $customer->userDetail : null;

        return view('sales.sale_report', compact(
            'sales',
            'settings',
            'discountAmount',
            'totalAmount',
            'taxDetails',
            'currencySymbol',
            'currencyPosition',
            'customer',
            'userDetails',
            'ids'
        ));
    }


    public function export_sales_report_pdf($ids)
    {
        $authUser   = auth()->user();
        $subAdminId = session('selectedSubAdminId');

        // 🔹 Decide branch_id based on role
        if ($authUser->role === 'staff' && $authUser->branch_id) {
            $branchIdToUse = $authUser->branch_id;
        } elseif ($authUser->role === 'admin' && ! empty($subAdminId)) {
            $branchIdToUse = $subAdminId;
        } else {
            $branchIdToUse = $authUser->id;
        }

        $idsArray = explode(',', $ids);

        // 🔹 Eager load related models
        $sales = OrderItem::with('product.category', 'invoice', 'user.userDetail', 'quantityType')
            ->whereIn('id', $idsArray)
            ->get();

        // dd($sales);

        if ($sales->isEmpty()) {
            return redirect()->route('sales.index')->with('error', 'No sales data found.');
        }

        // 🔹 Get settings
        $setting         = Setting::where('branch_id', $branchIdToUse)->first();
        $currencySymbol   = $setting->currency_symbol ?? '₹';
        $currencyPosition = $setting->currency_position ?? 'left';

        $subtotal = $sales->sum('total_amount');

        // 🔹 Discount calculation
        $discountAmount = 0;
        foreach ($sales as $sale) {
            if ($sale->invoice && $sale->invoice->discount) {
                $discountPercent = $sale->invoice->discount;
                $discountAmount += ($sale->total_amount * $discountPercent) / 100;
            }
        }

        $subtotalAfterDiscount = $subtotal - $discountAmount;

        // 🔹 GST / Tax Calculation
        $taxDetails     = [];
        $totalTaxAmount = 0;

        foreach ($sales as $sale) {
            $rowTaxes     = [];
            $rowTaxAmount = 0;

            $rowGSTOption = $sale->invoice->gst_option ?? 'without_gst';
            $rowTaxIds    = $sale->invoice->tax_id ?? '[]';

            // Decode JSON tax array
            $rowTaxIdsArray = json_decode($rowTaxIds, true) ?: [];

            $rowTaxRates = collect();
            if ($rowGSTOption === 'with_gst' && ! empty($rowTaxIdsArray)) {
                $rowTaxRates = TaxRate::where('status', 'active')
                    ->where('branch_id', $branchIdToUse)
                    ->where('isDeleted', 0)
                    ->whereIn('id', $rowTaxIdsArray)
                    ->get();
            }

            $unitPrice = $sale->price;
            // Apply discount per unit
            if ($sale->invoice && $sale->invoice->discount) {
                $discountPercent = $sale->invoice->discount;
                $unitPrice -= ($unitPrice * $discountPercent) / 100;
            }

            // Calculate row taxes
            foreach ($rowTaxRates as $tax) {
                $taxBase = $unitPrice * $sale->quantity;
                $amount  = $taxBase * ($tax->tax_rate / 100);

                $rowTaxes[] = [
                    'name'   => $tax->tax_name,
                    'rate'   => $tax->tax_rate,
                    'amount' => $amount,
                ];

                $rowTaxAmount += $amount;

                // accumulate overall tax totals
                if (! isset($taxDetails[$tax->id])) {
                    $taxDetails[$tax->id] = [
                        'name'   => $tax->tax_name,
                        'rate'   => $tax->tax_rate,
                        'amount' => 0,
                    ];
                }
                $taxDetails[$tax->id]['amount'] += $amount;
            }

            // Attach to sale row
            $sale->rowGSTOption = $rowGSTOption;
            $sale->rowTaxes     = $rowTaxes;
            $sale->rowTaxAmount = $rowTaxAmount;

            // Final total per row = (unit price after discount × qty) + row taxes
            $sale->rowFinalTotal = ($unitPrice * $sale->quantity) + $rowTaxAmount;

            $totalTaxAmount += $rowTaxAmount;
        }

        // 🔹 Total after discount + taxes
        // Total after discount + taxes
        $totalAmount = $sales->sum('rowFinalTotal');

        $pdfData = [
            'sales'            => $sales,
            'setting'         => $setting,
            'currencySymbol'   => $currencySymbol,
            'currencyPosition' => $currencyPosition,
            'subtotal'         => $subtotal,
            'discountAmount'   => $discountAmount,
            // 'afterDiscount'    => $afterDiscount,
            'taxDetails'       => $taxDetails,
            'totalTaxAmount'   => $totalTaxAmount,
            'totalAmount'       => $totalAmount,
            // 'ids' => $ids
        ];

        // Load PDF
        $pdf = PDF::loadView('sales.sales-invoice-report-pdf', $pdfData)
            ->setPaper('A4', 'portrait')
            ->setOptions([
                'defaultFont'          => 'DejaVu Sans',
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled'      => true,
            ]);

        return $pdf->download('sales_report.pdf');
    }


    //  public function makePaymentSubmit(Request $request)
    //     {
    //         // $user_id = Auth::id();
    //         $user_id = Auth::guard('api')->user();

    //         $request->validate([

    //             'order_id' => 'nullable|integer',
    //             'payment_amount' => 'nullable|numeric',
    //             'payment_date' => 'nullable|date',
    //             'payment_type' => 'nullable|string',
    //             'emi_month' => 'nullable|integer',
    //             'pending_date' => 'nullable|date',
    //             'new_emi_value' => 'nullable',
    //             'emi_paid_value' => 'nullable|numeric',
    //         ]);

    //         if ($request->filled('order_id')) {
    //             // Determine payment amount
    //             $paymentAmount = $request->emi_total_new ?? $request->emi_total ?? $request->amount ?? $request->upi_online_amount ?? 0;

    //             if ($request->filled('cash_amount') && $request->filled('online_amount')) {
    //                 $paymentAmount = (float) $request->cash_amount + (float) $request->online_amount;
    //             } elseif ($request->filled('fully_cash_amount') && $request->filled('full_online_amount')) {
    //                 $paymentAmount = (float) $request->fully_cash_amount + (float) $request->full_online_amount;
    //             } elseif ($request->cashAmount) {
    //                 $paymentAmount = $request->cashAmount;
    //             } elseif ($request->upi_online_amount) {
    //                 $paymentAmount = $request->upi_online_amount;
    //             } elseif ($request->emi_monthly) {
    //                 $paymentAmount = $request->emi_monthly;
    //             }

    //             // Determine payment type
    //             if (
    //                 in_array($request->paid_type, ['cash_partially']) ||
    //                 in_array($request->online_type, ['online_partially']) ||
    //                 in_array($request->cash_online_type, ['cash_online_partially'])
    //             ) {
    //                 $type = 'partially';
    //             } elseif (
    //                 in_array($request->paid_type, ['cash_fully']) ||
    //                 in_array($request->online_type, ['online_fully']) ||
    //                 in_array($request->cash_online_type, ['cash_online_fully']) ||
    //                 $request->payment_type === 'fully'

    //             ) {
    //                 $type = 'fully';
    //             } elseif (
    //                 in_array($request->emi_type, ['emi'])
    //             ) {
    //                 $type = 'emi';
    //             } else {
    //                 $type = 'fully';
    //             }


    //             // Fetch Invoice if exists
    //             $invoice = $request->order_id ? Order::find($request->order_id) : null;

    //             // Calculate remaining amount
    //             $currentRemaining = $invoice->remaining_amount ?? 0;
    //             $newRemaining = max(0, $currentRemaining - $paymentAmount);
    //             // dd($currentRemaining,$newRemaining);

    //             $payment = PaymentStore::create([
    //                 'user_id' => $user_id,
    //                 'order_id' =>  $request->order_id,
    //                 'custom_invoice_id' => 0,
    //                 'payment_amount' => $paymentAmount,
    //                 'remaining_amount' => $newRemaining,
    //                 'payment_method' => $request->payment_method ?? $request->payment_type ?? '',
    //                 'payment_date' => \Carbon\Carbon::now(),
    //                 'payment_type' => $type,
    //                 'cash_amount' => $request->cash_amount,
    //                 'upi_amount' => $request->online_amount,
    //                 'emi_month' => $request->emi_month ?? 1,
    //                 'isDeleted' => 0,
    //             ]);

    //             // Update invoice
    //             if ($invoice) {
    //                 $updateData = ['remaining_amount' => $newRemaining];

    //                 // If new EMI is being set
    //                 if ($request->filled('new_emi_value') && $request->payment_method == 'emi' || $request->filled('emi_paid_value')) {
    //                     //  dd($request->all());
    //                     $updateData['payment_method'] = 'EMI';
    //                     $updateData['emi_duration'] = $request->emi_month_new ?? $request->emi_month;
    //                     $updateData['emi_months'] = $request->emi_total_new ?? 1;
    //                 } else {
    //                     // dd($request->filled('emi_paid_value'));
    //                     // Otherwise, keep the actual payment method (cash, online, cash_online)
    //                     $method = $request->payment_method ?? $request->payment_type ?? $updateData['payment_method'] ?? 'Cash';

    //                     // Normalize to proper values
    //                     if (strtolower($method) === 'online' || strtolower($method) === 'upi') {
    //                         $method = 'Online';
    //                     } elseif (strtolower($method) === 'cash') {
    //                         $method = 'Cash';
    //                     } elseif (strtolower($method) === 'emi') {
    //                         $method = 'EMI';
    //                     } else {
    //                         $method = 'Cash';
    //                     }

    //                     $updateData['payment_method'] = $method;
    //                 }

    //                 if ($request->emi_duration) {
    //                     $updateData['emi_duration'] = $request->emi_duration;
    //                 }

    //                 // Update next pending date if provided
    //                 if ($request->pending_date) {
    //                     $updateData['next_pending_date'] = $request->pending_date;
    //                 }

    //                 $invoice->update($updateData);
    //             }
    //         }
    //         return response()->json([
    //             'status' => 'success',
    //             'message' => 'Payment submitted successfully.',
    //             'data' => $payment
    //         ]);
    //     }

    // public function getHistory($order_id)
    // {
    //     // $history = PaymentStore::where('order_id', $job  _card_id)
    //     $history = PaymentStore::where('order_id', $order_id)
    //         ->orderBy('created_at', 'desc')
    //         ->get();

    //     return response()->json([
    //         'status' => 'success',
    //         'data' => $history
    //     ]);
    // }


    // public function show_sales_report_page(Request $request)
    // {
    //     try {
    //         // $authUser = Auth::guard('api')->user();
    //         $ids = $request->input('ids');
    //         $branchId = $request->input('branch');

    //         if (empty($ids)) {
    //             abort(404, 'No sales selected.');
    //         }

    //         $idsArray = explode(',', $ids);

    //         // 🔹 Fetch sales data with relations
    //         $sales = OrderItem::with('product.category', 'invoice', 'user.userDetail')
    //             ->whereIn('id', $idsArray)
    //             ->get();

    //         if ($sales->isEmpty()) {
    //             abort(404, 'No sales found.');
    //         }

    //         // 🔹 Settings
    //         $settings = Setting::where('branch_id', $branchId)->first();
    //         $currencySymbol   = $settings->currency_symbol ?? '₹';
    //         $currencyPosition = $settings->currency_position ?? 'left';

    //         // 🔹 Tax / Discount calculations
    //         $taxDetails = [];
    //         $totalAmount = 0;
    //         $discountAmount = 0;

    //         foreach ($sales as $sale) {
    //             $rowTaxes     = [];
    //             $rowTaxAmount = 0;

    //             $rowGSTOption = $sale->invoice->gst_option ?? 'without_gst';
    //             $rowTaxIds    = $sale->invoice->tax_id ?? '[]';
    //             $rowTaxIdsArray = json_decode($rowTaxIds, true) ?: [];

    //             // Fetch applicable tax rates
    //             $rowTaxRates = collect();
    //             if ($rowGSTOption === 'with_gst' && !empty($rowTaxIdsArray)) {
    //                 $rowTaxRates = TaxRate::where('status', 'active')
    //                     ->where('branch_id', $branchId)
    //                     ->where('isDeleted', 0)
    //                     ->whereIn('id', $rowTaxIdsArray)
    //                     ->get();
    //             }

    //             $unitPrice = $sale->price;
    //             // Apply invoice-level discount
    //             if ($sale->invoice && $sale->invoice->discount) {
    //                 $discountPercent = $sale->invoice->discount;
    //                 $unitPrice -= ($unitPrice * $discountPercent) / 100;
    //             }

    //             // Calculate taxes per row
    //             foreach ($rowTaxRates as $tax) {
    //                 $taxBase = $unitPrice * $sale->quantity;
    //                 $amount  = $taxBase * ($tax->tax_rate / 100);

    //                 $rowTaxes[] = [
    //                     'name'   => $tax->tax_name,
    //                     'rate'   => $tax->tax_rate,
    //                     'amount' => $amount,
    //                 ];

    //                 $rowTaxAmount += $amount;

    //                 // accumulate overall tax totals
    //                 if (!isset($taxDetails[$tax->id])) {
    //                     $taxDetails[$tax->id] = [
    //                         'name'   => $tax->tax_name,
    //                         'rate'   => $tax->tax_rate,
    //                         'amount' => 0,
    //                     ];
    //                 }
    //                 $taxDetails[$tax->id]['amount'] += $amount;
    //             }

    //             // Attach row-level data for display
    //             $sale->rowGSTOption = $rowGSTOption;
    //             $sale->rowTaxes     = $rowTaxes;
    //             $sale->rowTaxAmount = $rowTaxAmount;

    //             // Final total per item (price × qty + tax)
    //             $sale->rowFinalTotal = ($unitPrice * $sale->quantity) + $rowTaxAmount;
    //         }

    //         // 🔹 Calculate grand total
    //         $totalAmount = $sales->sum('rowFinalTotal');

    //         // 🔹 Customer info
    //         $customer = $sales->first()->user ?? null;
    //         $userDetails = $customer ? $customer->userDetail : null;

    //         // 🔹 Data for blade view
    //         $data = [
    //             'sales'            => $sales,
    //             'settings'         => $settings,
    //             'discountAmount'   => $discountAmount,
    //             'totalAmount'      => $totalAmount,
    //             'taxDetails'       => $taxDetails,
    //             'currencySymbol'   => $currencySymbol,
    //             'currencyPosition' => $currencyPosition,
    //             'customer'         => $customer,
    //             'userDetails'      => $userDetails,
    //             'ids'              => $ids,
    //         ];

    //         return view('sales.web_sale_report', $data);

    //     } catch (\Throwable $e) {
    //         abort(500, 'Error loading sales report: ' . $e->getMessage());
    //     }
    // }
    public function show_sales_report_page(Request $request)
    {
        try {
            // 🔹 Get inputs directly from the request
            $ids = $request->input('ids');
            $branchId = $request->input('branch');

            // 🔹 Validate required parameters
            if (empty($ids)) {
                abort(404, 'No sales selected.');
            }
            if (empty($branchId)) {
                abort(404, 'Branch ID is missing.');
            }

            // 🔹 Convert to array if comma-separated
            $idsArray = explode(',', $ids);

            // 🔹 Fetch sales data with relationships
            $sales = OrderItem::with('product.category', 'invoice', 'user.userDetail')
                ->whereIn('id', $idsArray)
                ->get();

            if ($sales->isEmpty()) {
                abort(404, 'No sales found.');
            }

            // 🔹 Fetch settings for branch
            $settings = Setting::where('branch_id', $branchId)->first();
            $currencySymbol   = $settings->currency_symbol ?? '₹';
            $currencyPosition = $settings->currency_position ?? 'left';

            // 🔹 Initialize totals
            $taxDetails = [];
            $totalAmount = 0;
            $discountAmount = 0;

            foreach ($sales as $sale) {
                $rowTaxes     = [];
                $rowTaxAmount = 0;

                $rowGSTOption = $sale->invoice->gst_option ?? 'without_gst';
                $rowTaxIds    = $sale->invoice->tax_id ?? '[]';
                $rowTaxIdsArray = json_decode($rowTaxIds, true) ?: [];

                // 🔹 Fetch applicable tax rates
                $rowTaxRates = collect();
                if ($rowGSTOption === 'with_gst' && !empty($rowTaxIdsArray)) {
                    $rowTaxRates = TaxRate::where('status', 'active')
                        ->where('branch_id', $branchId)
                        ->where('isDeleted', 0)
                        ->whereIn('id', $rowTaxIdsArray)
                        ->get();
                }

                // 🔹 Apply discount (if any)
                $unitPrice = $sale->price;
                if ($sale->invoice && $sale->invoice->discount) {
                    $discountPercent = $sale->invoice->discount;
                    $discountPerUnit = ($unitPrice * $discountPercent) / 100;
                    $unitPrice -= $discountPerUnit;
                    $discountAmount += $discountPerUnit * $sale->quantity;
                }

                // 🔹 Calculate taxes per item
                foreach ($rowTaxRates as $tax) {
                    $taxBase = $unitPrice * $sale->quantity;
                    $amount  = $taxBase * ($tax->tax_rate / 100);

                    $rowTaxes[] = [
                        'name'   => $tax->tax_name,
                        'rate'   => $tax->tax_rate,
                        'amount' => $amount,
                    ];

                    $rowTaxAmount += $amount;

                    // Accumulate total tax details
                    if (!isset($taxDetails[$tax->id])) {
                        $taxDetails[$tax->id] = [
                            'name'   => $tax->tax_name,
                            'rate'   => $tax->tax_rate,
                            'amount' => 0,
                        ];
                    }
                    $taxDetails[$tax->id]['amount'] += $amount;
                }

                // 🔹 Attach row-level summary
                $sale->rowGSTOption = $rowGSTOption;
                $sale->rowTaxes     = $rowTaxes;
                $sale->rowTaxAmount = $rowTaxAmount;

                // 🔹 Final total per item
                $sale->rowFinalTotal = ($unitPrice * $sale->quantity) + $rowTaxAmount;
            }

            // 🔹 Calculate final grand total
            $totalAmount = $sales->sum('rowFinalTotal');

            // 🔹 Customer info (first sale user)
            $customer = $sales->first()->user ?? null;
            $userDetails = $customer ? $customer->userDetail : null;

            // 🔹 Prepare data for Blade view
            $data = [
                'sales'            => $sales,
                'settings'         => $settings,
                'discountAmount'   => $discountAmount,
                'totalAmount'      => $totalAmount,
                'taxDetails'       => $taxDetails,
                'currencySymbol'   => $currencySymbol,
                'currencyPosition' => $currencyPosition,
                'customer'         => $customer,
                'userDetails'      => $userDetails,
                'ids'              => $ids,
            ];

            // ✅ Return view without requiring authentication
            return view('sales.web_sale_report', $data);
        } catch (\Throwable $e) {
            abort(500, 'Error loading sales report: ' . $e->getMessage());
        }
    }
    // public function getTypes($productId)
    // {
    //     $product = Product::find($productId);
    //     $types = QuantityType::where('id', $product->quantity_type_id)->get();
    //     return response()->json($types);
    // }
}
