<?php

namespace App\Http\Controllers\api;

use App\Models\UserPermission;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDetail;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use App\Models\Module;
use Illuminate\Validation\Rule;


class StaffController extends Controller
{
    public function getAllStaff(Request $request)
    {
        $user = Auth::guard('api')->user();
        $userBranchId = $user->id ?? null;

        if (!empty($request->selectedSubAdminId)) {
            $userBranchId = $request->selectedSubAdminId;
        }

        $customers = User::select('id', 'name', 'email', 'phone', 'profile_image', 'role', 'gst_number', 'pan_number')
            ->where('role', 'staff')
            ->where('branch_id', $userBranchId)
            ->where('isDeleted', 0)
            ->with('details:country,user_id,city')
            ->orderBy('id', 'desc')
            ->get()
            ->map(function ($customer) {
                return [
                    'id' => $customer->id,
                    'name' => $customer->name,
                    'role' => $customer->role,
                    'email' => $customer->email,
                    'phone' => $customer->phone,
                    'gst_number' => $customer->gst_number,
                    'pan_number' => $customer->pan_number,
                    'profile_image' => $customer->profile_image,
                    'profile_image_url' => $customer->profile_image_url,
                    'country' => $customer->details ? $customer->details->country : '',
                    'city' => $customer->details ? $customer->details->city : '',
                ];
            });

        return response()->json(['status' => true, 'data' => $customers]);
    }


    public function getCustomerById($id)
    {
        $customer = User::find($id); // Assuming you have a User model
        if ($customer) {
            return response()->json(['status' => true, 'customer' => $customer], 200);
        } else {
            return response()->json(['status' => false, 'error' => 'Customer not found'], 404);
        }
    }
    public function createStaff(Request $request)
    {
        $user = Auth::guard('api')->user();
        $userBranchId = $user->id ?? null;
        if (!empty($request->sub_admin_id)) {
            $userBranchId = $request->sub_admin_id;
        }


        $validator = Validator::make($request->all(), [
            'customer_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|numeric|unique:users,phone',
            'gst_number' => 'nullable|string|max:15',
            'pan_number' => 'nullable|string|max:15',
            'country' => 'nullable|string|max:100',
            'password' => 'required|string|min:6',
            'city' => 'nullable|string|max:100',
            'address' => 'nullable|string|max:500',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // ✅ Create user
        $customer = new User();
        $customer->name = $request->customer_name;
        $customer->email = $request->email;
        $customer->phone = $request->phone;
        $customer->gst_number = $request->gst_number;
        $customer->pan_number = $request->pan_number;
        $customer->haspermission = $request->permission_type;
        $customer->password = Hash::make($request->password);

        if ($request->hasFile('avatar')) {
            $path = $request->file('avatar')->store('staff', 'public');
            $customer->profile_image = $path;
        }
        $customer->branch_id = $userBranchId;
        $customer->role = 'staff';
        $customer->status = 1;
        $customer->save();

        // ✅ Create user details
        $customerDetail = new UserDetail();
        $customerDetail->user_id = $customer->id;
        $customerDetail->country = $request->country;
        $customerDetail->city = $request->city;
        $customerDetail->address = $request->address;
        $customerDetail->save();

        // ✅ Store dynamic permissions
        if ($request->has('modules') && is_array($request->modules)) {
            // dd($request->modules)  ;
            foreach ($request->modules as $moduleData) {

                UserPermission::create([
                    'user_id'  => $customer->id,
                    'module_id' => $moduleData['module_id'],
                    'view'     => isset($moduleData['view']) ? 1 : 0,
                    'add'      => isset($moduleData['add']) ? 1 : 0,
                    'edit'     => isset($moduleData['edit']) ? 1 : 0,
                    'delete'   => isset($moduleData['delete']) ? 1 : 0,
                ]);
            }
        }

        return response()->json([
            'status'  => true,
            'message' => 'Staff created successfully',
            'data'    => [
                'user_id' => $customer->id,
            ],
        ], 201);
    }

    public function deleteStaff(Request $request, $id)
    {
        $customer = User::find($id);

        if (!$customer) {
            return response()->json(['status' => false, 'error' => 'Staff not found'], 404);
        }

        // Check if the customer has any orders
        $hasOrders = Order::where('user_id', $id)->exists();

        if ($hasOrders) {
            return response()->json(['status' => false, 'error' => 'This Staff cannot be deleted because they have placed orders.'], 400);
        }

        DB::beginTransaction();

        try {
            // Delete related user details
            UserDetail::where('user_id', $id)->update(['isDeleted' => 1]);

            // Soft delete the customer
            $customer->isDeleted = 1;
            $customer->save();

            DB::commit();

            return response()->json(['status' => true, 'message' => 'Staff deleted successfully!']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'error' => 'Error: ' . $e->getMessage()], 500);
        }
    }


    // public function getStaff($id)
    // {
    //     // Find customer and include details
    //     $customer = User::with('details')->find($id);

    //     if (!$customer) {
    //         return response()->json(['status' => false, 'error' => 'Customer not found'], 404);
    //     }

    //     return response()->json([
    //         'status' => true,
    //         'customer' => $customer,
    //     ]);
    // }
    public function getStaff($id)
    {
        $customer = User::with('details')->find($id);
        if (!$customer) {
            return response()->json(['status' => false, 'error' => 'Staff not found'], 404);
        }

        // Get all modules
        $modules = Module::all();

        // Fetch permissions for this user
        $permissions = UserPermission::where('user_id', $id)->get();

        return response()->json([
            'status' => true,
            'customer' => $customer,
            'modules' => $modules,
            'permissions' => $permissions
        ]);
    }

    // public function updateStaff(Request $request, $id)
    // {
    //     // Validate input data
    //     $validator = Validator::make($request->all(), [
    //         'customer_name' => 'required|string|max:255',
    //         'email' => "required|email|unique:users,email,$id",
    //         'phone' => "required|numeric|digits_between:10,15|unique:users,phone,$id",
    //         'gst_number' => 'nullable|string|max:15',
    //         'pan_number' => 'nullable|string|max:15',
    //         'country' => 'nullable|string|max:100',
    //         'city' => 'nullable|string|max:100',
    //         'address' => 'nullable|string|max:500',
    //         'password' => 'nullable|string|min:6', // ✅ Allow optional password update
    //         'avatar' => 'nullable|image|mimes:jpeg,png,webp,jpg,gif|max:2048',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => false,
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }

    //     // Find the user
    //     $customer = User::find($id);
    //     if (!$customer) {
    //         return response()->json([
    //             'status' => false,
    //             'error' => 'Staff not found'
    //         ], 404);
    //     }

    //     // Update main user fields
    //     $customer->name = $request->customer_name;
    //     $customer->email = $request->email;
    //     $customer->phone = $request->phone;
    //     $customer->gst_number = $request->gst_number;
    //     $customer->pan_number = $request->pan_number;

    //     $customer->role = 'staff';

    //     // ✅ Hash and update password if provided
    //     if ($request->filled('password')) {
    //         $customer->password = Hash::make($request->password);
    //     }

    //     // ✅ Store avatar in `staff` folder
    //     if ($request->hasFile('avatar')) {
    //         $path = $request->file('avatar')->store('staff', 'public');
    //         $customer->profile_image = $path;
    //     }

    //     $customer->save();

    //     // Update related user details
    //     $customerDetail = UserDetail::where('user_id', $id)->first();
    //     if ($customerDetail) {
    //         $customerDetail->country = $request->country;
    //         $customerDetail->city = $request->city;
    //         $customerDetail->address = $request->address;
    //         $customerDetail->save();
    //     }

    //     return response()->json([
    //         'status' => true,
    //         'message' => 'Staff updated successfully!'
    //     ]);
    // }

    public function updateStaff(Request $request, $id)
    {
        // Validate input data
        $validator = Validator::make($request->all(), [
            'staff_name' => 'required|string|max:255',
            'email'      => "required|email|unique:users,email,$id",
            'phone'      => "required|numeric|digits_between:10,15|unique:users,phone,$id",
            'country'    => 'nullable|string|max:100',
            'city'       => 'nullable|string|max:100',
            'address'    => 'nullable|string|max:500',
            'password'   => 'nullable|string|min:6',
            'avatar'     => 'nullable|image|mimes:jpeg,png,webp,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Find the user
        $customer = User::find($id);
        if (!$customer) {
            return response()->json([
                'status' => false,
                'error'  => 'Staff not found'
            ], 404);
        }

        DB::transaction(function () use ($request, $customer, $id) {
            // Update main user fields
            $customer->name          = $request->staff_name;
            $customer->email         = $request->email;
            $customer->phone         = $request->phone;
            $customer->haspermission = $request->permission_type;
            $customer->role          = 'staff';

            if ($request->filled('password')) {
                $customer->password = Hash::make($request->password);
            }

            if ($request->hasFile('avatar')) {
                $path = $request->file('avatar')->store('staff', 'public');
                $customer->profile_image = $path;
            }

            $customer->save();

            // Update or create user details
            $customerDetail = UserDetail::firstOrNew(['user_id' => $id]);
            $customerDetail->country = $request->country;
            $customerDetail->city    = $request->city;
            $customerDetail->address = $request->address;
            $customerDetail->save();

            // Update permissions according to selected permission type
            if ((int) $request->input('permission_type', 0) === 0) {
                // Without permission: remove all permissions
                UserPermission::where('user_id', $customer->id)->delete();
            } else {
                $moduleInputs = $request->input('modules', []);

                // Upsert submitted permissions (keep module even if all 0)
                foreach ($moduleInputs as $moduleData) {

                    UserPermission::updateOrCreate(
                        [
                            'user_id'   => $customer->id,
                            'module_id' => (int) $moduleData['module_id'],
                        ],
                        [
                            'view'   => !empty($moduleData['view'])   ? (int) $moduleData['view']   : 0,
                            'add'    => !empty($moduleData['add'])    ? (int) $moduleData['add']    : 0,
                            'edit'   => !empty($moduleData['edit'])   ? (int) $moduleData['edit']   : 0,
                            'delete' => !empty($moduleData['delete']) ? (int) $moduleData['delete'] : 0,
                        ]
                    );
                }
            }
        // dd($moduleData);
        });
        return response()->json([
            'status'  => true,
            'message' => 'Staff updated successfully!',
            'data'    => [
                'user_id' => $customer->id,
            ],
            'staff'         => $customer,
            'staff_details' => $customer->details ?? null,
        ]);
    }
    public function getStaffProfile($id)
    {
        $user = User::with('userDetail')->find($id);

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        // Get permissions with module name
        $permissions = UserPermission::with('module')
            ->where('user_id', $id)
            ->get()
            ->map(function ($perm) {
                return [
                    'module' => $perm->module->module ?? 'Unknown',
                    'view' => (bool) $perm->view,
                    'add' => (bool) $perm->add,
                    'edit' => (bool) $perm->edit,
                    'delete' => (bool) $perm->delete,
                ];
            });

        return response()->json([
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'gst_num' => $user->gst_num,
            'role' => $user->role,
            'profile_image' => $user->profile_image,
            'address' => $user->userDetail->address ?? 'N/A',
            'city' => $user->userDetail->city ?? 'N/A',
            'country' => $user->userDetail->country ?? 'N/A',
            'permissions' => $permissions,
        ]);
    }

    public function index()
    {
        $modules = Module::select('id', 'module as module_name', 'created_at')->get();

        return response()->json([
            'status'  => true,
            'message' => 'Modules fetched successfully',
            'data'    => $modules
        ], 200);
    }
}
