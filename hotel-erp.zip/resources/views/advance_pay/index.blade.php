@extends('layout.app')

@section('title', 'Advance Payment Details')

@section('content')
    <style>
        #DataTables_Table_0_info {
            float: left;
        }

        .table-scroll-top {
            display: none;
        }

        button#exportBtn {
            padding: 3px;
        }

        .table-scroll-top {
            overflow-x: auto;
            overflow-y: hidden;
            height: 20px;
            width: 100%;
            margin-bottom: 5px;
        }

        .table-scroll-top div {
            height: 1px;
        }

        .grand-total-box {
            display: inline-block;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background-color: #f8f9fa;
            font-size: 16px;
            font-weight: bold;
        }

        .grand-total-box strong {
            color: #1b2850;
            margin-right: 4px;
        }

        .grand-total-box span {
            color: orange;
        }

        /* Ensure select shows full placeholder text */
        .form-select-sm {
            min-width: 130px;
            margin-right: 10px;
            /* Add some space between selects *s
                            /* Adjust as needed */
        }


        @media screen and (max-width: 767px) {
            .table-scroll-top {
                display: block;
            }

            div#DataTables_Table_0_filter {
                margin-top: 10px !important;
            }

            .table-top {
                flex-direction: row;
                margin-bottom: 0 !important;
            }

            .table-top .wordset {
                margin-top: 0 !important;
            }

            .dataTables_length {
                margin-left: .8rem !important;
                margin-bottom: .1rem !important;
            }

            .dataTables_filter {
                text-align: left !important;
            }
        }
    </style>
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>All Advance Payment Details</h4>

            </div>
            <div class="page-btn">
                @if (app('hasPermission')(23, 'add'))
                    <a href="{{ route('advance_pay.create') }}" class="btn btn-added btn-sm">
                        <img src="{{ env('ImagePath') . 'admin/assets/img/icons/plus.svg' }}" alt="img"> New Advance
                        Payment
                    </a>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="card-body">

                <div class="table-top mb-3">
                    <div class="row g-3 align-items-end">

                        <!-- Staff Name -->
                        <div class="col-6 col-sm-4 col-md-3">
                            <label for="filterStaffName" class="form-label mb-1">Staff Name</label>
                            <select id="filterStaffName" class="form-select form-select-sm">
                                <option value="">Select Staff</option>
                                <!-- Dynamic staff options here -->
                            </select>
                        </div>

                        <!-- Year -->
                        <div class="col-6 col-sm-4 col-md-3">
                            <label for="filterYear" class="form-label mb-1">Year</label>
                            <select id="filterYear" class="form-select form-select-sm">
                                <option value="">Select Year</option>
                                <!-- Dynamic year options -->
                            </select>
                        </div>

                        <!-- Month -->
                        <div class="col-6 col-sm-4 col-md-3">
                            <label for="filterMonth" class="form-label mb-1">Month</label>
                            <select id="filterMonth" class="form-select form-select-sm">
                                <option value="">Select Month</option>
                                @for ($m = 1; $m <= 12; $m++)
                                    <option value="{{ str_pad($m, 2, '0', STR_PAD_LEFT) }}">
                                        {{ \Carbon\Carbon::create()->month($m)->format('F') }}
                                    </option>
                                @endfor
                            </select>
                        </div>

                        <!-- Export Button -->
                        <div class="col-6 col-sm-12 col-md-3 text-start text-md-end">
                            <button id="exportBtn" class="btn btn-success btn-sm w-100 w-md-auto">
                                <i class="fa fa-download me-1"></i> Export
                            </button>
                        </div>

                    </div>
                </div>



                <div class="table-scroll-top">
                    <div></div>
                </div>
                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>
                                <th>Staff Name</th>
                                <th>Amount</th>
                                <th>Paid Amount</th>
                                <th>Pending Amount</th>
                                <th>Date</th>
                                <th>Method</th>
                                <th>Reason</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody id="paymentTableBody">
                            <!-- Data will be loaded dynamically -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="8" class="text-end">
                                    <div class="grand-total-box">
                                        <strong>Total Payments:</strong>
                                        <span id="grandTotalAmount">₹0.00</span>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('js')
    <script>
        $(document).ready(function() {
        const authToken = localStorage.getItem("authToken");
                const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
            $(document).ready(function() {
                

                // Initial params for API
                let params = {};
                if (selectedSubAdminId) {
                    params.selectedSubAdminId = selectedSubAdminId;
                }

                // Fetch filters on page load
                fetchFilters();

                // Fetch table data on page load
                fetchAdvancePayments();

                // Fetch filters via AJAX
                function fetchFilters() {
                    $.ajax({
                        url: "/api/advance-payment-filters",
                        type: "GET",
                        data: params,
                        dataType: "json",
                        headers: {
                            "Authorization": "Bearer " + authToken,
                        },
                        success: function(response) {
                            if (response.staff) {
                                let staffOptions = '<option value="">Select Staff</option>';
                                $.each(response.staff, function(i, staff) {
                                    staffOptions +=
                                        `<option value="${staff.id}">${staff.name}</option>`;
                                });
                                $("#filterStaffName").html(staffOptions);
                            }

                            if (response.years) {
                                let yearOptions = '<option value="">Select Year</option>';
                                $.each(response.years, function(i, year) {
                                    yearOptions +=
                                        `<option value="${year}">${year}</option>`;
                                });
                                $("#filterYear").html(yearOptions);
                            }
                        }
                    });
                }

                // Fetch advance payments
                function fetchAdvancePayments() {
                    $.ajax({
                        url: "/api/advance-payments",
                        type: "GET",
                        dataType: "json",
                        data: params,
                        beforeSend: function() {
                            $(".datanew tbody").html(
                                '<tr><td colspan="6" class="text-center">Loading...</td></tr>'
                            );
                        },
                        headers: {
                            "Authorization": "Bearer " + authToken,
                        },
                        success: function(response) {
                            if (response.status && Array.isArray(response.data)) {
                                let payments = response.data;
                                let tableBody = "";
                                let grandTotal = 0; // 👈 Initialize total

                                $.each(payments, function(index, payment) {
                                    let amount = parseFloat(payment.amount) || 0;
                                    let paid = parseFloat(payment.paid_amount) || 0;
                                    let pending = parseFloat(payment.pending) || 0;
                                    grandTotal += amount; // 👈 Add to total

                                    // Capitalize each word
                                    let staffName = payment.staff_name ?
                                        payment.staff_name.replace(/\b\w/g, c => c
                                            .toUpperCase()) :
                                        'N/A';

                                    let method = payment.method ?
                                        payment.method.replace(/\b\w/g, c => c
                                            .toUpperCase()) :
                                        'N/A';

                                    let reason = payment.reason ?
                                        payment.reason.replace(/\b\w/g, c => c
                                            .toUpperCase()) :
                                        '-';

                                    tableBody += `
                            <tr>
                                <td>${staffName}</td>
            <td>₹${amount.toFixed(2)}</td>
            <td>₹${paid.toFixed(2)}</td>
            <td>₹${pending.toFixed(2)}</td>
            <td>${payment.date}</td>
            <td>${payment.method}</td>

                                <td style="white-space: normal; word-wrap: break-word; word-break: break-word;">
    ${reason}
</td>
                                <td>
                                    @if (app('hasPermission')(23, 'view'))
                                    <a href="/advance_pay/${payment.id}" class="me-2">
                                       <img src="{{ env('ImagePath') . 'admin/assets/img/icons/eye.svg' }}" alt="img">
                                    </a>
                                    @endif
                                    @if (app('hasPermission')(23, 'edit'))
                                    <a href="/advance_pay/${payment.id}/edit" class="me-2">
                                         <img src="{{ env('ImagePath') . 'admin/assets/img/icons/edit.svg' }}" alt="img">
                                    </a>
                                    @endif
                                    @if (app('hasPermission')(23, 'delete'))
                                    <a href="javascript:void(0);" class="delete-btn" data-id="${payment.id}">
                                        <img src="{{ env('ImagePath') . 'admin/assets/img/icons/delete.svg' }}" alt="img">
                                    </a>
                                    @endif
                                </td>
                            </tr>
                        `;
                                });

                                // Destroy DataTable before injecting new HTML
                                if ($.fn.DataTable.isDataTable(".datanew")) {
                                    $(".datanew").DataTable().clear().destroy();
                                }

                                $(".datanew tbody").html(tableBody);

                                // ✅ Always use calculated total (ignore API total if missing)
                                $("#grandTotalAmount").text("₹" + grandTotal.toFixed(2));

                                // Reinitialize DataTable after injecting rows
                                $(".datanew").DataTable({
                                    responsive: true,
                                    pageLength: 10,
                                    ordering: false,
                                    language: {
                                        emptyTable: "No advance payments found.",
                                        zeroRecords: "No matching records.",
                                    },
                                });

                            } else {
                                $(".datanew tbody").html(
                                    '<tr><td colspan="6" class="text-center">No advance payments found.</td></tr>'
                                );
                                $("#grandTotalAmount").text("₹0.00"); // reset total
                            }
                        },
                        error: function() {
                            $(".datanew tbody").html(
                                '<tr><td colspan="6" class="text-center text-danger">Error loading data.</td></tr>'
                            );
                            $("#grandTotalAmount").text("₹0.00"); // reset total
                        }
                    });
                }

                // When any filter changes, reload data
                $("#filterStaffName, #filterYear, #filterMonth").on("change", function() {
                    params.staff_id = $("#filterStaffName").val();
                    params.year = $("#filterYear").val();
                    params.month = $("#filterMonth").val();
                    fetchAdvancePayments();
                });

            });


            // Handle Delete
            $(document).on("click", ".delete-btn", function() {
                let paymentId = $(this).data("id");

                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#d33",
                    confirmButtonColor: "#ff9f43", // Confirm button color (orange)
                    cancelButtonColor: "#6c757d", // Cancel button color (gray)
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `/api/advance-payments/${paymentId}`,
                            type: "DELETE",
                            headers: {
                                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                    "content"),
                                "Authorization": "Bearer " + authToken,
                            },
                            success: function(response) {
                                // Swal.fire("Deleted!", response.message, "success");
                                Swal.fire({
                                    title: "Deleted!",
                                    text: response.message,
                                    icon: "success",
                                    confirmButtonColor: "#ff9f43", // Custom OK button color
                                    confirmButtonText: "OK"
                                });
                                // fetchAdvancePayments(); // Refresh the table after deletion
                                window.location.reload();
                            },
                            error: function(xhr) {
                                let errorMessage = "Failed to delete customer.";
                                if (xhr.responseJSON && xhr.responseJSON.error) {
                                    errorMessage = xhr.responseJSON.error;
                                }
                                Swal.fire({
                                    title: "Error!",
                                    text: errorMessage,
                                    icon: "error",
                                    confirmButtonColor: "#ff9f43", // custom orange color
                                    confirmButtonText: "OK"
                                });
                            },
                        });
                    }
                });
            });

             document.getElementById('exportBtn').addEventListener('click', function() {
                let staffId = document.getElementById('filterStaffName')?.value || '';
                let year = document.getElementById('filterYear')?.value || '';
                let month = document.getElementById('filterMonth')?.value || '';

                let params = {};

                if (staffId) params.staff_id = staffId;
                if (year) params.year = year;
                if (month) params.month = month;
                if (typeof selectedSubAdminId !== 'undefined' && selectedSubAdminId) {
                    params.selectedSubAdminId = selectedSubAdminId;
                }

                let query = new URLSearchParams(params).toString();
                if (query.length > 0) query = '?' + query;

                let token = localStorage.getItem("authToken");

                fetch('/api/export-advance-payments' + query, {
                        method: 'GET',
                        headers: {
                            "Authorization": "Bearer " + token
                        }
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (!data.status) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Export Failed',
                                text: data.message
                            });
                            return;
                        }

                        // SUCCESS
                        Swal.fire({
                            icon: 'success',
                            title: 'Export Ready',
                            text: 'Download Excel file'
                        }).then(() => {
                            window.location.href = data.file_url; // download
                        });
                    })
                    .catch(err => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Unexpected Error',
                            text: 'Something went wrong.'
                        });
                    });
            });




        });
    </script>
@endpush
