@extends('layout.app')

@section('title', 'Purchase List')

@section('content')
    <style>
        #DataTables_Table_0_info {
            float: left;
        }

        .table-scroll-top {
            display: none;
        }

        .input-groupicon.me-2.dateFilterclass {
            width: 105px !important;
        }

        .form-control {
            color: #595b5d !important;
        }

        .form-group {
            margin-bottom: 8px !important;
        }

        /* Responsive breakpoints for all screen sizes */

        /* Extra small devices (phones, less than 576px) */
        @media screen and (max-width: 575.98px) {
            /* Filter Section Mobile Styles */
            /* .table-top {
                        padding: 10px 0;
                    }

                    .table-top > div {
                        flex-direction: column !important;
                        gap: 10px !important;
                    } */

            .search-set {
                width: 100% !important;
                margin: 0 0 10px 0 !important;
            }

            .search-input {
                width: 100%;
            }

            /* .search-input .btn-searchset {
                        width: 100%;
                        padding: 10px;
                    } */
            /*
                    .table-top .me-2 {
                        margin-right: 0 !important;
                        margin-bottom: 8px;
                    } */

            /* Total display on mobile */
            /* .table-top > div > div[style*="border"] {
                        width: 100% !important;
                        text-align: center;
                        padding: 8px !important;
                        margin: 0 0 10px 0 !important;
                    } */

            /* Filter dropdowns - full width on mobile */
            .input-groupicon {
                width: 100% !important;
                margin: 0 0 10px 0 !important;
            }

            .input-groupicon select,
            .input-groupicon input {
                width: 100% !important;
                font-size: 14px;
            }

            .dateFilterclass {
                width: 100% !important;
            }

            /* Export buttons - full width on mobile */
            /* .table-top .d-flex.gap-2 {
                        width: 100% !important;
                        flex-direction: column;
                        gap: 8px !important;
                    }

                    .table-top .d-flex.gap-2 button {
                        width: 100% !important;
                        padding: 10px;
                        font-size: 14px;
                    } */

            .table-responsive {
                display: block !important;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                width: 100% !important;
            }

            .datanew {
                width: 100% !important;
                table-layout: fixed;
            }

            /* Make Invoice Number column take more space */
            .datanew th:nth-child(1),
            .datanew td:nth-child(1) {
                width: 70% !important;
                text-align: left;
            }

            /* Make Details column take less space */
            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                width: 30% !important;
                text-align: center;
                display: table-cell !important;
            }

            .mobile-order-card {
                display: none;
            }

            /* Hide filter inputs card on mobile */
            #filter_inputs {
                display: none;
            }

            .datanew {
                font-size: 11px;
            }

            .datanew th,
            .datanew td {
                padding: 6px 3px;
            }

            /* Show only Invoice Number and Details - hide all other columns including Action */
            .datanew th:nth-child(3),
            .datanew td:nth-child(3),
            .datanew th:nth-child(4),
            .datanew td:nth-child(4),
            .datanew th:nth-child(5),
            .datanew td:nth-child(5),
            .datanew th:nth-child(6),
            .datanew td:nth-child(6),
            .datanew th:nth-child(7),
            .datanew td:nth-child(7),
            .datanew th:nth-child(8),
            .datanew td:nth-child(8) {
                display: none;
            }

            /* Center Details column */
            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                text-align: center;
                display: table-cell !important;
            }
        }

        /* Small devices (landscape phones, 576px and up) */
        @media screen and (min-width: 576px) and (max-width: 767.98px) {
            /* Filter Section Small Mobile Styles */
            /* .table-top {
                        padding: 12px 0;
                    }

                    .table-top > div {
                        flex-wrap: wrap !important;
                        gap: 10px !important;
                    } */

            .search-set {
                width: 100% !important;
                margin: 0 0 10px 0 !important;
            }

            /* Total and filters in a row */
            /* .table-top > div > div[style*="border"] {
                        flex: 0 0 auto;
                        margin: 0 0 10px 0 !important;
                    } */

            .input-groupicon {
                flex: 0 0 calc(50% - 5px);
                margin: 0 0 10px 0 !important;
            }

            .input-groupicon select,
            .input-groupicon input {
                width: 100% !important;
                font-size: 14px;
            }

            .dateFilterclass {
                width: 100% !important;
            }

            /* Export buttons side by side */
            /* .table-top .d-flex.gap-2 {
                        width: 100% !important;
                        flex-direction: row;
                        gap: 10px !important;
                    }

                    .table-top .d-flex.gap-2 button {
                        flex: 1;
                        padding: 10px;
                        font-size: 14px;
                    } */

            .table-responsive {
                display: block !important;
                overflow-x: auto;
                width: 100% !important;
            }

            .datanew {
                width: 100% !important;
                table-layout: fixed;
            }

            /* Make columns take appropriate space */
            .datanew th:nth-child(1),
            .datanew td:nth-child(1) {
                width: 50% !important;
            }

            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                width: 20% !important;
                text-align: center;
                display: table-cell !important;
            }

            .datanew th:nth-child(3),
            .datanew td:nth-child(3) {
                width: 30% !important;
            }

            .mobile-order-card {
                display: none;
            }

            /* Hide filter inputs card on small mobile */
            #filter_inputs {
                display: none;
            }

            .datanew {
                font-size: 12px;
            }

            .datanew th,
            .datanew td {
                padding: 8px 4px;
            }

            /* Show Invoice Number, Details, Date, Vendor - hide Action and other columns */
            .datanew th:nth-child(5),
            .datanew td:nth-child(5),
            .datanew th:nth-child(6),
            .datanew td:nth-child(6),
            .datanew th:nth-child(7),
            .datanew td:nth-child(7),
            .datanew th:nth-child(8),
            .datanew td:nth-child(8) {
                display: none;
            }

            /* Center Details column */
            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                text-align: center;
                display: table-cell !important;
            }
        }

        /* Medium devices (tablets, 768px and up to 991px) */
        @media screen and (min-width: 768px) and (max-width: 991.98px) {
            .table-responsive {
                display: block !important;
                overflow-x: auto;
                width: 100% !important;
            }

            .mobile-order-card {
                display: none;
            }

            .datanew {
                font-size: 13px;
                width: 100% !important;
                table-layout: auto;
            }

            .datanew th,
            .datanew td {
                padding: 8px 6px;
            }

            /* Hide Details column on tablets */
            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                display: none !important;
            }

            /* Show all other columns on tablets - no hiding */
            /* All columns (Invoice Number, Date, Vendor Name, Grand Total, Purchase Status, Payment Status, Action) will be visible */

            /* Hide expandable rows on tablets */
            .order-details-row {
                display: none !important;
            }
        }

        /* Large devices (desktops, 992px and up) */
        @media screen and (min-width: 992px) {
            .table-responsive {
                display: block !important;
                overflow-x: auto;
                width: 100% !important;
            }

            .mobile-order-card {
                display: none;
            }

            .datanew {
                font-size: 14px;
                width: 100% !important;
            }

            .datanew th,
            .datanew td {
                padding: 12px 10px;
            }

            /* Hide Details column (2nd column) on desktop (992px and above) */
            .datanew th:nth-child(2),
            .datanew td:nth-child(2) {
                display: none !important;
            }

            /* Hide expandable rows on larger screens */
            .order-details-row {
                display: none !important;
            }
        }

        /* Expandable row details - available for all screen sizes */
        .order-details-row {
            display: none;
        }

        .order-details-row.show {
            display: table-row;
        }

        /* Expandable content styles - available for all screen sizes */
        .order-details-content {
            padding: 15px;
            background: #fff;
            border-top: 2px solid #e0e0e0;
        }

        .order-details-list {
            margin-bottom: 15px;
        }

        .order-detail-row-simple {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .order-detail-row-simple:last-of-type {
            border-bottom: none;
        }

        .order-detail-label-simple {
            font-weight: 600;
            color: #595b5d;
            font-size: 14px;
        }

        .order-detail-value-simple {
            color: #1b2850;
            font-size: 14px;
            text-align: right;
        }

        .mobile-action-buttons-simple {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: flex-start;
            padding-top: 15px;
            border-top: 1px solid #e0e0e0;
        }

        .btn-icon-mobile,
        button.btn-icon-mobile {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #1b2850;
            background: transparent;
            transition: all 0.3s;
            border: 2px solid #1b2850;
            cursor: pointer;
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        button.btn-icon-mobile {
            border: 2px solid #1b2850;
            background: transparent;
        }

        .btn-icon-mobile:hover {
            background: #1b2850;
            color: white;
            transform: scale(1.1);
        }

        .btn-icon-mobile i {
            font-size: 16px;
        }

        .btn-icon-mobile.btn-history i {
            font-size: 18px;
        }

        .mobile-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            text-transform: capitalize;
        }

        .btn-icon-mobile.btn-view i,
        .btn-icon-mobile.btn-edit i,
        .btn-icon-mobile.btn-download i,
        .btn-icon-mobile.btn-print i,
        .btn-icon-mobile.btn-delete i,
        .btn-icon-mobile.btn-payment i {
            font-size: 16px;
        }

        /* Toggle button styles - available for all screen sizes */
        .mobile-toggle-btn-table {
            background: #ff9f43;
            border: none;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: white;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.3s;
        }

        .mobile-toggle-btn-table:hover {
            background: #ff8c2e;
        }

        .mobile-toggle-btn-table.minus {
            background: #dc3545;
        }

        .mobile-toggle-btn-table.minus:hover {
            background: #c82333;
        }

        /* Additional responsive adjustments for larger screens */
        @media screen and (min-width: 992px) {
            .order-details-content {
                padding: 20px;
            }

            .order-detail-label-simple,
            .order-detail-value-simple {
                font-size: 15px;
            }

            .btn-icon-mobile {
                width: 42px;
                height: 42px;
            }

            .btn-icon-mobile i {
                font-size: 17px;
            }
        }

        @media screen and (max-width: 768px) {
            .table-scroll-top {
                display: block;
            }
        }
    </style>
    @if (session('error'))
        <div class="alert alert-danger" id="error-message">
            {{ session('error') }}
        </div>

        <style>
            .fade-out {
                opacity: 1;
                transition: opacity 0.5s ease-out;
            }

            .fade-out.hidden {
                opacity: 0;
            }
        </style>

        <script>
            setTimeout(function() {
                let alert = document.getElementById('error-message');
                if (alert) {
                    alert.classList.add('hidden'); // Triggers the fade-out transition
                    // Remove the element from DOM after fadeout (optional)
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500); // match the CSS transition duration (0.5s)
                }
            }, 4000);
        </script>
    @endif
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Purchases List</h4>
                <!-- <h6>Manage your purchases</h6> -->
            </div>
            <div class="page-btn">
                @if (app('hasPermission')(3, 'add'))
                    <a href="{{ route('purchase.add') }}" class="btn btn-sm btn-added">
                        <img src="{{ env('ImagePath') . 'admin/assets/img/icons/plus.svg' }}" alt="img">New Purchases
                    </a>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-top mb-3">
                    <div class="row w-100 align-items-center">
                        <!-- Search -->
                        <div class="col-md-2 col-12 d-flex align-items-center mb-1 mb-md-0">
                            <div class="search-set w-100">
                                <div class="search-path"></div>
                                <div class="search-input d-flex align-items-center">
                                    <a class="btn btn-searchset">
                                        <img src="{{ env('ImagePath') . 'admin/assets/img/icons/search-white.svg' }}"
                                            alt="img">
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Month Filter -->
                        <div class="col-md-2 col-6">
                            <!-- Total (only for admin/sub-admin) -->
                            {{-- @if (in_array(auth()->user()->role, ['admin', 'sub-admin']))
                                <div class="mb-1"
                                    style="color: #1b2850;border: 1px solid #0d1b3e;border-radius: 5px;padding: 4px;font-size: 14px;     font-weight: bold;">
                                    Total: <span style="color: #ff9f43" id="filtered-total">₹0.00</span>
                                </div>
                            @endif --}}

                            @if (in_array(auth()->user()->role, ['admin', 'sub-admin']))
                                <div class="mb-1"
                                    style="color: #1b2850;border: 1px solid #0d1b3e;border-radius: 5px;padding: 4px;font-size: 14px;     font-weight: bold;">
                                    Total: <span style="color: #ff9f43" id="filtered-total">₹0.00</span>
                                </div>
                            @endif


                        </div>


                        <!-- Month Filter -->
                        <div class="col-md-2 col-6">
                            <div class="mb-1">
                                <!-- <label for="filter-month" class="form-label">Month</label> -->
                                <select id="filter-month" class="form-control form-control-sm">
                                    <option value="">-- Select Month --</option>
                                    <option value="01">January</option>
                                    <option value="02">February</option>
                                    <option value="03">March</option>
                                    <option value="04">April</option>
                                    <option value="05">May</option>
                                    <option value="06">June</option>
                                    <option value="07">July</option>
                                    <option value="08">August</option>
                                    <option value="09">September</option>
                                    <option value="10">October</option>
                                    <option value="11">November</option>
                                    <option value="12">December</option>
                                </select>
                            </div>
                        </div>

                        <!-- Year Filter -->
                        <div class="col-md-2 col-6">
                            <div class="mb-1">
                                <!-- <label for="filter-year" class="form-label">Year</label> -->
                                <select id="filter-year" class="form-control form-control-sm">
                                    <option value="">-- Select Year --</option>
                                </select>
                            </div>
                        </div>

                        <!-- Date -->
                        <div class="col-md-2 col-6">
                            <!-- <div class="form-group mb-0"> -->
                            <!-- <label for="filter-date" class="form-label">Date</label> -->
                            <input type="text" id="filter-date" placeholder="Choose Date"
                                class="datetimepicker form-control form-control-sm">
                            <!-- </div> -->
                        </div>

                        <!-- Export Buttons -->
                        <div class="col-md-2 col-12 d-flex justify-content-md-end gap-2 mb-1">
                            <button id="exportAllChallan" class="btn btn-sm btn-success w-100">
                                <i class="fas fa-file-excel"></i> Excel
                            </button>
                            <button id="exportPdf" class="btn btn-sm btn-danger w-100">
                                <i class="fas fa-file-pdf"></i> PDF
                            </button>
                        </div>
                    </div>
                </div>


                {{-- <div class="table-top mb-3">
                    <div class="align-items-center d-flex flex-wrap gap-0 justify-content-end w-100">

                        <!-- Search -->
                        <div class="align-items-center d-flex me-2 me-auto search-set">
                            <div class="search-path"></div>
                            <div class="search-input">
                                <a class="btn btn-searchset">
                                    <img src="{{ env('ImagePath') . 'admin/assets/img/icons/search-white.svg' }}"
                                        alt="img">
                                </a>
                            </div>
                        </div>

                        <!-- Total (only for admin/sub-admin) -->
                        @if (in_array(auth()->user()->role, ['admin', 'sub-admin']))
                            <div class="me-2"
                                style="color: #1b2850;border: 3px solid #0d1b3e;border-radius: 5px;padding: 4px;font-size: 14px;     font-weight: bold;">
                                Total: <span style="color: #ff9f43" id="filtered-total">₹0.00</span>
                            </div>
                        @endif

                        <!-- Year Filter -->
                        <div class="input-groupicon me-2">
                            <select id="filter-year" class="form-control form-control-sm">
                                <option value="">-- Select Year --</option>
                            </select>
                        </div>

                        <!-- Month Filter -->
                        <div class="input-groupicon me-2">
                            <select id="filter-month" class="form-control form-control-sm">
                                <option value="">-- Select Month --</option>
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        </div>

                        <!-- Date Filter -->
                        <div class="input-groupicon me-2 dateFilterclass">
                            <input type="text" id="filter-date" placeholder="Choose Date"
                                class="datetimepicker form-control form-control-sm">
                        </div>

                        <!-- Customer Filter -->
                        <div class="input-groupicon me-2">
                            <select id="filter-customer" class="form-control form-control-sm">
                                <option value="">-- Select Vendor --</option>
                            </select>
                        </div>

                        <!-- Export Buttons -->
                        <div class="d-flex align-items-center gap-2">
                            <button id="exportAllChallan" class="btn btn-sm btn-success">
                                <i class="fas fa-file-excel"></i> Export Excel
                            </button>
                            <button id="exportPdf" class="btn btn-sm btn-danger">
                                <i class="fas fa-file-pdf"></i> Export PDF
                            </button>
                        </div>

                    </div>
                </div>
 --}}

                <!-- Filter Inputs Card -->
                <div class="card" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <input type="text" placeholder="Enter Name" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <input type="text" placeholder="Enter Reference No" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <select class="form-select">
                                        <option>Completed</option>
                                        <option>Paid</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group d-flex justify-content-end">
                                    <a class="btn btn-filters ms-auto">
                                        <img src="admin/assets/img/icons/search-whites.svg" alt="img">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Orders Table -->
                <div class="table-scroll-top"
                    style="overflow-x: auto; overflow-y: hidden; height: 20px; margin-bottom: 5px;">
                    <div style="height: 1px;"></div> <!-- Adjust width to match your table width -->
                </div>

                <div class="table-responsive mt-3" style="overflow-x: auto;">
                    <table class="table datanew" id="order-table" style="max-width: 2000px;">
                        <thead>
                            <tr>
                                <th>Invoice Number</th>
                                <th class="text-center">Details</th>
                                <th>Date</th>
                                <th>Vendor Name</th>
                                <th>Grand Total</th>
                                <th>Purchase Status</th>
                                <th>Payment Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- JS will populate this -->
                        </tbody>

                    </table>
                </div>

                <!-- Mobile Order Cards -->
                <div class="mobile-order-card mt-3" id="mobile-order-container">
                    <!-- JS will populate this -->
                </div>


            </div>
        </div>

    </div>
    <form id="makePaymentForm">
        <div class="modal fade" id="makePaymentModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">

                        <div class="text-end mb-3">
                            <button type="button" class="btn btn-sm btn-cancel text-white" id="viewHistoryBtn">View
                                Payment History</button>
                        </div>

                        <!-- ✅ Payment History Container -->
                        <div id="paymentHistoryBox" class="border p-2 rounded bg-white d-none mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0">Payment History</h6>

                                <!-- 👇 Visible Close Button -->
                                <button type="button" class="btn btn-sm btn-danger" id="closeHistoryBtn">
                                    &times; <!-- This renders an “×” symbol -->
                                </button>
                            </div>

                            <ul id="paymentHistoryList" class="list-unstyled mb-0"
                                style="max-height: 200px; overflow-y: auto;">
                                <!-- Populated via JavaScript -->
                            </ul>
                        </div>



                        <div class="border p-2 rounded bg-light">
                            <strong>Total Amount:</strong> ₹<span id="emiTotal"></span><br>
                            <strong>Remaining Amount:</strong> ₹<span id="remainingAmountDisplay">0.00</span>

                        </div>

                        <!-- ✅ View Payment History Button -->



                        <br>

                        <!-- Payment Method -->
                        <div class="mb-3" id="paymentMethodDiv">
                            <label for="paymentMethodSelect" class="form-label">Select Payment Method</label>
                            <select class="form-select" id="paymentMethodSelect" name="payment_method">
                                <option value="" selected disabled>Select</option>
                                <option value="cash">Cash</option>
                                <option value="online">Online</option>
                                <option value="cash_online">Cash + Online</option>

                            </select>
                            <div class="text-danger" id="paymentMethodError"></div>
                        </div>

                        <div class="mb-3 d-none" id="cashOnlineTypeDiv">
                            <label for="cashOnlineTypeSelect" class="form-label">Select Cash + Online Type</label>
                            <select class="form-select" id="cashOnlineTypeSelect" name="cash_online_type">
                                <option value="" selected disabled>Select</option>
                                <option value="cash_online_fully">Cash + Online Fully</option>
                                <option value="cash_online_partially">Cash + Online Partially</option>
                            </select>
                            <div class="text-danger" id="cashOnlineTypeError"></div>
                        </div>

                        <!-- Fully Cash + Online -->
                        <!-- Fully Cash + Online -->
                        <div class="mb-3 d-none" id="fullyCashOnlineFields">
                            <label>Cash Amount</label>
                            <input type="number" id="cashOnlineFullAmount" name="fully_cash_amount"
                                class="form-control" min="0" step="0.01">
                            <div class="text-danger" id="cashOnlineFullAmountError"></div>
                            <label class="mt-2">Online Amount</label>
                            <input type="number" id="upiOnlineFullAmount" name="full_online_amount"
                                class="form-control" readonly>
                            <div class="text-danger" id="upiOnlineFullAmountError"></div>
                        </div>

                        <!-- Partial Cash + Online -->
                        <div class="mb-3 d-none" id="partialCashOnlineFields">
                            <label>Cash Amount</label>
                            <input type="number" id="cashOnlinePartialAmount" name="cash_amount" class="form-control"
                                min="0" step="0.01">
                            <div class="text-danger" id="cashOnlinePartialAmountError"></div>
                            <label class="mt-2">Online Amount</label>
                            <input type="number" id="upiOnlinePartialAmount" name="online_amount" class="form-control"
                                min="0" step="0.01">
                            <div class="text-danger" id="upiOnlinePartialAmountError"></div>
                            <label class="mt-2">Remaining Amount</label>
                            <input type="number" id="remainingCashOnlineAmount" name="remaining_amount"
                                class="form-control" readonly>
                        </div>







                        <div class="mb-3 d-none" id="onlineTypeDiv">
                            <label for="onlineTypeSelect" class="form-label">Select Online Type</label>
                            <select class="form-select" id="onlineTypeSelect" name="online_type">
                                <option value="" selected disabled>Select</option>
                                <option value="online_fully">Online Fully</option>
                                <option value="online_partially">Online Partially</option>
                            </select>
                            <div class="text-danger" id="onlineTypeError"></div>
                        </div>

                        <!-- Paid Type Dropdown (Hidden by default) -->
                        <div class="mb-3 d-none" id="paidTypeDiv">
                            <label for="paidTypeSelect" class="form-label">Paid Type</label>
                            <select class="form-select" id="paidTypeSelect" name="paid_type">
                                <option value="" selected disabled>Select</option>
                                <option value="cash_partially">Cash Partially</option>
                                <option value="cash_fully">Cash Fully</option>
                            </select>
                            <div class="text-danger" id="paidTypeError"></div>
                        </div>

                        <!-- UPI Amount Input -->
                        <div class="mb-3 d-none" id="upiAmountDiv">
                            <label for="upiAmountInput" class="form-label">Online Amount</label>
                            <input type="number" class="form-control" id="upiAmountInput" name="upi_online_amount"
                                readonly>
                            <div class="text-danger" id="upiAmountError"></div>
                        </div>



                        <!-- Partially Paid Fields -->
                        <div class="mb-3 d-none" id="partialPaidFields">
                            <label for="partialAmount" class="form-label">Enter Amount</label>
                            <input type="number" class="form-control mb-2" id="partialAmount" name="amount"
                                min="1" step="0.01">
                            <div class="text-danger" id="partialAmountError"></div>

                            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                                <div style="flex: 1;">
                                    <label for="pendingAmount" class="form-label">Pending Amount</label>
                                    <input type="number" class="form-control" id="pendingAmount"
                                        name="cash_pending_amount" readonly>
                                </div>

                            </div>
                        </div>

                        <!-- Fully Paid Fields -->
                        <div class="mb-3 d-none" id="fullyPaidFields">
                            <label class="form-label">Cash Amount</label>
                            <input type="number" class="form-control" id="cashAmount" name="cashAmount" min="0"
                                step="0.01">
                            <div class="text-danger" id="cashAmountError"></div>
                        </div>













                        <!-- Cleaned Hidden Inputs (no duplicate name attributes) -->
                        <input type="hidden" id="paymentJobCardId" name="purchase_id">
                        <input type="hidden" id="remainingAmountHidden" name="remaining_amount">
                        <input type="hidden" id="paymentMethodHidden" name="payment_type">




                        <div class="text-end">
                            <button type="submit" class="btn btn-submit text-white"
                                style="background-color: #ff9f43;">Submit Payment</button>
                            <button type="button" class="btn btn-secondary btn-cancel"
                                data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- Global Payment History Modal -->
    <div class="modal fade" id="paymentHistoryModal" tabindex="-1" aria-labelledby="paymentHistoryLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentHistoryLabel">Payment History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul id="globalPaymentHistoryList" class="list-group"></ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script>
        // Global variables
        var purchaseTable;

        // Helper function to build expandable row content
        function buildPurchaseExpandableRowContent(purchase, currencySymbol, currencyPosition) {
            const amount = parseFloat(purchase.grand_total || 0).toFixed(2);
            const displayAmount = currencyPosition === 'right' ?
                amount + currencySymbol : currencySymbol + amount;

            let actionBtns = '';

            // Make Payment button (orange button) - only if there's remaining amount
            if (parseFloat(purchase.remaining_amount || 0) > 0) {
                actionBtns += `<button type="button" class="btn btn-sm btn-primary me-3 make-payment-btn" 
                    data-bs-toggle="modal" data-bs-target="#makePaymentModal"
                    data-id="${purchase.id}" 
                    data-amount="${purchase.remaining_amount}" 
                    data-method="${purchase.payment_mode || ''}"
                    data-total-amount="${purchase.grand_total || 0}" 
                    data-remaining-amount="${purchase.remaining_amount}"
                    style="background-color: #ff9f43; border-color: #ff9f43; color: white;">
                    Make Payment
                </button>`;
            }

            // History icon button
            actionBtns += `<button class="btn-icon-mobile btn-history open-history" data-id="${purchase.id}" title="Payment History">
                <i class="fas fa-history"></i>
            </button>`;

            // Download icon button
            @if (app('hasPermission')(3, 'view'))
                actionBtns += `<a class="btn-icon-mobile btn-download" href="/print-purchase/${purchase.id}" title="Download Invoice">
                    <i class="fas fa-download"></i>
                </a>`;
            @endif

            // Print icon button
            @if (app('hasPermission')(3, 'view'))
                actionBtns += `<a class="btn-icon-mobile btn-print" href="javascript:void(0);" onclick="window.open('/purchase/invoice/pdf/' + ${purchase.id});" title="Print Invoice">
                    <i class="fas fa-print"></i>
                </a>`;
            @endif

            // Delete icon button
            @if (app('hasPermission')(3, 'delete'))
                actionBtns += `<a class="btn-icon-mobile btn-delete delete-order" href="javascript:void(0);" data-id="${purchase.id}" title="Delete">
                    <i class="fas fa-trash"></i>
                </a>`;
            @endif

            return `
                <td colspan="8" class="order-details-content">
                    <div class="order-details-list">
                        <div class="order-detail-row-simple">
                            <span class="order-detail-label-simple">Date:</span>
                            <span class="order-detail-value-simple">${purchase.invoice_date || purchase.date || purchase.created_at || 'N/A'}</span>
                        </div>
                        <div class="order-detail-row-simple">
                            <span class="order-detail-label-simple">Vendor Name:</span>
                            <span class="order-detail-value-simple">${purchase.vendor_name || 'N/A'}</span>
                        </div>
                        <div class="order-detail-row-simple">
                            <span class="order-detail-label-simple">Purchase Status:</span>
                            <span class="order-detail-value-simple">
                                <span class="mobile-badge bg-lightgreen">${purchase.purchase_status || purchase.status || 'N/A'}</span>
                            </span>
                        </div>
                        <div class="order-detail-row-simple">
                            <span class="order-detail-label-simple">Payment Status:</span>
                            <span class="order-detail-value-simple">
                                <span class="mobile-badge bg-lightgreen">${purchase.payment_status || 'N/A'}</span>
                            </span>
                        </div>
                        <div class="order-detail-row-simple">
                            <span class="order-detail-label-simple">Grand Total:</span>
                            <span class="order-detail-value-simple" style="font-weight: bold; color: #ff9f43;">${displayAmount}</span>
                        </div>
                        ${parseFloat(purchase.remaining_amount || 0) > 0 ? `
                                <div class="order-detail-row-simple">
                                    <span class="order-detail-label-simple">Remaining:</span>
                                    <span class="order-detail-value-simple" style="color: #dc3545; font-weight: bold;">
                                        ${currencySymbol}${parseFloat(purchase.remaining_amount || 0).toFixed(2)}
                                    </span>
                                </div>
                                ` : ''}
                    </div>
                    <div class="mobile-action-buttons-simple">
                        ${actionBtns}
                    </div>
                </td>
            `;
        }

        // Toggle function for table rows - must be global
        window.togglePurchaseRowDetails = function(purchaseId) {
            // Find the button that was clicked
            const btn = $(`.mobile-toggle-btn-table[data-purchase-id="${purchaseId}"]`);
            if (btn.length === 0) {
                console.error('Toggle button not found for purchase:', purchaseId);
                return;
            }

            const row = btn.closest('tr');
            let detailsRow = row.next(`tr.order-details-row[data-purchase-id="${purchaseId}"]`);
            const icon = btn.find('.toggle-icon');

            // If expandable row doesn't exist, create it
            if (detailsRow.length === 0) {
                const purchaseData = window.purchaseDataMap && window.purchaseDataMap[purchaseId];
                if (purchaseData) {
                    detailsRow = $('<tr>')
                        .addClass('order-details-row')
                        .attr('data-purchase-id', purchaseId)
                        .html(buildPurchaseExpandableRowContent(purchaseData, purchaseData.currencySymbol, purchaseData
                            .currencyPosition));
                    row.after(detailsRow);
                } else {
                    console.error('Purchase data not found for purchase:', purchaseId);
                    return;
                }
            }

            if (detailsRow.hasClass('show')) {
                detailsRow.removeClass('show');
                btn.removeClass('minus');
                icon.text('+');
            } else {
                detailsRow.addClass('show');
                btn.addClass('minus');
                icon.text('−');
            }
        }

        // Function to add expandable rows - must be global
        window.addPurchaseExpandableRows = function(dt) {
            if (!dt) return;

            const currentWidth = $(window).width();
            const isMobileOrTablet = currentWidth <= 1024;

            if (!isMobileOrTablet) {
                // Remove expandable rows on desktop
                $('tr.order-details-row').remove();
                return;
            }

            dt.rows().every(function() {
                const row = this.node();
                const toggleBtn = $(row).find('.mobile-toggle-btn-table');
                if (toggleBtn.length > 0) {
                    const purchaseId = toggleBtn.data('purchase-id');
                    const purchaseData = window.purchaseDataMap && window.purchaseDataMap[purchaseId];
                    if (purchaseData && !$(row).next('tr.order-details-row[data-purchase-id="' + purchaseId +
                            '"]').length) {
                        const expandableRow = $('<tr>')
                            .addClass('order-details-row')
                            .attr('data-purchase-id', purchaseId)
                            .html(buildPurchaseExpandableRowContent(purchaseData, purchaseData.currencySymbol,
                                purchaseData.currencyPosition));
                        $(row).after(expandableRow);
                    }
                }
            });
        };

        // Function to calculate total for visible rows - must be global
        function calculatePurchaseFilteredTotal() {
            if (!purchaseTable) {
                purchaseTable = $('.datanew').DataTable();
            }

            let total = 0;

            // Find the Grand Total column index by header name
            let totalColumnIndex = -1;
            purchaseTable.columns().every(function() {
                const header = $(this.header());
                if (header.text().trim() === 'Grand Total') {
                    totalColumnIndex = this.index();
                    return false; // break
                }
            });

            // If column not found by name, use index 4 as fallback
            if (totalColumnIndex === -1) {
                totalColumnIndex = 4;
            }

            purchaseTable.rows({
                filter: 'applied'
            }).every(function() {
                const row = this.data();
                if (row[totalColumnIndex]) {
                    const amountText = row[totalColumnIndex];
                    const rawAmount = parseFloat(amountText.replace(/[^0-9.-]+/g, '')) || 0;
                    total += rawAmount;
                }
            });

            const currencySymbol = "₹";
            $('#filtered-total').text(`${currencySymbol}${total.toFixed(2)}`);
        }

        $(document).ready(function() {
            // Initialize table after data is loaded
            let currentYear = new Date().getFullYear();
            for (let i = 0; i < 4; i++) {
                let year = currentYear - i;
                $("#filter-year").append(`<option value="${year}">${year}</option>`);
            }


            // ✅ On dropdown change → filter table
            $("#filter-customer").off('change').on("change", function() {
                let selectedCustomer = $(this).val();
                if (purchaseTable) {
                    if (selectedCustomer) {
                        purchaseTable.column(3) // column index for vendor name (after Details column)
                            .search("^" + selectedCustomer + "$", true, false) // exact match
                            .draw();
                    } else {
                        purchaseTable.column(3).search("").draw(); // clear filter
                    }
                    setTimeout(() => calculatePurchaseFilteredTotal(), 100);
                }
            });


            // Month short names
            const monthNames = {
                "01": "Jan",
                "02": "Feb",
                "03": "Mar",
                "04": "Apr",
                "05": "May",
                "06": "Jun",
                "07": "Jul",
                "08": "Aug",
                "09": "Sep",
                "10": "Oct",
                "11": "Nov",
                "12": "Dec"
            };

            // Apply month/year filter whenever dropdown changes
            $("#filter-month, #filter-year").off('change').on("change", function() {
                applyMonthYearFilter();
            });

            function applyMonthYearFilter() {
                const selectedMonth = $("#filter-month").val();
                const selectedYear = $("#filter-year").val();

                let regex = "";
                if (selectedMonth && selectedYear) {
                    regex = `${monthNames[selectedMonth]}.*${selectedYear}`;
                } else if (selectedMonth) {
                    regex = `${monthNames[selectedMonth]}`;
                } else if (selectedYear) {
                    regex = `${selectedYear}`;
                }

                console.log("Applied Filter Regex:", regex);

                // Use the DataTable instance
                if (purchaseTable) {
                    purchaseTable.column(2).search(regex, true, false).draw(); // Date column is now index 2
                    setTimeout(() => calculatePurchaseFilteredTotal(), 100);
                }
            }

            // alert("Purchase List Page Loaded");
            const authToken = localStorage.getItem("authToken");
            const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
            // console.log("Selected Sub Admin ID:", selectedSubAdminId);




            $(document).on('click', '.make-payment-btn', function() {
                let jobCardId = $(this).data('id');
                let totalAmount = $(this).data('total-amount');
                let remainingAmount = $(this).data('remaining-amount');
                let method = $(this).data('method') || '';

                // ✅ Fill modal hidden inputs + text spans
                $('#paymentJobCardId').val(jobCardId);
                $('#emiTotal').text(parseFloat(totalAmount).toFixed(2));
                $('#remainingAmountDisplay').text(parseFloat(remainingAmount).toFixed(2));
                $('#remainingAmountHidden').val(remainingAmount);
                $('#paymentMethodHidden').val(method);

                // ✅ Reset payment method dropdown to default
                $('#paymentMethodSelect').val('');

                // ✅ Hide history box initially
                $('#paymentHistoryBox').addClass('d-none');
                $('#paymentHistoryList').html('');

                // ✅ Bind View History button
                $('#viewHistoryBtn').off('click').on('click', function() {
                    $.ajax({
                        url: '/api/purchase/payment-history/' + jobCardId,
                        method: 'GET',
                        headers: {
                            "Authorization": "Bearer " + authToken
                        },
                        success: function(response) {
                            const history = response.data;

                            if (!history || history.length === 0) {
                                $('#paymentHistoryList').html(
                                    '<li>No payment history found.</li>');
                            } else {
                                let historyHtml = '';
                                history.forEach(function(payment) {
                                    historyHtml += `
                                                                            <li class="mb-2">
                                                                                <strong>Amount:</strong> ₹${parseFloat(payment.payment_amount).toFixed(2)}<br>
                                                                                <strong>Date:</strong> ${payment.payment_date}<br>
                                                                                <strong>Method:</strong> ${payment.payment_method}<br>
                                                                                <strong>Payment Type:</strong> ${payment.payment_type ? payment.payment_type : 'N/A'}<br>
                                                                                ${payment.payment_type === 'emi' ? `<strong>EMI Months:</strong> ${payment.emi_month || 0}<br>` : ''}
                                                                            </li>
                                                                            <hr class="my-1"/>
                                                                        `;
                                });
                                $('#paymentHistoryList').html(historyHtml);
                            }

                            $('#paymentHistoryBox').removeClass('d-none');
                        },
                        error: function() {
                            $('#paymentHistoryList').html(
                                '<li class="text-danger">Failed to load payment history.</li>'
                            );
                            $('#paymentHistoryBox').removeClass('d-none');
                        }
                    });
                });

                // ✅ Close history
                $('#closeHistoryBtn').off('click').on('click', function() {
                    $('#paymentHistoryBox').addClass('d-none');
                });
            });

            $('#paymentMethodSelect').on('change', function() {
                let method = $(this).val();

                // Hide all optional sections first
                $('#cashOnlineTypeDiv, #fullyCashOnlineFields, #partialCashOnlineFields, #onlineTypeDiv, #paidTypeDiv, #upiAmountDiv, #partialPaidFields, #fullyPaidFields')
                    .addClass('d-none');

                if (method === 'cash') {
                    $('#paidTypeDiv').removeClass('d-none'); // Show paid type options

                } else if (method === 'online') {
                    $('#onlineTypeDiv').removeClass('d-none'); // Show online type dropdown

                } else if (method === 'cash_online') {
                    $('#cashOnlineTypeDiv').removeClass('d-none'); // Show Cash + Online type dropdown
                }
            });

            $('#paidTypeSelect').on('change', function() {
                let type = $(this).val();
                let remaining = parseFloat($('#remainingAmountHidden').val()) || 0;

                // Hide both sections
                $('#partialPaidFields, #fullyPaidFields').addClass('d-none');

                // Disable all inputs first
                $('#partialPaidFields input, #fullyPaidFields input').prop('disabled', true);

                if (type === 'cash_partially') {
                    // Show partial fields
                    $('#partialPaidFields').removeClass('d-none');
                    $('#partialPaidFields input').prop('disabled', false);

                    // Clear & reset values
                    $('#partialAmount').val('');
                    $('#pendingAmount').val(remaining.toFixed(2));

                    // Remove any full cash amount
                    $('#cashAmount').val('').prop('readonly', false).prop('disabled', true);

                    // Live calculation for pending
                    $('#partialAmount').off('input').on('input', function() {
                        let entered = parseFloat($(this).val()) || 0;
                        let newPending = Math.max(remaining - entered, 0);
                        $('#pendingAmount').val(newPending.toFixed(2));
                    });

                } else if (type === 'cash_fully') {
                    // Show fully fields
                    $('#fullyPaidFields').removeClass('d-none');
                    $('#fullyPaidFields input').prop('disabled', false);

                    // Fill full amount & disable editing
                    $('#cashAmount').val(remaining.toFixed(2)).prop('readonly', true);

                    // Reset partial fields
                    $('#partialAmount, #pendingAmount').val('');
                    $('#partialPaidFields input').prop('disabled', true);
                }
            });


            // ✅ Handle Online Type (when Payment Method = Online)
            $('#onlineTypeSelect').on('change', function() {
                let type = $(this).val();
                let remaining = parseFloat($('#remainingAmountHidden').val()) || 0;

                // Hide both sections
                $('#upiAmountDiv, #partialPaidFields').addClass('d-none');
                // Disable all inputs first
                $('#upiAmountDiv input, #partialPaidFields input').prop('disabled', true);

                if (type === 'online_partially') {
                    // Show partial fields
                    $('#partialPaidFields').removeClass('d-none');
                    $('#partialPaidFields input').prop('disabled', false);

                    // Reset values
                    $('#partialAmount').val('');
                    $('#pendingAmount').val(remaining.toFixed(2));

                    // Clear and disable UPI field
                    $('#upiAmountInput').val('').prop('readonly', false).prop('disabled', true);

                    // Live pending update
                    $('#partialAmount').off('input').on('input', function() {
                        let entered = parseFloat($(this).val()) || 0;
                        let newPending = Math.max(remaining - entered, 0);
                        $('#pendingAmount').val(newPending.toFixed(2));
                    });

                } else if (type === 'online_fully') {
                    // Show fully online section
                    $('#upiAmountDiv').removeClass('d-none');
                    $('#upiAmountDiv input').prop('disabled', false);

                    // Fill with remaining and lock editing
                    $('#upiAmountInput').val(remaining.toFixed(2)).prop('readonly', true);

                    // Reset partial section
                    $('#partialAmount, #pendingAmount').val('');
                    $('#partialPaidFields input').prop('disabled', true);
                }
            });

            // ✅ Handle Cash + Online Type
            $('#cashOnlineTypeSelect').on('change', function() {
                let type = $(this).val();
                let remaining = parseFloat($('#remainingAmountHidden').val()) || 0;

                // Hide both sections
                $('#fullyCashOnlineFields, #partialCashOnlineFields').addClass('d-none');
                // Disable all inputs first
                $('#fullyCashOnlineFields input, #partialCashOnlineFields input').prop('disabled', true);

                if (type === 'cash_online_fully') {
                    // Show fully section
                    $('#fullyCashOnlineFields').removeClass('d-none');
                    $('#fullyCashOnlineFields input').prop('disabled', false);

                    // Reset values
                    $('#cashOnlineFullAmount').val('');
                    $('#upiOnlineFullAmount').val(remaining.toFixed(2));

                    // Live adjustment of online amount
                    $('#cashOnlineFullAmount').off('input').on('input', function() {
                        let cash = parseFloat($(this).val()) || 0;
                        let online = Math.max(remaining - cash, 0);
                        $('#upiOnlineFullAmount').val(online.toFixed(2));
                    });

                    // Disable partial fields
                    $('#partialCashOnlineFields input').prop('disabled', true);

                } else if (type === 'cash_online_partially') {
                    // Show partial section
                    $('#partialCashOnlineFields').removeClass('d-none');
                    $('#partialCashOnlineFields input').prop('disabled', false);

                    // Reset values
                    $('#cashOnlinePartialAmount, #upiOnlinePartialAmount').val('');
                    $('#remainingCashOnlineAmount').val(remaining.toFixed(2));

                    // Live update on cash input
                    $('#cashOnlinePartialAmount').off('input').on('input', function() {
                        let cash = parseFloat($(this).val()) || 0;
                        let newRemaining = Math.max(remaining - cash, 0);
                        $('#remainingCashOnlineAmount').val(newRemaining.toFixed(2));
                    });

                    // Live update on online input
                    $('#upiOnlinePartialAmount').off('input').on('input', function() {
                        let online = parseFloat($(this).val()) || 0;
                        let cash = parseFloat($('#cashOnlinePartialAmount').val()) || 0;
                        let newRemaining = Math.max(remaining - cash - online, 0);
                        $('#remainingCashOnlineAmount').val(newRemaining.toFixed(2));
                    });

                    // Disable fully fields
                    $('#fullyCashOnlineFields input').prop('disabled', true);
                }
            });

            $('#makePaymentForm').on('submit', function(e) {
                e.preventDefault();


                let isValid = true;


                // Clear all previous errors
                $('.text-danger').text('');

                // Get values
                let paymentMethod = $('#paymentMethodSelect').val();
                let paymentTypeemionly = $('#paymentType').val();
                let paidType = $('#paidTypeSelect').val();
                let onlineType = $('#onlineTypeSelect').val();
                let cashOnlineType = $('#cashOnlineTypeSelect').val();
                let pendingAmount = $('#pendingAmount').val();

                console.log(pendingAmount);
                console.log(onlineType);

                // return false;
                // EMI Validation



                // Payment Method validation


                if (!paymentMethod) {
                    isValid = false;
                    console.log("Validation failed: Payment method not selected");
                    $('#paymentMethodError').text("Please select a payment method.");
                    return false;
                } else {
                    console.log("Payment method selected:", paymentMethod);
                }


                // Cash Payment Validation
                if (paymentMethod === 'cash') {
                    console.log("Cash payment selected");

                    if (!paidType) {
                        isValid = false;
                        console.log("Validation failed: Paid type not selected");
                        $('#paidTypeError').text("Please select paid type.");
                        return false;
                    } else {
                        console.log("Paid type selected:", paidType);
                    }

                    if (paidType === 'cash_partially') {
                        let partialAmount = parseFloat($('#partialAmount').val()) || 0;
                        let remainingAmount = parseFloat($('#remainingAmountHidden').val()) || 0;

                        console.log("Cash partially selected, entered amount:", partialAmount, "Remaining:",
                            remainingAmount);

                        if (!partialAmount || isNaN(partialAmount) || partialAmount <= 0) {
                            isValid = false;
                            $('#partialAmountError').text("Enter a valid positive partial cash amount.");
                            return false;
                        }

                        if (partialAmount > remainingAmount) {
                            isValid = false;
                            $('#partialAmountError').text(
                                "Partial cash amount cannot exceed remaining amount (" + remainingAmount
                                .toFixed(2) + ")."
                            );
                            return false;
                        }

                        if (partialAmount < 0) {
                            isValid = false;
                            $('#partialAmountError').text("Amount cannot be negative.");
                            return false;
                        }

                        console.log("Partial cash amount valid");
                    } else {
                        let cashAmount = $('#cashAmount').val();
                        console.log("Cash fully selected, amount:", cashAmount);
                        if (!cashAmount || parseFloat(cashAmount) <= 0) {
                            isValid = false;
                            console.log("Validation failed: Invalid full cash amount");
                            $('#cashAmountError').text("Enter a valid cash amount.");
                            return false;
                        } else {
                            console.log("Full cash amount valid");
                        }
                    }
                }

                // Online Payment Validation
                if (paymentMethod === 'online') {
                    console.log("Online payment selected");

                    if (!onlineType) {
                        isValid = false;
                        console.log("Validation failed: Online type not selected");
                        $('#onlineTypeError').text("Please select online type.");
                        return false;
                    } else {
                        console.log("Online type selected:", onlineType);
                    }

                    let onlineAmount = parseFloat($('#partialAmount').val()) || parseFloat($(
                        '#upiAmountInput').val()) || 0;
                    let remainingAmount = parseFloat($('#remainingAmountHidden').val()) || 0;

                    console.log("Online amount entered:", onlineAmount, "Remaining:", remainingAmount);

                    // ✅ Check 1: Must be a valid positive number
                    if (!onlineAmount || isNaN(onlineAmount) || onlineAmount <= 0) {
                        isValid = false;
                        if (onlineType === 'online_partially') {
                            console.log("Validation failed: Invalid partial online amount");
                            $('#partialAmountError').text("Enter a valid positive online partial amount.");
                        } else {
                            console.log("Validation failed: Invalid full online amount");
                            $('#upiAmountError').text("Enter a valid positive online amount.");
                        }
                        return false;
                    }

                    // ✅ Check 2: Cannot exceed remaining
                    if (onlineType === 'online_partially' && onlineAmount > remainingAmount) {
                        // console.log(onlineType);
                        isValid = false;
                        console.log("Validation failed: Partial online amount exceeds remaining");
                        $('#partialAmountError').text(
                            "Partial online amount cannot exceed remaining amount (" + remainingAmount
                            .toFixed(2) + ")."
                        );
                        return false;
                    }

                    // ✅ Check 3: Cannot be negative
                    if (onlineAmount < 0) {
                        isValid = false;
                        console.log("Validation failed: Negative online amount");
                        $('#partialAmountError').text("Amount cannot be negative.");
                        return false;
                    }

                    console.log("Online amount valid");
                }


                // Cash + Online Validation
                if (paymentMethod === 'cash_online') {
                    console.log("Cash + Online payment selected");

                    if (!cashOnlineType) {
                        isValid = false;
                        console.log("Validation failed: Cash + Online type not selected");
                        $('#cashOnlineTypeError').text("Please select Cash + Online type.");
                        return false;
                    } else {
                        console.log("Cash + Online type selected:", cashOnlineType);
                    }

                    if (cashOnlineType === 'cash_online_fully') {
                        let cashAmt = $('#cashOnlineFullAmount').val();
                        let onlineAmt = $('#upiOnlineFullAmount').val();
                        console.log("Cash+Online fully amounts:", cashAmt, onlineAmt);

                        if (!cashAmt || parseFloat(cashAmt) <= 0 || !onlineAmt || parseFloat(onlineAmt) <=
                            0) {
                            isValid = false;
                            console.log("Validation failed: Invalid fully cash + online amounts");
                            $('#cashOnlineFullAmountError').text("Enter a valid cash amount.");
                            $('#upiOnlineFullAmountError').text("Enter a valid online amount.");
                            return false;
                        } else {
                            console.log("Fully cash + online amounts valid");
                        }
                    }

                    if (cashOnlineType === 'cash_online_partially') {
                        let cashAmt = parseFloat($('#cashOnlinePartialAmount').val()) || 0;
                        let onlineAmt = parseFloat($('#upiOnlinePartialAmount').val()) || 0;

                        // Clean pending amount
                        let rawPending = $('#remainingCashOnlineAmount').val() || "0";
                        rawPending = rawPending.replace(/[₹,]/g, '').trim();
                        let pendingAmt = parseFloat(rawPending) || 0;

                        console.log("Cash+Online partially amounts:", cashAmt, onlineAmt, "Pending:",
                            pendingAmt);

                        // ✅ Check for invalid or negative input
                        if ((cashAmt <= 0 && onlineAmt <= 0)) {
                            isValid = false;
                            console.log("Validation failed: Invalid partially cash + online amounts");
                            $('#cashOnlinePartialAmountError').text("Enter at least one valid amount.");
                            $('#upiOnlinePartialAmountError').text("Enter at least one valid amount.");
                            return false;
                        }

                        if (cashAmt < 0 || onlineAmt < 0) {
                            isValid = false;
                            console.log("Validation failed: Negative amounts are not allowed");
                            $('#cashOnlinePartialAmountError').text("Negative amount not allowed.");
                            $('#upiOnlinePartialAmountError').text("Negative amount not allowed.");
                            return false;
                        }

                        // ✅ Total should not exceed pending amount
                        let total = cashAmt + onlineAmt;
                        console.log("Total payment:", total, "Pending amount:", pendingAmt);

                        if (total > pendingAmt) {
                            isValid = false;
                            console.log("Validation failed: Total exceeds pending amount");
                            $('#cashOnlinePartialAmountError').text(
                                "Total payment cannot exceed pending amount (" + pendingAmt + ").");
                            $('#upiOnlinePartialAmountError').text(
                                "Total payment cannot exceed pending amount (" + pendingAmt + ").");
                            return false;
                        }

                        console.log("Partially cash + online amounts valid");
                    }

                }


                console.log('done pay');


                if (isValid) {
                    // this.submit(); // submit the form
                }
                let selectedPaymentType = $('#paymentType').val();
                $('#paymentMethodHidden').val(selectedPaymentType);

                if ($("#paymentMethodDiv").hasClass("d-none")) {
                    $("#newEmiHidden").prop("disabled", true).val("");
                }



                let formElement = $(this)[0];
                let formData = new FormData(formElement);

                let submitButton = $(this).find('button[type="submit"]');
                submitButton.prop('disabled', true).text('Processing...');
                if (paymentMethodSelect === 'emi') {
                    let emiTotal = $('#emiTotalCalculated').val();
                    formData.append('emi_paid_value', emiTotal);
                }

                if (selectedPaymentType === 'emi') {
                    let emi_val = $('#emiTotalCalculated').val();
                    formData.append('amount', emi_val);
                }

                $.ajax({
                    url: "{{ route('make-payment.purchase') }}",
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    headers: {
                        'X-CSRF-TOKEN': "{{ csrf_token() }}",
                        "Authorization": "Bearer " + authToken
                    },
                    success: function(response) {
                        $('#makePaymentModal').modal('hide');
                        submitButton.prop('disabled', false).text('Submit Payment');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Payment submitted successfully.',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            location.reload();
                        });
                    },
                    error: function(xhr) {
                        submitButton.prop('disabled', false).text('Submit Payment');

                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            let errorMsg = '';
                            $.each(errors, function(key, value) {
                                errorMsg += value + '\n';
                            });
                            Swal.fire({
                                icon: 'error',
                                title: 'Validation Error',
                                text: errorMsg
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Something went wrong. Please try again.'
                            });
                        }
                    }
                });
            });


            $(function() {

                function formatDate(dateStr) {
                    if (!dateStr) return 'N/A';
                    const d = new Date(dateStr);
                    const day = String(d.getDate()).padStart(2, '0');
                    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
                        "Nov", "Dec"
                    ];
                    const month = months[d.getMonth()];
                    const year = d.getFullYear();
                    let hours = d.getHours();
                    const minutes = String(d.getMinutes()).padStart(2, '0');
                    const ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours % 12 || 12;
                    return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                }

                function badge(text, okClass, warnClass) {
                    const positiveStatuses = ['paid', 'completed', 'delivered', 'success'];
                    const isPositive = positiveStatuses.includes(String(text).toLowerCase());
                    const cls = isPositive ? okClass : warnClass;
                    return `<span class="badges ${cls}" style="text-transform:capitalize;">${text}</span>`;
                }

                function actionLinks(o) {


                    let buttons = '';

                    // Show "Make Payment" button only if remaining amount > 0
                    if (parseFloat(o.remaining_amount) > 0) {

                        buttons += `
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-primary me-3 make-payment-btn"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#makePaymentModal"
                                                                                    data-id="${o.id}"
                                                                                    data-amount="${parseFloat(o.remaining_amount).toFixed(2)}"
                                                                                    data-method="${o.payment_mode || ''}"
                                                                                    data-total-amount="${o.grand_total || 0}"
                                                                                    data-remaining-amount="${parseFloat(o.remaining_amount).toFixed(2)}">
                                                                                    Make Payment
                                                                                </button>
                                                                            `;
                    }
                    console.log(o);

                    // Other actions (always visible)
                    buttons += `
                                    <button class="btn open-history" data-id="${o.id}" title="Payment History">
                                                <i class="fas fa-history" style="font-size: 16px;"></i>
                                            </button>
                                                                            <a class="me-3" href="/print-purchase/${o.id}">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 32 32"><path d="M28 24v-4a1 1 0 0 0-2 0v4a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-4a1 1 0 0 0-2 0v4a3 3 0 0 0 3 3h18a3 3 0 0 0 3-3zm-6.38-5.22-5 4a1 1 0 0 1-1.24 0l-5-4a1 1 0 0 1 1.24-1.56l3.38 2.7V6a1 1 0 0 1 2 0v13.92l3.38-2.7a1 1 0 1 1 1.24 1.56z" fill="#092C4C"></path></svg>
                                                                            </a>`;
                    if (!o.has_payment || o.has_payment === 0) {
                        @if (app('hasPermission')(3, 'edit'))
                            buttons += `
                        <a class="me-3" href="/edit-purchase/${o.id}">
                                <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.045 5.401C15.423 5.023 15.631 4.521 15.631 3.987C15.631 3.453 15.423 2.951 15.045 2.573L13.459 0.987001C13.081 0.609001 12.579 0.401001 12.045 0.401001C11.511 0.401001 11.009 0.609001 10.632 0.986001L0 11.585V16H4.413L15.045 5.401ZM12.045 2.401L13.632 3.986L12.042 5.57L10.456 3.985L12.045 2.401ZM2 14V12.415L9.04 5.397L10.626 6.983L3.587 14H2ZM0 18H16V20H0V18Z" fill="#092C4C"></path>
                                    </svg>
                            </a>`;
                        @endif
                    }

                    buttons += `
                                                                            @if (app('hasPermission')(3, 'view'))

                                                                            <a class="me-3" href="javascript:void(0);" onclick="window.open('/purchase/invoice/pdf/' + ${o.id});">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="#092C4C" viewBox="0 0 24 24">
                                                                                    <path d="M19 7V4a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3H3a1 1 0 0 0-1 1v9a2 2 0 0 0 2 2h2v3h12v-3h2a2 2 0 0 0 2-2V8a1 1 0 0 0-1-1h-2zM7 4h10v3H7V4zm10 16H7v-4h10v4zm3-6a1 1 0 0 1-1 1h-2v-2H7v2H5a1 1 0 0 1-1-1V9h16v5z"/>
                                                                                </svg>
                                                                            </a>
                                                                            @endif

                                                                            @if (app('hasPermission')(3, 'delete'))

                                                                            <a class="me-3 confirm-text delete-order" data-id="${o.id}" href="javascript:void(0);">
                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M5 20C5 20.5304 5.21071 21.0391 5.58579 21.4142C5.96086 21.7893 6.46957 22 7 22H17C17.5304 22 18.0391 21.7893 18.4142 21.4142C18.7893 21.0391 19 20.5304 19 20V8H21V6H17V4C17 3.46957 16.7893 2.96086 16.4142 2.58579C16.0391 2.21071 15.5304 2 15 2H9C8.46957 2 7.96086 2.21071 7.58579 2.58579C7.21071 2.96086 7 3.46957 7 4V6H3V8H5V20ZM9 4H15V6H9V4ZM8 8H17V20H7V8H8Z" fill="#092C4C"/>
                                                                                    <path d="M9 10H11V18H9V10ZM13 10H15V18H13V10Z" fill="#092C4C"/>
                                                                                </svg>
                                                                            </a>
                                                                            @endif
                                                                        `;

                    return buttons;
                }

                function loadPurchases() {
                    const rawDate = $('#filter-date').val();
                    const [day, month, year] = rawDate ? rawDate.split('-') : [null, null, null];
                    const formattedDate = rawDate ? `${year}-${month}-${day}` : '';

                    const filters = {
                        date: formattedDate,
                        selectedSubAdminId: selectedSubAdminId || null,
                        vendor_name: $('#filter_inputs input[placeholder="Enter Name"]').val().trim(),
                        reference_no: $('#filter_inputs input[placeholder="Enter Reference No"]').val()
                            .trim(),
                        status: $('#filter_inputs select').val()
                    };

                    $.ajax({
                        url: "/api/purchase_list",
                        type: "GET",
                        dataType: "json",
                        data: filters,
                        headers: {
                            "Authorization": "Bearer " + authToken
                        },
                        success: res => {
                            const rows = [];

                            if (res.success && Array.isArray(res.data)) {
                                const currencySymbol = res.currency_symbol || '₹';
                                const currencyPosition = res.currency_position || 'left';

                                // Store purchase data for expandable rows
                                if (!window.purchaseDataMap) {
                                    window.purchaseDataMap = {};
                                }

                                res.data.forEach(o => {
                                    const amount = parseFloat(o.grand_total || 0)
                                        .toFixed(2);
                                    const formattedAmount = currencyPosition ===
                                        'right' ?
                                        `${amount}${currencySymbol}` :
                                        `${currencySymbol}${amount}`;

                                    // Store purchase data for expandable row
                                    const purchaseData = {
                                        ...o,
                                        invoice_date: formatDate(o.invoice_date || o
                                            .date || o.created_at),
                                        displayAmount: formattedAmount,
                                        currencySymbol: currencySymbol,
                                        currencyPosition: currencyPosition
                                    };
                                    window.purchaseDataMap[o.id] = purchaseData;

                                    rows.push([
                                        `<a href="/purchase-view/${o.id}" style="text-decoration: none;">${o.invoice_number || ''}</a>`,
                                        `<button class="mobile-toggle-btn-table" onclick="togglePurchaseRowDetails('${o.id}')" data-purchase-id="${o.id}">
                                            <span class="toggle-icon">+</span>
                                        </button>`,
                                        formatDate(o.invoice_date || o.date || o
                                            .created_at),
                                        `<span style="text-transform:capitalize;">${o.vendor_name || ''}</span>`,
                                        formattedAmount,
                                        badge((o.purchase_status || o.status ||
                                                ''), 'bg-lightgreen',
                                            'bg-lightyellow'),
                                        badge(o.payment_status, 'bg-lightgreen',
                                            'bg-lightred'),
                                        actionLinks(o)
                                    ]);
                                });

                                const $tbl = $('#order-table');

                                function updateTotal(dt) {
                                    setTimeout(() => calculatePurchaseFilteredTotal(), 100);
                                }

                                if ($.fn.DataTable.isDataTable($tbl)) {
                                    const dt = $tbl.DataTable();
                                    dt.clear().rows.add(rows).draw();
                                    dt.off('draw').on('draw', () => {
                                        updateTotal(dt);
                                        if (window.addPurchaseExpandableRows) {
                                            window.addPurchaseExpandableRows(dt);
                                        }
                                    });
                                    updateTotal(dt);
                                    setTimeout(() => {
                                        if (window.addPurchaseExpandableRows) {
                                            window.addPurchaseExpandableRows(dt);
                                        }
                                    }, 100);
                                } else {
                                    const dt = $tbl.DataTable({
                                        data: rows,
                                        responsive: true,
                                        autoWidth: false,
                                        pageLength: 10,
                                        ordering: true,
                                        searching: true,
                                        language: {
                                            searchPlaceholder: "Search purchases...",
                                            search: ""
                                        }
                                    });
                                    dt.on('draw', () => {
                                        updateTotal(dt);
                                        if (window.addPurchaseExpandableRows) {
                                            window.addPurchaseExpandableRows(dt);
                                        }
                                    });
                                    updateTotal(dt);
                                    setTimeout(() => {
                                        if (window.addPurchaseExpandableRows) {
                                            window.addPurchaseExpandableRows(dt);
                                        }
                                    }, 100);
                                }

                                // Update global purchaseTable reference
                                purchaseTable = $tbl.DataTable();

                                // Populate customer dropdown after first draw
                                purchaseTable.one('draw', function() {
                                    let customers = new Set();
                                    purchaseTable.column(3, {
                                        search: 'applied'
                                    }).data().each(function(d) {
                                        let name = $('<div>').html(d).text()
                                            .trim();
                                        customers.add(name);
                                    });

                                    let $filter = $("#filter-customer");
                                    $filter.empty().append(
                                        '<option value="">-- Select Vendor --</option>'
                                    );
                                    customers.forEach(function(name) {
                                        $filter.append('<option value="' +
                                            name + '">' + name + '</option>'
                                        );
                                    });
                                });

                                // Scroll sync
                                const topScroll = document.querySelector('.table-scroll-top');
                                const tableResponsive = document.querySelector(
                                    '.table-responsive');
                                const table = document.getElementById('order-table');
                                topScroll.querySelector('div').style.width = table.scrollWidth +
                                    'px';

                                topScroll.onscroll = () => {
                                    tableResponsive.scrollLeft = topScroll.scrollLeft;
                                };
                                tableResponsive.onscroll = () => {
                                    topScroll.scrollLeft = tableResponsive.scrollLeft;
                                };
                            }
                        },
                        error: xhr => console.error('purchase_list error:', xhr.responseText)
                    });
                }

                // Init
                loadPurchases();

                $('#filter-date').on('dp.change', loadPurchases);
                $('.btn-filters').on('click', e => {
                    e.preventDefault();
                    loadPurchases();
                });
            });


            // Handle delete action
            $(document).on("click", ".delete-order", function() {
                let orderId = $(this).data("id");

                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#ff9f43", // Orange confirm button
                    cancelButtonColor: "#6c757d",
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "/api/purchase_delete",
                            type: "POST",
                            data: {
                                id: orderId,
                                _token: "{{ csrf_token() }}"
                            },
                            headers: {
                                "Authorization": "Bearer " + authToken,
                            },
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire({
                                        title: "Deleted!",
                                        text: response.message,
                                        icon: "success",
                                        confirmButtonColor: "#ff9f43"
                                    }).then(() => {
                                        location
                                            .reload(); // ✅ Reload page after user clicks OK
                                    });
                                } else {
                                    // ❌ Show backend error if success = false
                                    Swal.fire({
                                        title: "Error!",
                                        text: response.message,
                                        icon: "error",
                                        confirmButtonColor: "#ff9f43"
                                    });
                                }
                            },
                            error: function(xhr) {
                                // Try to show backend message from response JSON
                                let errorMessage = "Something went wrong. Try again.";
                                if (xhr.responseJSON && xhr.responseJSON.message) {
                                    errorMessage = xhr.responseJSON.message;
                                }

                                Swal.fire({
                                    title: "Error!",
                                    text: errorMessage,
                                    icon: "error",
                                    confirmButtonColor: "#ff9f43"
                                });

                                console.error(xhr.responseText); // For debugging
                            }
                        });
                    }
                });
            });

            // Global history modal open
            $(document).on('click', '.open-history', function() {
                const jobCardId = $(this).data('id');
                $('#globalPaymentHistoryList').html('<li class="list-group-item">Loading...</li>');
                $.ajax({
                    url: '/api/purchase/payment-history/' + jobCardId,
                    method: 'GET',
                    headers: {
                        "Authorization": "Bearer " + authToken
                    },
                    success: function(response) {
                        const history = response.data || [];
                        if (history.length === 0) {
                            $('#globalPaymentHistoryList').html(
                                '<li class="list-group-item">No payment history found.</li>'
                            );
                        } else {
                            const items = history.map(p => `
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Payment Date: ${(p.payment_date || p.created_at)}</span>
                                    <span><strong>${parseFloat(p.payment_amount || 0).toFixed(2)}</strong> via ${p.payment_method || ''}</span>
                                </li>
                            `).join('');
                            $('#globalPaymentHistoryList').html(items);
                        }
                        const modal = new bootstrap.Modal(document.getElementById(
                            'paymentHistoryModal'));
                        modal.show();
                    },
                    error: function() {
                        $('#globalPaymentHistoryList').html(
                            '<li class="list-group-item text-danger">Failed to load payment history.</li>'
                        );
                        const modal = new bootstrap.Modal(document.getElementById(
                            'paymentHistoryModal'));
                        modal.show();
                    }
                });
            });

            // Function to force CSS media query recalculation
            function forceCSSRecalculation() {
                // Create a temporary element to force reflow
                const temp = document.createElement('div');
                temp.style.width = '1px';
                temp.style.height = '1px';
                temp.style.position = 'absolute';
                temp.style.visibility = 'hidden';
                document.body.appendChild(temp);
                void temp.offsetWidth;
                void temp.offsetHeight;
                document.body.removeChild(temp);

                // Force reflow on viewport
                void window.innerWidth;
                void window.innerHeight;

                // Force reflow on document
                void document.documentElement.offsetWidth;
                void document.documentElement.offsetHeight;
            }

            // Resize handler for responsive behavior
            let resizeTimer;
            let lastWidth = $(window).width();

            function handlePurchaseResize() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() {
                    const currentWidth = $(window).width();

                    // Always process resize to ensure CSS updates
                    lastWidth = currentWidth;

                    // Force CSS media query recalculation first
                    forceCSSRecalculation();

                    // Force CSS recalculation by triggering multiple reflows
                    const table = document.getElementById('order-table');
                    const tableResponsive = document.querySelector('.table-responsive');
                    const tableTop = document.querySelector('.table-top');
                    const cardBody = document.querySelector('.card-body');
                    const card = document.querySelector('.card');

                    // Method 1: Force reflow on all key elements
                    [table, tableResponsive, tableTop, cardBody, card].forEach(function(el) {
                        if (el) {
                            void el.offsetHeight;
                            void el.offsetWidth;
                            // Force style recalculation
                            el.style.display = 'none';
                            void el.offsetHeight;
                            el.style.display = '';
                        }
                    });

                    // Method 2: Force CSS media query recalculation
                    if (document.body) {
                        const originalDisplay = document.body.style.display;
                        document.body.style.display = 'none';
                        void document.body.offsetHeight;
                        document.body.style.display = originalDisplay;
                    }

                    // Method 3: Force table and DataTables recalculation
                    if (purchaseTable && table) {
                        // Remove all existing expandable rows first
                        $('tr.order-details-row').remove();

                        // Force DataTables to recalculate
                        try {
                            // Multiple adjustments to ensure columns update
                            purchaseTable.columns.adjust();
                            void table.offsetHeight;

                            purchaseTable.draw(false);
                            void table.offsetHeight;

                            // Additional adjustment after draw
                            setTimeout(function() {
                                purchaseTable.columns.adjust();
                                purchaseTable.draw(false);

                                // Force one more reflow
                                void table.offsetHeight;

                                // Re-add expandable rows if needed
                                setTimeout(function() {
                                    if (window.addPurchaseExpandableRows) {
                                        window.addPurchaseExpandableRows(purchaseTable);
                                    }
                                    calculatePurchaseFilteredTotal();

                                    // Final CSS recalculation
                                    forceCSSRecalculation();
                                    void table.offsetHeight;
                                }, 100);
                            }, 100);
                        } catch (e) {
                            console.error('DataTables adjustment error:', e);
                            // Fallback: just redraw
                            purchaseTable.draw(false);
                            setTimeout(function() {
                                if (window.addPurchaseExpandableRows) {
                                    window.addPurchaseExpandableRows(purchaseTable);
                                }
                                calculatePurchaseFilteredTotal();
                                forceCSSRecalculation();
                            }, 150);
                        }
                    } else {
                        // Even if no table, force CSS recalculation
                        forceCSSRecalculation();
                    }
                }, 50);
            }

            // Window resize handler with throttling - multiple listeners for reliability
            $(window).off('resize.purchase').on('resize.purchase', handlePurchaseResize);

            // Also add native window resize listener (remove old one if exists, then add new)
            if (window.purchaseResizeHandler) {
                window.removeEventListener('resize', window.purchaseResizeHandler);
            }
            window.purchaseResizeHandler = handlePurchaseResize;
            window.addEventListener('resize', window.purchaseResizeHandler, {
                passive: true
            });

            // Orientation change handler
            $(window).off('orientationchange.purchase').on('orientationchange.purchase', function() {
                setTimeout(function() {
                    lastWidth = $(window).width();
                    handlePurchaseResize();
                }, 300);
            });

            // Also add native orientation change listener
            window.addEventListener('orientationchange', function() {
                setTimeout(function() {
                    lastWidth = $(window).width();
                    handlePurchaseResize();
                }, 500);
            });

            // MatchMedia listeners for all breakpoint changes
            const queries = [
                window.matchMedia('(max-width: 575.98px)'),
                window.matchMedia('(min-width: 576px) and (max-width: 767.98px)'),
                window.matchMedia('(min-width: 768px) and (max-width: 1024px)'),
                window.matchMedia('(min-width: 1025px)')
            ];

            queries.forEach(function(query) {
                // Modern browsers
                if (query.addEventListener) {
                    query.addEventListener('change', function() {
                        setTimeout(handlePurchaseResize, 100);
                    });
                }
                // Legacy browsers
                else if (query.addListener) {
                    query.addListener(function() {
                        setTimeout(handlePurchaseResize, 100);
                    });
                }
            });

            // Initial width set
            lastWidth = $(window).width();

            // Call on initial load to ensure correct state
            $(window).on('load', function() {
                setTimeout(function() {
                    lastWidth = $(window).width();
                    handlePurchaseResize();
                }, 500);
            });

            // Also call after a short delay to ensure DOM is ready
            setTimeout(function() {
                if (purchaseTable) {
                    handlePurchaseResize();
                }
            }, 1000);

            // Make handler globally accessible for debugging
            window.handlePurchaseResize = handlePurchaseResize;

        });
        const topScroll = document.querySelector('.table-scroll-top');
        const tableResponsive = document.querySelector('.table-responsive');
        const table = document.getElementById('order-table');

        // Set top scrollbar inner div width to match table scroll width
        function updateTopScrollbarWidth() {
            const topInnerDiv = topScroll.querySelector('div');
            topInnerDiv.style.width = table.scrollWidth + 'px';
        }

        // Update on load and window resize
        window.addEventListener('load', updateTopScrollbarWidth);
        window.addEventListener('resize', updateTopScrollbarWidth);

        // Sync scrolling
        topScroll.addEventListener('scroll', function() {
            tableResponsive.scrollLeft = topScroll.scrollLeft;
        });
        tableResponsive.addEventListener('scroll', function() {
            topScroll.scrollLeft = tableResponsive.scrollLeft;
        });
        $('#exportAllChallan').click(function() {
            let selectedYear = $('#filter-year').val() || '';
            let selectedMonth = $('#filter-month').val() || '';
            let selectedDate = $('#filter-date').val() || '';
            let selectedVendorId = $('#filter-customer').val() || '';
            const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
            let authToken = localStorage.getItem("authToken");

            let url =
                `/api/export-purchase?year=${selectedYear}&month=${selectedMonth}&date=${selectedDate}&customer_id=${selectedVendorId}&selectedSubAdminId=${selectedSubAdminId}`;

            $.ajax({
                url: url,
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + authToken
                },
                success: function(response) {
                    if (response.status && response.file_url) {
                        // Trigger download
                        const link = document.createElement('a');
                        link.href = response.file_url;
                        link.download = response.file_name; // optional
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        alert("Export failed: " + (response.message || "Unknown error"));
                    }
                },
                error: function(xhr) {
                    console.error("Export failed:", xhr.responseText);
                    alert("Export failed. Please try again.");
                }
            });
        });

        $('#exportPdf').click(function() {
            let selectedYear = $('#filter-year').val() || '';
            let selectedMonth = $('#filter-month').val() || '';
            let selectedDate = $('#filter-date').val() || '';
            let selectedVendorId = $('#filter-customer').val() || '';
            const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
            let authToken = localStorage.getItem("authToken");

            $.ajax({
                url: `/api/export-purchase-pdf`,
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + authToken
                },
                data: {
                    year: selectedYear,
                    month: selectedMonth,
                    date: selectedDate,
                    customer_id: selectedVendorId,
                    selectedSubAdminId: selectedSubAdminId
                },
                success: function(response) {
                    if (response.status && response.file_url) {
                        // Download the PDF
                        let link = document.createElement('a');
                        link.href = response.file_url;
                        link.download = response.file_name || 'Purchases.pdf';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        alert("PDF generation failed.");
                    }
                },
                error: function(xhr) {
                    console.error(xhr);
                    alert("Failed to generate PDF. Please try again.");
                }
            });
        });
    </script>
@endpush
