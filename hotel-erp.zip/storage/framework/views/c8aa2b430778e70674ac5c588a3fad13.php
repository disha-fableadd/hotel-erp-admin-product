<?php
    $user = auth()->user();
?>

<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                
                <?php if(app('hasPermission')(0, 'view')): ?>
                    <li>
                        <a href="<?php echo e(route('auth.dashboard')); ?>"><img
                                src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/dashboard.svg'); ?>" alt="img"><span>
                                Dashboard</span> </a>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(1, 'view') || app('hasPermission')(1, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/product.svg'); ?>" alt="img"><span>
                                Menu</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(1, 'view')): ?>
                                <li><a href="<?php echo e(route('product.list')); ?>">All Products</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(1, 'add')): ?>
                                <li><a href="<?php echo e(route('product.add')); ?>">New Product</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(8, 'view')): ?>
                                <li><a href="<?php echo e(route('category.list')); ?>">All Categories</a></li>
                                <li><a href="<?php echo e(route('category.add')); ?>">New Category</a></li>
                                <li><a href="<?php echo e(route('brand.list')); ?>">All Brands</a></li>
                                <li><a href="<?php echo e(route('brand.add')); ?>">New Brand</a></li>
                                <li><a href="<?php echo e(route('product.import')); ?>">Import Products</a></li>
                                <li><a href="<?php echo e(route('quantity_type.quantity')); ?>">Quantity Type</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(2, 'view') || app('hasPermission')(2, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/sales1.svg'); ?>"
                                alt="img"><span>Orders</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(2, 'view')): ?>
                                <li><a href="<?php echo e(route('sales.list')); ?>">All Orders</a></li>
                                <li><a href="<?php echo e(route('tables.create')); ?>">Tables Views</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(2, 'add')): ?>
                                <li><a href="<?php echo e(route('sales.add')); ?>">New Orders</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(3, 'view') || app('hasPermission')(3, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/purchase1.svg'); ?>"
                                alt="img"><span>Purchases</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(3, 'view')): ?>
                                <li><a href="<?php echo e(route('purchase.lists')); ?>">All Purchases</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(3, 'add')): ?>
                                <li><a href="<?php echo e(route('purchase.add')); ?>">New Purchase</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(app('hasPermission')(17, 'view')): ?>
                    <li>
                        <a href="<?php echo e(route('inventory.list')); ?>">
                            <i class="fa fa-book"></i>
                            <span>Manage Inventory</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(app('hasPermission')(16, 'view')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/purchase1.svg'); ?>" alt="img">
                            <span>Manage Accounting</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <?php if(app('hasPermission')(16, 'view')): ?>
                                <li><a href="<?php echo e(route('account_ledger.add')); ?>">Account Ledger</a></li>
                            <?php endif; ?>

                            <?php if(app('hasPermission')(16, 'view')): ?>
                                <li><a href="<?php echo e(route('income-statement.index')); ?>">Income Statement</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(16, 'view')): ?>
                                <li class="d-none"><a href="<?php echo e(route('accounting.balance-sheet')); ?>">Balance Sheet</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <?php if(app('hasPermission')(4, 'view') || app('hasPermission')(4, 'add')): ?>
                    <li class="submenu" style="display: none;">
                        <a href="javascript:void(0);"><img
                                src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/purchase1.svg'); ?>"
                                alt="img"><span>Invoices</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(4, 'view')): ?>
                                <li><a href="<?php echo e(route('custom_invoice.lists')); ?>">All Invoices</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(4, 'add')): ?>
                                <li><a href="<?php echo e(route('custom_invoice.add')); ?>">New Invoice</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(5, 'view') || app('hasPermission')(5, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/expense1.svg'); ?>" alt="img"><span>
                                Expenses</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(5, 'view')): ?>
                                <li><a href="<?php echo e(route('expense.list')); ?>">All Expenses</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(5, 'add')): ?>
                                <li><a href="<?php echo e(route('expense.add')); ?>">New Expense</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(5, 'view')): ?>
                                <li><a href="<?php echo e(route('expensetype.list')); ?>">All Expense Type</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if((app('hasPermission')(2, 'add') && app('hasPermission')(2, 'edit')) || (app('hasPermission')(3, 'add') && app('hasPermission')(3, 'edit'))): ?>
                    <li class="submenu d-none">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/return1.svg'); ?>" alt="img">
                            <span>Returns</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            
                            <?php if(app('hasPermission')(2, 'add') && app('hasPermission')(2, 'edit')): ?>
                                <li><a href="<?php echo e(route('salesreturn.add')); ?>">Sales Return</a></li>
                            <?php endif; ?>

                            
                            <?php if(app('hasPermission')(3, 'add') && app('hasPermission')(3, 'edit')): ?>
                                <li><a href="<?php echo e(route('purchasereturn.add')); ?>">Purchase Return</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                

                <?php
                   
                    $canViewAttendance = app('hasPermission')(26, 'view');
                   
                ?>

                <?php if(auth()->user()->role === 'staff'): ?>

                <?php if($canViewAttendance): ?>
                    <?php if($canViewAttendance): ?>
                        
                        <li style="display: none;">
                            <a href="<?php echo e(route('attendance.list')); ?>">
                                <i class="fa fa-clock"></i><span> Attendance</span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>

                
                <?php if(app('hasPermission')(8, 'view')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/users1.svg'); ?>" alt="img">
                            <span> Staff</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <li><a href="<?php echo e(route('staff.list')); ?>">All Staff</a></li>
                            <li><a href="<?php echo e(route('staff.add')); ?>">New Staff</a></li>
                            <li class="d-none"><a href="<?php echo e(route('attendance.list')); ?>">Attendance</a></li>
                            <li class="d-none"><a href="<?php echo e(route('salary.list')); ?>">Salary</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                <!-- <li class="submenu">
                        <a href="javascript:void(0);"><i class="fa fa-calendar-check"></i><span> Appointment</span>
                            <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(17, 'view')): ?>
                                <li><a href="<?php echo e(route('appointments.index')); ?>">All Appointment</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(17, 'add')): ?>
                                <li><a href="<?php echo e(route('appointments.create')); ?>">New Appointment</a></li>
                            <?php endif; ?>
                        </ul>
                    </li> -->

                <?php if(auth()->user()->role === 'admin'): ?>

                    <li class="submenu" style="display: none;">
                        <a href="javascript:void(0);">
                            <i class="fa fa-money-bill-wave"></i>
                            <span>Advance Pay</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <?php if(app('hasPermission')(23, 'view')): ?>
                                <li><a href="<?php echo e(route('advance_pay.index')); ?>">All Advance Pay</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(23, 'add')): ?>
                                <li><a href="<?php echo e(route('advance_pay.create')); ?>">New Advance Pay</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(9, 'view') || app('hasPermission')(9, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/tab.svg'); ?>"
                                alt="img"><span> Tables</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(9, 'view')): ?>
                                <li><a href="<?php echo e(route('customer.list')); ?>">All Tables</a></li>
                            <?php endif; ?>
                            <!-- <?php if(app('hasPermission')(9, 'add')): ?>
                                <li><a href="<?php echo e(route('customer.add')); ?>">New Tables</a></li>
                            <?php endif; ?> -->
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(10, 'view') || app('hasPermission')(10, 'add')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/users1.svg'); ?>"
                                alt="img"><span> Vendors</span> <span class="menu-arrow"></span></a>
                        <ul>
                            <?php if(app('hasPermission')(10, 'view')): ?>
                                <li><a href="<?php echo e(route('vendor.list')); ?>">All Vendors</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(10, 'add')): ?>
                                <li><a href="<?php echo e(route('vendor.add')); ?>">New Vendor </a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                
                
                <?php if(app('hasPermission')(2, 'view') || app('hasPermission')(3, 'view') || app('hasPermission')(5, 'view')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/time.svg'); ?>" alt="img">
                            <span> Reports</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <?php if(app('hasPermission')(2, 'view')): ?>
                                <li><a href="<?php echo e(route('sales.report')); ?>">Orders Report</a></li>
                            <?php endif; ?>

                            <?php if(app('hasPermission')(3, 'view')): ?>
                                <li><a href="<?php echo e(route('purchase.report')); ?>">Purchase Report</a></li>
                            <?php endif; ?>

                            <?php if(app('hasPermission')(5, 'view')): ?>
                                <li><a href="<?php echo e(route('expense.report')); ?>">Expenses Report</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(app('hasPermission')(14, 'view') || app('hasPermission')(15, 'view')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(env('ImagePath') . '/admin/assets/img/icons/settings.svg'); ?>" alt="img">
                            <span> Settings</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <?php if(app('hasPermission')(14, 'view')): ?>
                                <li><a href="<?php echo e(route('setting.generalsettings')); ?>">Shop Settings</a></li>
                            <?php endif; ?>
                            <?php if(app('hasPermission')(15, 'view')): ?>
                                <li><a href="<?php echo e(route('auth.taxrates')); ?>">Tax Rates</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\hotel-erp\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>