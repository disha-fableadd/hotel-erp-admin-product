@php
    $user = auth()->user();
@endphp

<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                {{-- Dashboard --}}
                @if(app('hasPermission')(0, 'view'))
                    <li>
                        <a href="{{route('auth.dashboard')}}"><img
                                src="{{ env('ImagePath') . '/admin/assets/img/icons/dashboard.svg' }}" alt="img"><span>
                                Dashboard</span> </a>
                    </li>
                @endif
                {{-- Products --}}
                @if(app('hasPermission')(1, 'view') || app('hasPermission')(1, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="{{ env('ImagePath') . '/admin/assets/img/icons/product.svg' }}" alt="img"><span>
                                Menu</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(1, 'view'))
                                <li><a href="{{route('product.list')}}">All Products</a></li>
                            @endif
                            @if(app('hasPermission')(1, 'add'))
                                <li><a href="{{route('product.add')}}">New Product</a></li>
                            @endif
                            @if(app('hasPermission')(8, 'view'))
                                <li><a href="{{route('category.list')}}">All Categories</a></li>
                                <li><a href="{{route('category.add')}}">New Category</a></li>
                                <li><a href="{{route('brand.list')}}">All Brands</a></li>
                                <li><a href="{{route('brand.add')}}">New Brand</a></li>
                                <li><a href="{{route('product.import')}}">Import Products</a></li>
                                <li><a href="{{route('quantity_type.quantity')}}">Quantity Type</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Sales and Orders --}}
                @if(app('hasPermission')(2, 'view') || app('hasPermission')(2, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="{{ env('ImagePath') . '/admin/assets/img/icons/sales1.svg' }}"
                                alt="img"><span>Orders</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(2, 'view'))
                                <li><a href="{{route('sales.list')}}">All Orders</a></li>
                                <li><a href="{{route('tables.create')}}">Tables Views</a></li>
                            @endif
                            @if(app('hasPermission')(2, 'add'))
                                <li><a href="{{route('sales.add')}}">New Orders</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Purchases --}}
                @if(app('hasPermission')(3, 'view') || app('hasPermission')(3, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="{{ env('ImagePath') . '/admin/assets/img/icons/purchase1.svg' }}"
                                alt="img"><span>Purchases</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(3, 'view'))
                                <li><a href="{{route('purchase.lists')}}">All Purchases</a></li>
                            @endif
                            @if(app('hasPermission')(3, 'add'))
                                <li><a href="{{route('purchase.add')}}">New Purchase</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                @if (app('hasPermission')(17, 'view'))
                    <li>
                        <a href="{{ route('inventory.list') }}">
                            <i class="fa fa-book"></i>
                            <span>Manage Inventory</span>
                        </a>
                    </li>
                @endif
                @if (app('hasPermission')(16, 'view'))
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/purchase1.svg' }}" alt="img">
                            <span>Manage Accounting</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            @if(app('hasPermission')(16, 'view'))
                                <li><a href="{{ route('account_ledger.add') }}">Account Ledger</a></li>
                            @endif

                            @if(app('hasPermission')(16, 'view'))
                                <li><a href="{{ route('income-statement.index') }}">Income Statement</a></li>
                            @endif
                            @if(app('hasPermission')(16, 'view'))
                                <li class="d-none"><a href="{{ route('accounting.balance-sheet') }}">Balance Sheet</a></li>
                            @endif
                        </ul>
                    </li>
                @endif

                {{-- Invoices --}}
                @if(app('hasPermission')(4, 'view') || app('hasPermission')(4, 'add'))
                    <li class="submenu" style="display: none;">
                        <a href="javascript:void(0);"><img
                                src="{{ env('ImagePath') . '/admin/assets/img/icons/purchase1.svg' }}"
                                alt="img"><span>Invoices</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(4, 'view'))
                                <li><a href="{{route('custom_invoice.lists')}}">All Invoices</a></li>
                            @endif
                            @if(app('hasPermission')(4, 'add'))
                                <li><a href="{{route('custom_invoice.add')}}">New Invoice</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Expenses --}}
                @if(app('hasPermission')(5, 'view') || app('hasPermission')(5, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img
                                src="{{ env('ImagePath') . '/admin/assets/img/icons/expense1.svg' }}" alt="img"><span>
                                Expenses</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(5, 'view'))
                                <li><a href="{{route('expense.list')}}">All Expenses</a></li>
                            @endif
                            @if(app('hasPermission')(5, 'add'))
                                <li><a href="{{route('expense.add')}}">New Expense</a></li>
                            @endif
                            @if(app('hasPermission')(5, 'view'))
                                <li><a href="{{route('expensetype.list')}}">All Expense Type</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Returns --}}
                @if((app('hasPermission')(2, 'add') && app('hasPermission')(2, 'edit')) || (app('hasPermission')(3, 'add') && app('hasPermission')(3, 'edit')))
                    <li class="submenu d-none">
                        <a href="javascript:void(0);">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/return1.svg' }}" alt="img">
                            <span>Returns</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            {{-- Sales Return: show only if user has add & edit permission on module 2 --}}
                            @if(app('hasPermission')(2, 'add') && app('hasPermission')(2, 'edit'))
                                <li><a href="{{ route('salesreturn.add') }}">Sales Return</a></li>
                            @endif

                            {{-- Purchase Return: show only if user has add & edit permission on module 3 --}}
                            @if(app('hasPermission')(3, 'add') && app('hasPermission')(3, 'edit'))
                                <li><a href="{{ route('purchasereturn.add') }}">Purchase Return</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Quotes --}}

                @php
                   
                    $canViewAttendance = app('hasPermission')(26, 'view');
                   
                @endphp

                @if (auth()->user()->role === 'staff')

                @if ($canViewAttendance)
                    @if ($canViewAttendance)
                        {{-- ✅ Only Attendance permission → show directly --}}
                        <li style="display: none;">
                            <a href="{{ route('attendance.list') }}">
                                <i class="fa fa-clock"></i><span> Attendance</span>
                            </a>
                        </li>
                    @endif
                @endif
                @endif

                {{-- Staff --}}
                @if(app('hasPermission')(8, 'view'))
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/users1.svg' }}" alt="img">
                            <span> Staff</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            <li><a href="{{route('staff.list')}}">All Staff</a></li>
                            <li><a href="{{route('staff.add')}}">New Staff</a></li>
                            <li class="d-none"><a href="{{ route('attendance.list') }}">Attendance</a></li>
                            <li class="d-none"><a href="{{ route('salary.list') }}">Salary</a></li>
                        </ul>
                    </li>
                @endif
                <!-- <li class="submenu">
                        <a href="javascript:void(0);"><i class="fa fa-calendar-check"></i><span> Appointment</span>
                            <span class="menu-arrow"></span></a>
                        <ul>
                            @if (app('hasPermission')(17, 'view'))
                                <li><a href="{{ route('appointments.index') }}">All Appointment</a></li>
                            @endif
                            @if (app('hasPermission')(17, 'add'))
                                <li><a href="{{ route('appointments.create') }}">New Appointment</a></li>
                            @endif
                        </ul>
                    </li> -->

                @if (auth()->user()->role === 'admin')

                    <li class="submenu" style="display: none;">
                        <a href="javascript:void(0);">
                            <i class="fa fa-money-bill-wave"></i>
                            <span>Advance Pay</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            @if (app('hasPermission')(23, 'view'))
                                <li><a href="{{ route('advance_pay.index') }}">All Advance Pay</a></li>
                            @endif
                            @if (app('hasPermission')(23, 'add'))
                                <li><a href="{{ route('advance_pay.create') }}">New Advance Pay</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Customers --}}
                @if(app('hasPermission')(9, 'view') || app('hasPermission')(9, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="{{ env('ImagePath') . '/admin/assets/img/icons/tab.svg' }}"
                                alt="img"><span> Tables</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(9, 'view'))
                                <li><a href="{{route('customer.list')}}">All Tables</a></li>
                            @endif
                            <!-- @if(app('hasPermission')(9, 'add'))
                                <li><a href="{{route('customer.add')}}">New Tables</a></li>
                            @endif -->
                        </ul>
                    </li>
                @endif
                {{-- Vendors --}}
                @if(app('hasPermission')(10, 'view') || app('hasPermission')(10, 'add'))
                    <li class="submenu">
                        <a href="javascript:void(0);"><img src="{{ env('ImagePath') . '/admin/assets/img/icons/users1.svg' }}"
                                alt="img"><span> Vendors</span> <span class="menu-arrow"></span></a>
                        <ul>
                            @if(app('hasPermission')(10, 'view'))
                                <li><a href="{{route('vendor.list')}}">All Vendors</a></li>
                            @endif
                            @if(app('hasPermission')(10, 'add'))
                                <li><a href="{{route('vendor.add')}}">New Vendor </a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- GST Reports --}}
                {{-- @if(app('hasPermission')(20, 'view'))
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <img src="{{ env('ImagePath').'/admin/assets/img/icons/time.svg' }}" alt="img">
                        <span> GST Reports</span> <span class="menu-arrow"></span>
                    </a>
                    <ul>
                        @if(app('hasPermission')(20, 'view'))
                        <li><a href="{{ route('gst.reports.purchase') }}">GST Purchase Report</a></li>
                        @endif
                        @if(app('hasPermission')(20, 'view'))
                        <li><a href="{{ route('gst.reports.sales') }}">GST Sales Report</a></li>
                        @endif
                    </ul>
                </li>
                @endif --}}
                {{-- Reports --}}
                @if(app('hasPermission')(2, 'view') || app('hasPermission')(3, 'view') || app('hasPermission')(5, 'view'))
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/time.svg' }}" alt="img">
                            <span> Reports</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            @if(app('hasPermission')(2, 'view'))
                                <li><a href="{{route('sales.report')}}">Orders Report</a></li>
                            @endif

                            @if(app('hasPermission')(3, 'view'))
                                <li><a href="{{route('purchase.report')}}">Purchase Report</a></li>
                            @endif

                            @if(app('hasPermission')(5, 'view'))
                                <li><a href="{{route('expense.report')}}">Expenses Report</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
                {{-- Settings --}}
                @if(app('hasPermission')(14, 'view') || app('hasPermission')(15, 'view'))
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/settings.svg' }}" alt="img">
                            <span> Settings</span> <span class="menu-arrow"></span>
                        </a>
                        <ul>
                            @if(app('hasPermission')(14, 'view'))
                                <li><a href="{{route('setting.generalsettings')}}">Shop Settings</a></li>
                            @endif
                            @if(app('hasPermission')(15, 'view'))
                                <li><a href="{{route('auth.taxrates')}}">Tax Rates</a></li>
                            @endif
                        </ul>
                    </li>
                @endif
            </ul>
        </div>
    </div>
</div>