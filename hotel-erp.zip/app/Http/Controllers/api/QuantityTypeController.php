<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\QuantityType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class QuantityTypeController extends Controller
{
    public  function getAllQuantityTypes(Request $request)
    {
        $quantityTypes = QuantityType::where('isDeleted', 0)
            ->orderBy('id', 'DESC')
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Quantity Type List',
            'data' => $quantityTypes
        ]);
    }
    public function addQuantityType(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'quantity_type' => [
                'required',
                'string',
                'max:255',
                function ($attribute, $value, $fail) {
                    if (QuantityType::where('quantity_type', $value)->where('isDeleted', 0)->exists()) {
                        $fail('This quantity type already exists.');
                    }
                }
            ]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        QuantityType::create([
            'quantity_type' => $request->quantity_type,
            'created_by' => Auth::guard('api')->id() ?? Auth::id()
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Quantity Type added successfully.'
        ]);
    }
    public function updateQuantityType(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'quantity_type' => [
                'required',
                'string',
                'max:255',
                function ($attribute, $value, $fail) use ($id) {
                    if (
                        QuantityType::where('quantity_type', $value)
                        ->where('id', '!=', $id)
                        ->where('isDeleted', 0)
                        ->exists()
                    ) {
                        $fail('This quantity type already exists.');
                    }
                }
            ]
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $quantityType = QuantityType::find($id);

        if (!$quantityType) {
            return response()->json(['status' => false, 'message' => 'Not Found'], 404);
        }

        $quantityType->update([
            'quantity_type' => $request->quantity_type
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Quantity Type updated successfully.'
        ]);
    }

    // Soft Delete
    public function deleteQuantityType($id)
    {
        $quantityType = QuantityType::find($id);

        if (!$quantityType) {
            return response()->json(['status' => false, 'message' => 'Not Found'], 404);
        }

        $quantityType->update(['isDeleted' => 1]);

        return response()->json([
            'status' => true,
            'message' => 'Quantity Type deleted successfully.'
        ]);
    }
}
