<?php $__env->startSection('title', 'Purchaes Invoice'); ?>

<?php $__env->startSection('content'); ?>

<style>
    .details td {
        vertical-align: middle !important
    }

    .product-list td {

        vertical-align: middle;

    }

    .logo_img {
        max-width: 150px;
        height: auto;
    }

    .invoice-box table {
        width: 100%;
        border-collapse: collapse;
    }

    .invoice-box table td {
        white-space: nowrap;
    }

    /* Adjust columns for mobile, keep same layout */
    @media (max-width: 767px) {
        .invoice-box {
            overflow-x: auto;
        }

        .card-sales-split {
            flex-direction: row;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
        }

        .col-lg-6.table_view {
            flex: 0 0 50%;
            max-width: 50%;
        }

        .col-lg-6.total-order {
            flex: 0 0 100%;
            max-width: 100%;
        }

        .invoice-box,
        .invoice-box table,
        .invoice-box td,
        .invoice-box h4,
        .invoice-box h5 {
            font-size: 12px;
            line-height: 1.2;
        }

        .logo_img {
            max-width: 130px;
            height: auto;
        }

        font {
            line-height: 19px !important;
        }
    }
</style>
<div class="content">
    <div class="page-header">
        <div class="page-title">
            <h4>Purchase Invoice</h4>
            <!-- <h6>View purchase Invoice</h6> -->
        </div>

        <div class="page-btn d-flex gap-2">
            <!-- ✅ Add Sale -->
            <a href="<?php echo e(route('purchase.add')); ?>" class="btn btn-added">
                <i class="fa fa-plus me-1"></i> Add Purchase
            </a>
            <?php if(!$hasPaymentStarted): ?>
            <a href="<?php echo e(url('edit-purchase/' . $invoice->id)); ?>" class="btn btn-primary">
                <i class="fa fa-edit me-1"></i> Edit
            </a>
            <?php endif; ?>

            <!-- ✅ Print Invoice -->
            <a href="<?php echo e(route('purchase.invoice.pdf', $invoice->id)); ?>" target="_blank" class="btn btn-primary">
                <i class="fa fa-print me-1"></i> Print
            </a>

            <!-- Back -->
            <a href="<?php echo e(route('purchase.lists')); ?>" class="btn" style="background: #1b2850; color: #fff;">
                Back
            </a>
        </div>
    </div>
    <div class="card">
        <div class="card-body">


            <div class="download_pdf">
                <div class="invoice-box table-height"
                    style="max-width: 1600px;width:100%;margin:15px auto;padding: 0;font-size: 14px;line-height: 24px;color: #555;">
                    <table cellpadding="0" cellspacing="0" style="width: 100%;line-height: inherit;text-align: left;">
                        <tbody id="product-details">

                            <tr class="top">
                                <td colspan="6" style="padding: 5px;vertical-align: top;">
                                    <table style="width: 100%;line-height: inherit;text-align: left;"
                                        class="product-list">
                                        <div class="row">
                                            <div class="col-6">
                                                <img src="<?php echo e(($compenyinfo?->logo) ? env('ImagePath').'storage/' . $compenyinfo->logo : env('ImagePath').'/admin/assets/img/logso.png'); ?>"
                                                    alt="logo" class="logo_img">
                                            </div>
                                            <div class="col-6 mt-4" style=" text-align: end; ">
                                                <h1>Invoice</h1>
                                                <h4 class="mt-3">#<?php echo e($invoice->invoice_number); ?></h4>
                                            </div>
                                        </div>
                                        <hr>
                                        <td colspan="6" style="padding: 5px;vertical-align: top;">
                                            <table style="width: 100%;line-height: inherit;text-align: left;"
                                                class="product-list">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding:5px; vertical-align:top; text-align:left; padding-bottom:20px">
                                                             <font style="vertical-align: inherit; margin-bottom:25px;">
                                                                <font style="vertical-align: inherit; font-size:14px; color:#7367F0; font-weight:600; line-height: 35px;">
                                                                    Vendor Info
                                                                </font>
                                                            </font><br>

                                                            <?php if(!empty($vendor->name)): ?>
                                                            <font>
                                                                <font class="vendor-name"><?php echo e($vendor->name); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($vendor->email)): ?>
                                                            <font>
                                                                <font><?php echo e($vendor->email); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($vendor->phone)): ?>
                                                            <font>
                                                                <font class="vendor-phone"><?php echo e($vendor->phone); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <font>
                                                                <strong>GST No : </strong>
                                                                <font class="gst-no"><?php echo e($vendor->gst_number ?? 'N/A'); ?></font>
                                                            </font><br>
                                                            <font>
                                                                <strong>PAN No : </strong>
                                                                <font class="pan-no"><?php echo e($vendor->pan_number ?? 'N/A'); ?></font>
                                                            </font><br>
                                                        </td>


                                                        <td style="padding:5px; vertical-align:top; text-align:left; padding-bottom:20px">
                                                            <font style="vertical-align: inherit; margin-bottom:25px;">
                                                                <font style="vertical-align: inherit; font-size:14px; color:#7367F0; font-weight:600; line-height: 35px;">
                                                                    Company Info
                                                                </font>
                                                            </font><br>

                                                            <?php if(!empty($compenyinfo?->name)): ?>
                                                            <font>
                                                                <font><?php echo e($compenyinfo->name); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($compenyinfo?->email)): ?>
                                                            <font>
                                                                <font><?php echo e($compenyinfo->email); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($compenyinfo?->phone)): ?>
                                                            <font>
                                                                <font><?php echo e($compenyinfo->phone); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($compenyinfo?->address)): ?>
                                                            <font>
                                                                <font><?php echo e($compenyinfo->address); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>

                                                            <?php if(!empty($compenyinfo?->gst_num)): ?>
                                                            <font>
                                                                <font><strong>GST No : </strong> <?php echo e($compenyinfo->gst_num); ?></font>
                                                            </font><br>
                                                            <?php endif; ?>
                                                         </td>
                                                         <td
                                                            style="padding:5px;vertical-align:top;text-align:left;padding-bottom:20px">
                                                            <font style="vertical-align: inherit;margin-bottom:25px;">
                                                                <font
                                                                    style="vertical-align: inherit;font-size:14px;color:#7367F0;font-weight:600;line-height: 35px;">
                                                                    Invoice Info</font>
                                                            </font><br>
                                                            <font>
                                                                <font>Invoice Number</font>
                                                            </font><br>
                                                            <font>
                                                                <font>Purchase Date</font>
                                                            </font><br>
                                                            <font>
                                                                <font>Payment Status</font>
                                                            </font><br>
                                                            <font>
                                                                <font>Order Status</font>
                                                            </font><br>
                                                        </td>

                                                        <td
                                                            style="padding:5px;vertical-align:top;text-align:right;padding-bottom:20px">
                                                            <font style="vertical-align: inherit;margin-bottom:25px;">
                                                                <font
                                                                    style="vertical-align: inherit;font-size:14px;color:#7367F0;font-weight:600;line-height: 35px;">
                                                                    &nbsp;</font>
                                                            </font><br>
                                                            <font>
                                                                <font class="invoice-id"><?php echo e($invoice->invoice_number); ?>

                                                                </font>
                                                            </font><br>
                                                            <font>
                                                                <font class="invoice-id"><?php echo e($invoice->created_at); ?>

                                                                </font>
                                                            </font><br>
                                                            <font>
                                                                <font class="payment-status">
                                                                    <?php echo e($invoice->paid ? 'Paid' : 'Unpaid'); ?>

                                                                </font>
                                                            </font><br>
                                                            <font>
                                                                <font class="order-status">
                                                                    <?php echo e(ucfirst($invoice->status)); ?>

                                                                </font>
                                                            </font><br>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </table>
                                </td>
                            </tr>

                            <tr class="heading" style="background: #F3F2F7;">
                                <td style="padding: 10px;">Product Name</td>
                                <td style="padding: 10px;">QTY</td>
                                <td style="padding: 10px;">QTY Type</td>
                                <td style="padding: 10px;">Price</td>
                                <!-- <td style="padding: 10px;">Discount</td> -->
                                <!-- <td style="padding: 10px;">TAX</td> -->
                                <td style="padding: 10px;">Subtotal</td>
                            </tr>

                            <?php $__currentLoopData = $invoice->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="details" style="border-bottom:1px solid #E9ECEF;">
                                <td style="padding: 10px; vertical-align: top;">
                                    <a href="<?php echo e(url('/product-view/' . $product['product_id'])); ?>"
                                        style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                                        <img src="<?php echo e($product['product_image']); ?>" alt="img" class="me-2"
                                            style="width:40px; height:40px; object-fit: cover; border-radius: 4px;">
                                        <?php echo e($product['product_name']); ?>

                                    </a>
                                </td>

                                <td><?php echo e($product['quantity']); ?></td>
                                <td><?php echo e($product['quantity_type']); ?></td>

                                <td>
                                    <?php if($currencyPosition === 'right'): ?>
                                    <?php echo e(number_format($product['price'], 2)); ?><?php echo e($currencySymbol); ?>

                                    <?php else: ?>
                                    <?php echo e($currencySymbol); ?><?php echo e(number_format($product['price'], 2)); ?>

                                    <?php endif; ?>
                                </td>

                                <!-- <td>
                                            <?php if($currencyPosition === 'right'): ?>
                                            0.00<?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                            <?php echo e($currencySymbol); ?>0.00
                                            <?php endif; ?>
                                        </td> -->

                                <!-- <td>
                                            <?php
                                            $taxAmount = 0;
                                            foreach ($invoice->taxes as $tax) {
                                            $taxAmount += $tax['amount'];
                                            }
                                            ?>
                                            <?php if($currencyPosition === 'right'): ?>
                                            <?php echo e(number_format($taxAmount, 2)); ?><?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                            <?php echo e($currencySymbol); ?><?php echo e(number_format($taxAmount, 2)); ?>

                                            <?php endif; ?>
                                        </td> -->

                                <td style="padding: 10px;">
                                    <?php if($currencyPosition === 'right'): ?>
                                    <?php echo e(number_format($product['total'], 2)); ?><?php echo e($currencySymbol); ?>

                                    <?php else: ?>
                                    <?php echo e($currencySymbol); ?><?php echo e(number_format($product['total'], 2)); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="row">
                    <div class="col-lg-6"></div>
                    <div class="col-lg-6">
                        <div class="total-order w-100 max-widthauto m-auto mb-4">
                            <ul>
                                <li>
                                    <h4>Subtotal</h4>
                                    <h5>
                                        <?php if($currencyPosition === 'right'): ?>
                                        <?php echo e(number_format($invoice->total_amount, 2)); ?><?php echo e($currencySymbol); ?>

                                        <?php else: ?>
                                        <?php echo e($currencySymbol); ?><?php echo e(number_format($invoice->total_amount, 2)); ?>

                                        <?php endif; ?>
                                    </h5>
                                </li>
                                <!-- <li>
                                        <h4>Discount</h4>
                                        <h5>
                                            <?php if($currencyPosition === 'right'): ?>
                                            <?php echo e(number_format($invoice->discount, 2)); ?><?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                            <?php echo e($currencySymbol); ?><?php echo e(number_format($invoice->discount, 2)); ?>

                                            <?php endif; ?>
                                        </h5>
                                    </li>
                                    <li>
                                        <h4>After Discount</h4>
                                        <h5>
                                            <?php $afterDiscount = $invoice->total_amount - $invoice->discount; ?>
                                            <?php if($currencyPosition === 'right'): ?>
                                            <?php echo e(number_format($afterDiscount, 2)); ?><?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                            <?php echo e($currencySymbol); ?><?php echo e(number_format($afterDiscount, 2)); ?>

                                            <?php endif; ?>
                                        </h5>
                                    </li> -->
                                <?php $__currentLoopData = $invoice->taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <h4><?php echo e($tax['name'] ?? 'Tax'); ?> (<?php echo e($tax['rate'] ?? '0'); ?>%)</h4>
                                    <h5>
                                        <?php $taxAmount = $tax['amount'] ?? 0; ?>
                                        <?php if($currencyPosition === 'right'): ?>
                                        <?php echo e(number_format($taxAmount, 2)); ?><?php echo e($currencySymbol); ?>

                                        <?php else: ?>
                                        <?php echo e($currencySymbol); ?><?php echo e(number_format($taxAmount, 2)); ?>

                                        <?php endif; ?>
                                    </h5>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <h4>Shipping</h4>
                                    <h5>
                                        <?php if($currencyPosition === 'right'): ?>
                                        <?php echo e(number_format($invoice->shipping, 2)); ?><?php echo e($currencySymbol); ?>

                                        <?php else: ?>
                                        <?php echo e($currencySymbol); ?><?php echo e(number_format($invoice->shipping, 2)); ?>

                                        <?php endif; ?>
                                    </h5>
                                </li>
                                <li class="total">
                                    <h4>Total</h4>
                                    <h5>
                                        <?php if($currencyPosition === 'right'): ?>
                                        <?php echo e(number_format($invoice->grand_total, 2)); ?><?php echo e($currencySymbol); ?>

                                        <?php else: ?>
                                        <?php echo e($currencySymbol); ?><?php echo e(number_format($invoice->grand_total, 2)); ?>

                                        <?php endif; ?>
                                    </h5>
                                </li>
                                <li style="border-top:1px dashed #ddd; padding-top:10px;">
                                        <h4 style="color:#2E7D32;">Paid Amount</h4>
                                        <h5 style="color:#2E7D32;font-weight:600;">
                                            <?php if($currencyPosition === 'right'): ?>
                                                <?php echo e(number_format($paidAmount, 2)); ?><?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                                <?php echo e($currencySymbol); ?><?php echo e(number_format($paidAmount, 2)); ?>

                                            <?php endif; ?>
                                        </h5>
                                    </li>

                                    <li>
                                        <h4 style="color:#C62828;">Pending Amount</h4>
                                        <h5 style="color:#C62828;font-weight:600;">
                                            <?php if($currencyPosition === 'right'): ?>
                                                <?php echo e(number_format($pendingAmount, 2)); ?><?php echo e($currencySymbol); ?>

                                            <?php else: ?>
                                                <?php echo e($currencySymbol); ?><?php echo e(number_format($pendingAmount, 2)); ?>

                                            <?php endif; ?>
                                        </h5>
                                    </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div style="text-align: center; margin-top: 100px;">
                    <h2 style="color: #7367F0; font-size: 24px; margin-bottom: 10px;">Thank You for Your Business!</h2>
                    <p style="font-size: 16px; color: #555;">We appreciate your business and hope to serve you again
                        soon.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    function downloadPDF() {
        const element = document.querySelector('.download_pdf');
        const opt = {
            margin: 10,
            filename: '<?php echo e($invoice->invoice_number); ?>',
            image: {
                type: 'jpeg',
                quality: 0.98
            },
            html2canvas: {
                scale: 2
            },
            jsPDF: {
                unit: 'mm',
                format: 'a4',
                orientation: 'portrait'
            }
        };
        html2pdf().set(opt).from(element).save();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-erp\resources\views/purchase/purchase_invoice.blade.php ENDPATH**/ ?>