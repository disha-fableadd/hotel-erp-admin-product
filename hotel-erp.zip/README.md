# Hotel ERP

Hotel ERP is a Laravel-based management system for sales, purchase, inventory, invoices, staff, attendance, salary, and accounting reports.

## 🚀 Features

- Sales and purchase management
- Inventory and stock tracking
- Invoice generation and billing workflows
- Staff management, attendance, and salary handling
- Accounting and reporting modules
- Role-based access control for different user types

## 🛠️ Technology Stack

- Backend: Laravel 10 (PHP 8.1+)
- Frontend tooling: Vite 5, Axios
- Database: MySQL / MariaDB
- PDF generation: `barryvdh/laravel-dompdf`
- Excel/Spreadsheet export: `phpoffice/phpspreadsheet`
- Barcode support: `milon/barcode`
- Roles and permissions: `spatie/laravel-permission`
- API Authentication packages: `laravel/sanctum`, `laravel/passport`

## 📦 Installation

### Requirements

- PHP 8.1+
- Composer
- MySQL / MariaDB
- Node.js and npm (required if you build frontend assets)

### Setup Steps

1. Install PHP dependencies:
```bash
composer install
```

2. Copy environment file:
```bash
cp .env.example .env
```
Then update `.env` with your database credentials.

3. Generate app key:
```bash
php artisan key:generate
```

4. Run migrations:
```bash
php artisan migrate
```

5. Seed roles and admin user:
```bash
php artisan db:seed
```
This seeds:
- Roles: `admin`, `sub-admin`, `staff`, `customer`, `vendor`
- Admin user with assigned admin role

6. (Optional) Install frontend dependencies and build assets:
```bash
npm install
npm run build
```

7. Start application:
```bash
php artisan serve
```

## 🔐 Authentication (Important)

This project uses multiple authentication-related layers:

- Session-based login for the web application
- Role-based authorization with `spatie/laravel-permission`
- API token/auth support via `laravel/sanctum` and `laravel/passport` packages

### Default Seeded Credentials

- Email: `admin@gmail.com`
- Password: `12345678`

### Seeded Roles

- `admin`
- `sub-admin`
- `staff`
- `customer`
- `vendor`

### Notes

- Change the default admin password immediately after first login.
- If Passport-based API authentication is needed, run:
```bash
php artisan passport:install
```
- Ensure authentication guards/providers are configured correctly in `config/auth.php` based on your usage (web/API).

## Useful Commands

- Run only admin seeder:
```bash
php artisan db:seed --class=AdminUserSeeder
```

- Run only roles seeder:
```bash
php artisan db:seed --class=RolesSeeder
```

- Fresh migration + seed:
```bash
php artisan migrate:fresh --seed
```
