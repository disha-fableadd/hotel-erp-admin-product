@php
$settings = App\Models\Setting::first();
$admin = App\Models\User::where('role', 'admin')->first();
@endphp
<style>
    .select2-container--default .select2-selection--single .select2-selection__clear{
        display: none;
    }
    .web_button {
        width: 25px;
        height: 24px;
        cursor: pointer;
        display: flex;
        align-items: center;
    }

    .bar-icon span {
        display: block;
        height: 3px;
        width: 100%;
        background-color: #333;
        margin: 3px 0;
        transition: all 0.3s ease;
    }

    .search-view {
        width: 465px;
    }

    @media (max-width: 991px) {
        .web_button {
            display: none;
        }
    }

    /* Tablet and iPad Pro specific fixes */
    @media (min-width: 768px) and (max-width: 1024px) {
        .web_button {
            display: flex !important;
            z-index: 1000;
            position: relative;
        }





        /* Ensure toggle button is clickable on tablets */
        #toggle_btn1 {
            pointer-events: auto !important;
            cursor: pointer !important;
        }
    }

    /* iPad Pro specific (1024px) */
    @media screen and (width: 1024px) {
        .web_button {
            display: flex !important;
        }

        .mobile_btn {
            display: none !important;
        }
    }

    @media (max-width: 983px) and (min-width: 575px) {
        .logo-view {
            float: left;
            margin-left: 3rem;
        }

        .search-view {
            width: 366px;
        }
    }

    div#subBranchContainer {
        width: 200px !important;
    }
</style>
@php
$user = auth()->user();
@endphp

<div class="header">

    <div class="header-left active">
        <a href="{{ route('auth.dashboard') }}" class="logo">
            <img src="{{ !empty($settings) && !empty($settings->logo) ? env('ImagePath').'/storage/' . $settings->logo : 'https://fableadtechnolabs.com/static/media/250x150%20(1).b3f5a4db48c7770366ef.webp' }}"
                alt="" style="max-width: 80% !important;" class="logo-view">
        </a>
        <a href="{{ route('auth.dashboard') }}" class="logo-small">
            <img src="{{ !empty($settings) && !empty($settings->favicon) ? env('ImagePath').'/storage/' . $settings->favicon : 'https://fableadtechnolabs.com/favicon-192x192.webp' }}"
                alt="">
        </a>

        <!-- <a id="toggle_btn" href="javascript:void(0);">
        </a> -->
        <div id="toggle_btn1" class="web_button">
            <span class="bar-icon">
                <span></span>
                <span></span>
                <span></span>
            </span>
        </div>
    </div>

    <a id="mobile_btn" class="mobile_btn" href="#sidebar">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>

    <ul class="nav user-menu">
        <div class="d-flex align-items-center header-search-container">
            @if(in_array($user->role, ['admin']))
            <div class="me-3" id="subBranchContainer" style="display: none;">
                <div class="d-flex align-items-center">
                    <select id="subBrandSelect" class="form-select form-select-sm" style="width: 300px;">

                    </select>
                    <div id="currentSelection" class="ms-2 text-muted d-none" style="font-size: 12px;"></div>
                </div>
            </div>
            @endif
            <!-- Search Field Container -->
            <div class="header-search d-flex align-items-center position-relative me-3 search-view">
                <!-- Search Icon -->
                <img src="{{ env('ImagePath').'/admin/assets/img/icons/search.svg' }}" alt="Search"
                    style="position: absolute; left: 12px; width: 18px; height: 18px; z-index: 10; opacity: 0.6;">

                <!-- Input Field -->
                <input type="text" id="customerSearch" class="form-control form-control-sm rounded px-3 ps-5"
                    placeholder="Search..." autocomplete="off" style="height: 38px; font-size: 14px;">

                <!-- Search Results -->
                <div id="searchResults" class="list-group bg-white position-absolute rounded shadow mt-1 w-100"
                    style="z-index: 1050; max-height: 300px; overflow-y: auto; display: none; top: 100%; left: 0;">
                </div>
            </div>

            <!-- New Order Button -->
            @if(in_array($user->role, ['sales-manager', 'inventory-manager', 'admin']))
            <a href="/add-sales" class="btn btn-sm d-flex align-items-center justify-content-center me-3 header-new-order-button"
                style="height: 38px; background-color: #ff9f43; color: white;">
                + New Order
            </a>
            @endif
        </div>



        <li class="nav-item dropdown has-arrow main-drop">
            <a href="javascript:void(0);" class="dropdown-toggle nav-link userset" data-bs-toggle="dropdown">
                <span class="user-img"><img
                        src="{{ !empty($admin) && !empty($admin->profile_image) ? env('ImagePath').'/storage/' . $admin->profile_image : env('ImagePath').'/admin/assets/img/customer/customer5.jpg' }}"
                        alt="">
                    <span class="status online"></span></span>
            </a>
            <div class="dropdown-menu menu-drop-user">
                <div class="profilename">
                    <div class="profileset">
                        <span class="user-img">
                            <img src="{{ !empty($user->profile_image) ? env('ImagePath').'/storage/' . $user->profile_image : env('ImagePath').'/admin/assets/img/customer/customer5.jpg' }}" alt="">
                        </span>
                        <span class="status online"></span>
                        <div class="profilesets">
                            <h6>{{ $user->name ?? 'User' }}</h6>
                            <h5>{{ ucfirst($user->role ?? 'user') }}</h5>
                        </div>
                    </div>
                    <hr class="m-0">
                    <a class="dropdown-item" href="{{ route('auth.profile') }}">
                        <i class="me-2" data-feather="user"></i> My Profile
                    </a>
                    @if($user->role === 'admin')
                    <a class="dropdown-item" href="{{ route('setting.generalsettings') }}">
                        <i class="me-2" data-feather="settings"></i> Settings
                    </a>
                    <a class="dropdown-item new_branch" href="{{route('subbranch.list')}}"><i class="me-2"
                            data-feather="layers"></i>My Branch</a>

                    @endif
                    <hr class="m-0">
                    <a class="dropdown-item logout pb-0" href="{{ route('logout') }}">
                        <img src="{{ env('ImagePath').'/admin/assets/img/icons/log-out.svg' }}" class="me-2" alt="img"> Logout
                    </a>
                </div>

            </div>
        </li>
    </ul>


    <div class="dropdown mobile-user-menu">
        <a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
            aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="{{route('auth.profile')}}">My Profile</a>
            @if($user->role === 'admin')
            <a class="dropdown-item" href="{{route('setting.generalsettings')}}">Settings</a>
            <a class="dropdown-item new_branch" href="{{route('subbranch.list')}}">My Branch</a>
            @endif
            <a class="dropdown-item" href="{{ route('logout') }}">Logout</a>
        </div>
    </div>

</div>
@push('js')
<script>
    const currentUserRole = "{{ auth()->user()->role }}";
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('customerSearch');
        const resultBox = document.getElementById('searchResults');


        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('customerSearch');
            const resultBox = document.getElementById('searchResults');

            searchInput.addEventListener('input', function() {
                const query = this.value.trim();

                if (query.length < 1) {
                    resultBox.style.display = 'none';
                    return;
                }

                fetch(`/search-users?query=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
                        resultBox.innerHTML = '';
                        let hasResults = false;

                        // Users section
                        if (data.users?.length > 0) {
                            hasResults = true;
                            resultBox.innerHTML += `<div class="list-group-item fw-bold">Users</div>`;
                            data.users.forEach(user => {
                                const profileUrl = user.role === 'customer' ? `/customer-view/${user.id}` : `/vendor-view/${user.id}`;
                                resultBox.innerHTML += `
                                    <a href="${profileUrl}" class="list-group-item d-flex align-items-center">
                                        <img src="${user.profile_image}" alt="User Image" class="rounded-circle me-2" style="width:30px; height:30px;">
                                        <div>
                                            <strong>${user.name ?? 'N/A'}</strong><br>
                                            <small>${user.email ?? 'N/A'} (${user.role})</small>
                                        </div>
                                    </a>
                                `;
                            });
                        }

                        // Products section
                        if (data.products?.length > 0) {
                            hasResults = true;
                            resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Products</div>`;
                            data.products.forEach(product => {
                                resultBox.innerHTML += `
                                    <a href="/product-view/${product.id}" class="list-group-item d-flex align-items-center">
                                        <img src="${product.image}" alt="Product Image" class="rounded me-2" style="width:30px; height:30px; object-fit: cover;">
                                        <div>
                                            <strong>${product.name ?? 'N/A'}</strong><br>
                                            <small>Price: ${product.price ?? 'N/A'}</small>
                                        </div>
                                    </a>
                                `;
                            });
                        }

                        // Orders section
                        if (data.orders?.length > 0) {
                            hasResults = true;
                            resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Orders</div>`;
                            data.orders.forEach(order => {
                                resultBox.innerHTML += `
                                    <a href="/sales-details/${order.id}" class="list-group-item d-flex flex-column">
                                        <div class="d-flex align-items-center mb-1">
                                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/cart.svg'}}" width="20" height="20" class="me-2" alt="cart">
                                            <strong>Order #: ${order.order_number ?? 'N/A'}</strong>
                                        </div>
                                        <div>
                                            <small>Customer: ${order.user_name ?? 'N/A'}</small><br>
                                            <small>Total: ${order.total_amount ?? 'N/A'}</small> | 
                                            <small>Status: ${order.payment_status ?? 'N/A'}</small>
                                        </div>
                                    </a>
                                `;
                            });
                        }

                        // Purchase Invoices section
                        if (data.purchase_invoices?.length > 0) {
                            hasResults = true;
                            resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Purchase Invoices</div>`;
                            data.purchase_invoices.forEach(invoice => {
                                resultBox.innerHTML += `
                                    <a href="/purchase-view/${invoice.id}" class="list-group-item d-flex flex-column">
                                        <div class="d-flex align-items-center mb-1">
                                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/purchase.svg'}}" width="20" height="20" class="me-2" alt="purchase">
                                            <strong>Invoice #: ${invoice.invoice_number ?? 'N/A'}</strong>
                                        </div>
                                        <div>
                                            <small>Total: ${invoice.grand_total ?? 'N/A'}</small>
                                        </div>
                                    </a>
                                `;
                            });
                        }

                        if (!hasResults) {
                            resultBox.innerHTML = '<div class="list-group-item">No results found</div>';
                        }

                        resultBox.style.display = 'block';
                    })
                    .catch(error => {
                        console.error('Search error:', error);
                        resultBox.innerHTML = '<div class="list-group-item">Error loading search results</div>';
                        resultBox.style.display = 'block';
                    });
            });

        });

        searchInput.addEventListener('input', function() {
            const query = this.value.trim();

            if (query.length < 1) {
                resultBox.style.display = 'none';
                return;
            }

            fetch(`/search-users?query=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    resultBox.innerHTML = '';
                    let hasResults = false;

                    // ✅ Customers section
                    if (['admin', 'sales-manager', 'inventory-manager'].includes(currentUserRole) && data.users?.length > 0) {
                        hasResults = true;
                        resultBox.innerHTML += `<div class="list-group-item fw-bold">Customers</div>`;
                        data.users.forEach(user => {
                            const profileUrl = `/customer-view/${user.id}`;
                            resultBox.innerHTML += `
                    <a href="${profileUrl}" class="list-group-item d-flex align-items-center">
                        <img src="${user.profile_image}" alt="User Image" class="rounded-circle me-2" style="width:30px; height:30px;">
                        <div>
                            <strong>${user.name ?? 'N/A'}</strong><br>
                            <small>${user.email ?? 'N/A'}</small>
                        </div>
                    </a>
                `;
                        });
                    }

                    // ✅ Vendors section
                    if (['admin', 'purchase-manager', 'inventory-manager'].includes(currentUserRole) && data.vendors?.length > 0) {
                        hasResults = true;
                        resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Vendors</div>`;
                        data.vendors.forEach(vendor => {
                            const vendorUrl = `/vendor-view/${vendor.id}`;
                            resultBox.innerHTML += `
                    <a href="${vendorUrl}" class="list-group-item d-flex align-items-center">
                        <img src="${vendor.profile_image}" alt="Vendor Image" class="rounded-circle me-2" style="width:30px; height:30px;">
                        <div>
                            <strong>${vendor.name ?? 'N/A'}</strong><br>
                            <small>${vendor.email ?? 'N/A'}</small>
                        </div>
                    </a>
                `;
                        });
                    }

                    // ✅ Products section
                    if (['admin', 'purchase-manager', 'inventory-manager'].includes(currentUserRole) && data.products?.length > 0) {
                        hasResults = true;
                        resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Products</div>`;
                        data.products.forEach(product => {
                            resultBox.innerHTML += `
                    <a href="/product-view/${product.id}" class="list-group-item d-flex align-items-center">
                        <img src="${product.image}" alt="Product Image" class="rounded me-2" style="width:30px; height:30px; object-fit: cover;">
                        <div>
                            <strong>${product.name ?? 'N/A'}</strong><br>
                            <small>Price: ${product.price ?? 'N/A'}</small>
                        </div>
                    </a>
                `;
                        });
                    }

                    // ✅ Orders section
                    if (['admin', 'sales-manager', 'inventory-manager'].includes(currentUserRole) && data.orders?.length > 0) {
                        hasResults = true;
                        resultBox.innerHTML += `<div class="list-group-item fw-bold mt-2">Orders</div>`;
                        data.orders.forEach(order => {
                            resultBox.innerHTML += `
                    <a href="/sales-details/${order.id}" class="list-group-item d-flex flex-column">
                        <div class="d-flex align-items-center mb-1">
                            <img src="{{ env('ImagePath') . '/admin/assets/img/icons/cart.svg'}}" width="20" height="20" class="me-2" alt="cart">
                            <strong>Order #: ${order.order_number ?? 'N/A'}</strong>
                        </div>
                        <div>
                            <small>Customer Name: ${order.user_name ?? 'N/A'}</small><br>
                            <small>Total Amount: ${order.total_amount ?? 'N/A'}</small> | 
                            <small>Status: ${order.payment_status ?? 'N/A'}</small>
                        </div>
                    </a>
                `;
                        });
                    }

                    if (!hasResults) {
                        resultBox.innerHTML = '<div class="list-group-item">No results found</div>';
                    }

                    resultBox.style.display = 'block';
                });


        });

        // Optional: Hide dropdown on outside click
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !resultBox.contains(e.target)) {
                resultBox.style.display = 'none';
            }
        });


    });

    $(document).on('mouseover', function(e) {
        e.stopPropagation();

        // Check if mini-sidebar mode is active and toggle button exists (not just visible check for tablets)
        const $toggleBtn = $('#toggle_btn1');
        const isTabletSize = $(window).width() >= 768 && $(window).width() <= 1024;
        const isButtonAvailable = $toggleBtn.length > 0 && (isTabletSize || $toggleBtn.is(':visible'));

        if ($('body').hasClass('mini-sidebar') && isButtonAvailable) {
            const isInsideSidebar = $(e.target).closest('.sidebar, .header-left').length;

            if (isInsideSidebar) {
                $('body').addClass('expand-menu');
                $('.subdrop + ul').slideDown();
            } else {
                $('body').removeClass('expand-menu');
                $('.subdrop + ul').slideUp();
            }

            return false;
        }
    });

    // Toggle button handler with tablet/iPad Pro support
    // Using only 'click' event - works on all devices including touch devices
    // Modern browsers automatically convert touch events to click events
    $(document).on('click', '#toggle_btn1', function(e) {
        e.preventDefault();
        e.stopPropagation();

        // Prevent double-firing on touch devices
        if ($(this).data('processing')) {
            return false;
        }
        $(this).data('processing', true);

        const body = $('body');
        const $btn = $(this);

        if (body.hasClass('mini-sidebar')) {
            body.removeClass('mini-sidebar');
            $btn.addClass('active');
            $('.subdrop + ul').slideDown();
            localStorage.setItem('screenModeNightTokenState', 'night');

            setTimeout(function() {
                body.removeClass('mini-sidebar');
                $('.header-left').addClass('active');
            }, 100);
        } else {
            body.addClass('mini-sidebar');
            $btn.removeClass('active');
            $('.subdrop + ul').slideUp();
            localStorage.removeItem('screenModeNightTokenState');

            setTimeout(function() {
                body.addClass('mini-sidebar');
                $('.header-left').removeClass('active');
            }, 100);
        }

        // Reset processing flag
        setTimeout(() => {
            $btn.data('processing', false);
        }, 300);

        return false;
    });

    // Ensure dropdown is visible and has Main Branch before fetching
    (function initializeBranchDropdown() {
        const container = document.getElementById('subBranchContainer');
        const select = document.getElementById('subBrandSelect');
        if (container) {
            container.style.display = 'block';
        }
        if (select) {
            // Reset and add Main Branch immediately
            select.innerHTML = "";
            const mainOption = document.createElement('option');
            mainOption.value = "";
            mainOption.textContent = 'Main Branch';
            select.appendChild(mainOption);
            // Init Select2 early (idempotent)
            if (window.$ && $.fn && $.fn.select2) {
                $('#subBrandSelect').select2({ placeholder: 'Select a branch', allowClear: true });
            }
        }
    })();

    fetch('/api/get_subadmin', {
            headers: {
                "Authorization": "Bearer " + localStorage.getItem("authToken"),
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        })
        .then(res => res.json())
        .then(response => {
            if (!response) { console.warn('No response from /api/get_subadmin'); return; }
            if (response.status === false) { console.warn('API status false', response); }

            const select = document.getElementById("subBrandSelect");
            const role = response.role;

            // Reset options to avoid duplicates
            select.innerHTML = "";

            // Always show container and add Main Branch option
            document.getElementById('subBranchContainer').style.display = 'block';
            const mainOption = document.createElement("option");
            mainOption.value = "";
            mainOption.textContent = "Main Branch";
            select.appendChild(mainOption);

            // Append options
            (response.data || []).forEach(function(item) {
                const option = document.createElement("option");
                option.value = item.id;
                option.textContent = item.name;
                select.appendChild(option);
            });

            // Initialize Select2 with placeholder
            $('#subBrandSelect').select2({
                placeholder: 'Select a branch',
                allowClear: true
            });

            // Restore saved selection
            const savedId = localStorage.getItem('selectedSubAdminId');
            if (savedId) {
                const exists = (response.data || []).some(function(item) {
                    return String(item.id) === String(savedId);
                });
                if (exists) {
                    $('#subBrandSelect').val(savedId).trigger('change.select2');
                    setTimeout(function() {
                        if (typeof loadFilteredDashboardData === 'function') {
                            loadFilteredDashboardData(savedId);
                        }
                    }, 300);
                } else {
                    $.post('/clear-subadmin-session', {
                        _token: $('meta[name="csrf-token"]').attr('content')
                    }, function() {
                        console.log('Session cleared');
                        localStorage.removeItem('selectedSubAdminId');
                    });
                }
            } else {
                // Default to Main Branch if nothing saved
                $('#subBrandSelect').val("").trigger('change.select2');
            }
        })
        .catch(function() {
            console.error('Failed to load sub-admin list');
        });


    $('#subBrandSelect').on('change', function() {
        const selectedId = $(this).val();
        const selectedText = $(this).find('option:selected').text() || '';

        // Update visible current selection text
        $('#currentSelection').text(selectedId ? ('Selected: ' + selectedText) : '');

        if (selectedId) {
            localStorage.setItem('selectedSubAdminId', selectedId);
            $.post('/set-subadmin-session', {
                _token: $('meta[name="csrf-token"]').attr('content'),
                subAdminId: selectedId
            }, function() {
                // Redirect to dashboard after session is set
                window.location.href = "{{ route('auth.dashboard') }}";
            });

    } else if (selectedText === "Main Branch") {
        $.post('/clear-subadmin-session', {
            _token: $('meta[name="csrf-token"]').attr('content')
        }, function() {
            console.log('Session cleared');
            localStorage.removeItem('selectedSubAdminId');
            window.location.href = '/dashboard';
        });
    }
    });
</script>



<style>

    @media only screen and (max-width: 767px) {
       .select2-container {
           min-width: unset !important;
       }
   }
   /* iPhone SE */
   @media screen and (max-width: 340px) {
       .select2-container {
           width: 123px !important;
       }
   }
   @media screen and (min-width: 341px) and (max-width: 374px) {
       .select2-container {
           width: 140px !important;
       }
   }
   /* iPhone XR / iPhone 11 */
   @media screen and (min-width: 375px) and (max-width: 390px) {
       .select2-container {
           width: 145px !important;
       }
   }
   /* iPhone XR / iPhone 11 */
   @media screen and (min-width: 391px) and (max-width: 420px) {
       .select2-container {
           width: 165px !important;
       }
   }

   /* iPhone XR / iPhone 11 */
   @media screen and (min-width: 430px) and (max-width: 480px) {
       .select2-container {
           width: 175px !important;
       }
   }

   @media screen and (min-width: 768px) and (max-width: 819px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 340px !important;
       }
   }
   @media screen and (min-width: 820px) and (max-width: 1023px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 368px  !important;
       }
       .header-new-order-button{
        display: none !important;
       }

       #toggle_btn1  {
        display: none !important;
       }


       .header-search{
        display: none !important;
       }
       .header-search-container{
        display: none !important;
       }
       .logo-view {
        float: none;
    }
   }

   @media screen and (width: 768px) and (height: 1024px) {
       .header-new-order-button{
        display: none !important;
       }

       .header-search{
        display: none !important;
       }
       .header-search-container{
        display: none !important;
       }
       .logo-view {
        float: none;
    }
       #toggle_btn1  {
        display: none !important;
       }
   }


   @media screen and (width: 1024px) and (height: 1366px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 151px  !important;
       }
       /* .header .header-left {
        width: 78px !important;
       } */
       /* .web_button{
        position: absolute;
        z-index: 9999;
       }


       #toggle_btn1  {
        display: none !important;
       }
       .header .mobile_btn {
        display: block !important;
       }
*/
       /* .header-search{
        display: none !important;
       }
       .header-search-container{
        display: none !important;
       } */
       .search-view {
            width: 285px !important;
        }
       .logo-view {
        float: none;
        /* display: none !important; */
    }
    /* .header-new-order-button{
        display: none !important;
       } */
       .mini-sidebar .header-left .logo-small {
        display: none !important;
       }
   }
   @media screen and (width: 540px) and (height: 720px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 225px  !important;
       }
   }
   @media screen and (width: 1024px) and (height: 600px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 155px  !important;
       }
       /* .header .header-left {
        width: 78px !important;
       } */
       .web_button{
        position: absolute;
    z-index: 9999;
       }
       .search-view {
            width: 285px !important;
        }
       .logo-view {
        float: none;
        /* display: none !important; */
    }
    .mini-sidebar .header-left .logo-small {
        display: none !important;
       }

       div#toggle_btn1 {
    position: relative !important;
}
   }
   @media screen and (width: 1280px) and (height: 800px) {
       .select2-container {
           min-width:auto !important;
       }
       .select2-container {
           width: 215px  !important;
       }
       /* .header .header-left {
        width: 78px !important;
       } */

       .web_button{
        position: absolute;
    z-index: 9999;
       }
   }
   .search-view {
            width: 285px !important;
        }
       .logo-view {
        float: none;
        /* display: none !important; */
    }
    .mini-sidebar .header-left .logo-small {
        display: none !important;
       }

       div#toggle_btn1 {
    position: relative !important;
}

       </style>

@endpush
