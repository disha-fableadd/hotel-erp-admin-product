@extends('layout.app')

@section('title', 'Branch List')

@section('content')
    <style>
        #DataTables_Table_0_info {
            float: left;
        }

        .table-scroll-top {
            display: none;
        }

        .table-scroll-top {
            overflow-x: auto;
            overflow-y: hidden;
            height: 20px;
            width: 100%;
            margin-bottom: 5px;
        }

        .table-scroll-top div {
            height: 1px;
        }

        @media screen and (max-width: 767px) {
            .table-scroll-top {
                display: block;
            }

            div#DataTables_Table_0_filter {
                margin-top: 10px !important;
            }

            .table-top {
                flex-direction: row;
                margin-bottom: 0 !important;
            }

            .table-top .wordset {
                margin-top: 0 !important;
            }

            .dataTables_length {
                margin-left: .8rem !important;
                margin-bottom: .1rem !important;
            }

            .dataTables_filter {
                text-align: left !important;
            }
        }
    </style>
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>All Branches</h4>

            </div>
            <div class="page-btn">
                <a href="{{ route('subbranch.add') }}" class="btn btn-added btn-sm">
                    <img src="{{ env('ImagePath') . 'admin/assets/img/icons/plus.svg' }}" alt="img">
                    New Branch
                </a>
            </div>

        </div>

        <div class="card">
            <div class="card-body">

                <div class="table-scroll-top">
                    <div></div>
                </div>
                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>

                                <th>Branch Name</th>
                                <th>Branch Role</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Country</th>
                                <th>City</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data will be loaded dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('js')
    <script>
        $(document).ready(function() {
            var authToken = localStorage.getItem("authToken");
            const imagePath = "{{ env('ImagePath') }}";
            fetchCustomers(); // Call function on page load

            function fetchCustomers() {
                $.ajax({
                    url: "/api/getAllSubbranch",
                    type: "GET",
                    dataType: "json",
                    beforeSend: function() {
                        $(".datanew tbody").html(
                            '<tr><td colspan="8" class="text-center">Loading...</td></tr>');
                    },
                    headers: {
                        "Authorization": "Bearer " + authToken,
                    },
                    success: function(response) {
                        if (response.status && response.data.length > 0) {
                            let customers = response.data;
                            let tableBody = "";

                            function capitalizeFirstLetter(str) {
                                if (!str) return 'N/A';
                                return str.charAt(0).toUpperCase() + str.slice(1);
                            }

                            $.each(customers, function(index, customer) {
                                tableBody += `
        <tr>
            <td class="productimgname">
                <a href="/view-subbranch/${customer.id}" style="display: flex; align-items: center; gap: 10px; text-decoration: none; color: inherit;">
                    <p class="product-img mb-0" style="margin: 0;">
                        <img src="${customer.profile_image ? imagePath + '/storage/' + customer.profile_image : imagePath + 'admin/assets/img/customer/customer5.jpg'}"
                            alt="Product"
                            style="width: 50px; height: auto;"
                        >
                    </p>
                    <p style="margin: 0;">${capitalizeFirstLetter(customer.name)}</p>
                </a>
            </td>
            <td>${capitalizeFirstLetter(customer.role) || 'N/A'}</td>
            <td>${customer.phone || 'N/A'}</td>
            <td>${customer.email || 'N/A'}</td>
            <td>${capitalizeFirstLetter(customer.user_detail?.country) || 'N/A'}</td>
            <td>${capitalizeFirstLetter(customer.user_detail?.city) || 'N/A'}</td>
            <td>
                <a class="me-3" href="/view-subbranch/${customer.id}">
                    <img src="{{ env('ImagePath') }}admin/assets/img/icons/eye.svg" alt="View">
                </a>
                <a class="me-3" href="/edit-subbranch/${customer.id}">
                    <img src="{{ env('ImagePath') }}admin/assets/img/icons/edit.svg" alt="Edit">
                </a>
                <a class="me-3 confirm-text delete-btn" href="javascript:void(0);" data-id="${customer.id}">
                    <img src="{{ env('ImagePath') }}admin/assets/img/icons/delete.svg" alt="Delete">
                </a>
            </td>
        </tr>
    `;
                            });


                            // Destroy existing DataTable if exists
                            if ($.fn.DataTable.isDataTable(".datanew")) {
                                $(".datanew").DataTable().clear().destroy();
                            }

                            // Append new rows
                            $(".datanew tbody").html(tableBody);

                            // Reinitialize DataTable
                            $(".datanew").DataTable({
                                responsive: true,
                                autoWidth: false,
                                pageLength: 10,
                                ordering: false,
                                searching: true,
                                paging: true,
                                destroy: true,
                                language: {
                                    searchPlaceholder: " ",
                                    search: "Search:",
                                    emptyTable: "No branch found.",
                                    zeroRecords: "No branch record found.",
                                },
                            }).draw();

                            // Top scrollbar sync (optional)
                            const topScroll = document.querySelector('.table-scroll-top');
                            const tableResponsive = document.querySelector('.table-responsive');
                            const tableElement = document.querySelector('.datanew');

                            if (topScroll && tableResponsive && tableElement) {
                                const topInnerDiv = topScroll.querySelector('div');
                                topInnerDiv.style.width = tableElement.scrollWidth + 'px';

                                topScroll.onscroll = () => {
                                    tableResponsive.scrollLeft = topScroll.scrollLeft;
                                };
                                tableResponsive.onscroll = () => {
                                    topScroll.scrollLeft = tableResponsive.scrollLeft;
                                };
                            }

                        } else {
                            $(".datanew tbody").html(
                                '<tr><td colspan="8" class="text-center">No branches found.</td></tr>'
                                );
                        }
                    },
                    error: function() {
                        $(".datanew tbody").html(
                            '<tr><td colspan="8" class="text-center text-danger">Error loading data.</td></tr>'
                            );
                    },
                });
            }


            // Handle Delete
            $(document).on("click", ".delete-btn", function() {
                let customerId = $(this).data("id");

                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#ff9f43", // Confirm button color (orange)
                    cancelButtonColor: "#6c757d", // Cancel button color (gray)
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: `/api/deleteSubbranch/${customerId}`,
                            type: "POST",
                            headers: {
                                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                    "content"),
                                "Authorization": "Bearer " + authToken,
                            },
                            success: function(response) {
                                Swal.fire({
                                    title: response.status ? "Deleted!" :
                                        "Notice",
                                    text: response.message,
                                    icon: response.status ? "success" : "info",
                                    confirmButtonColor: "#ff9f43",
                                    confirmButtonText: "OK"
                                });

                                if (response.status) {
                                    fetchCustomers
                                (); // refresh only if deleted successfully
                                }
                            },
                            error: function(xhr) {
                                let errorMessage = "Something went wrong.";
                                if (xhr.responseJSON && xhr.responseJSON.message) {
                                    errorMessage = xhr.responseJSON.message;
                                }

                                Swal.fire({
                                    title: "Error!",
                                    text: errorMessage,
                                    icon: "error",
                                    confirmButtonColor: "#ff9f43",
                                    confirmButtonText: "OK"
                                });
                            },
                        });
                    }
                });
            });


        });
    </script>
@endpush
