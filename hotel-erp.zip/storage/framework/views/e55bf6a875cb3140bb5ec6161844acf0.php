<?php $__env->startSection('title', 'Account Ledger'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Account Ledger</h4>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <!-- View PDF & Excel buttons -->
                <div class="d-flex justify-content-end mb-3">
                    <button type="button" class="btn btn-sm me-2 text-white btn-danger" id="viewPdfBtn">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </button>
                    <button type="button" class="btn btn-sm text-white btn-success" id="viewCsvBtn">
                        <i class="fas fa-file-csv"></i> Export Excel
                    </button>
                </div>
                <form id="appointmentForm">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6 col-6">
                            <div class="form-group">
                                <label>Type</label>
                                <select name="type" id="type" class="form-control">
                                    <option value="">Select Type</option>
                                    <option value="customer">Customer</option>
                                    <option value="vendor">Vendor</option>
                                </select>
                            </div>
                        </div>

                        <!-- Customer Dropdown -->
                        <div class="col-lg-3 col-sm-6 col-6" id="customerDropdown" style="display: none;">
                            <div class="form-group">
                                <label>Customer Name</label>
                                <select name="customer_id" id="customer_id" class="form-control select2 Name">
                                    <option value="">Select Customer</option>
                                    <option value="all">All Customers</option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->id ?? 'null'); ?>">
                                            <?php echo e($customer->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger error-customer_id"></span>
                            </div>
                        </div>

                        <!-- Vendor Dropdown -->
                        <div class="col-lg-3 col-sm-6 col-6" id="vendorDropdown" style="display: none;">
                            <div class="form-group">
                                <label>Vendor Name</label>
                                <select name="vendor_id" id="vendor_id" class="form-control select2 Name">
                                    <option value="">Select Vendor</option>
                                    <option value="all">All Vendors</option>
                                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($vendor->id ?? 'null'); ?>">
                                            <?php echo e($vendor->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger error-vendor_id"></span>
                            </div>
                        </div>

                        <div class="col-lg-3 col-sm-6 col-6">
                            <div class="form-group">
                                <label>Month</label>
                                <select name="month" id="month" class="form-control select2 Name">
                                    <option value="">Select Month</option>
                                    <option value="all">All Months</option> 
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <option value="<?php echo e($i); ?>">
                                            <?php echo e(date('F', mktime(0, 0, 0, $i, 1))); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                                <span class="text-danger error-month"></span>
                            </div>
                        </div>

                        <div class="col-lg-3 col-sm-6 col-6">
                            <div class="form-group">
                                <label>Year</label>
                                <select name="year" id="year" class="form-control select2 Name">
                                    <option value="">Select Year</option>
                                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($year); ?>" <?php echo e($year == now()->year ? 'selected' : ''); ?>>
                                            <?php echo e($year); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger error-year"></span>
                            </div>
                        </div>
                        
                    </div>
                </form>
                <div id="paymentDetails">
                    <!-- Payment details will be displayed here -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const typeSelect = document.getElementById("type");
            const customerDropdown = document.getElementById("customerDropdown");
            const vendorDropdown = document.getElementById("vendorDropdown");

            typeSelect.addEventListener("change", function() {
                if (this.value === "customer") {
                    customerDropdown.style.display = "block";
                    vendorDropdown.style.display = "none";
                } else if (this.value === "vendor") {
                    vendorDropdown.style.display = "block";
                    customerDropdown.style.display = "none";
                } else {
                    customerDropdown.style.display = "none";
                    vendorDropdown.style.display = "none";
                }
            });

        });
        $(document).ready(function() {
            // localStorage.getItem('selectedSubAdminId');
            console.log(localStorage.getItem("selectedSubAdminId"));


            $('.Name').select2({
                placeholder: 'Select an option',
                width: '100%'
            });

            // Trigger fetch when any filter is changed
            $('#customer_id, #vendor_id, #month, #year').on('change', fetchPayments);
            let debounceTimer;

            // $('#vehicle_number').on('input', function() {
            //     clearTimeout(debounceTimer);
            //     debounceTimer = setTimeout(fetchPayments, 500); // Debounce typing
            // });

            $('#customer_id, #vendor_id').on('change', function() {
                const selectedOption = $(this).find(':selected');
                const subbranchId = selectedOption.data('subbranch-id');

                if (subbranchId) {
                    console.log("Selected Sub Branch ID:", subbranchId);

                    // Optional: store it in localStorage for API calls
                    localStorage.setItem("selectedSubBranchId", subbranchId);
                } else {
                    console.log("No subbranch ID found.");
                    localStorage.removeItem("selectedSubBranchId");
                }
            });

            function fetchPayments() {
                var authToken = localStorage.getItem("authToken");
                var type = $('#type').val(); // customer | vendor
                var selectedId = type === 'customer' ? $('#customer_id').val() : $('#vendor_id').val();
                var month = $('#month').val();
                var year = $('#year').val();
                var selectedId = type === 'customer' ? $('#customer_id').val() : $('#vendor_id').val();
                if (!selectedId) {
                    $('#paymentDetails').html('<div class="text-danger">Please select an option.</div>');
                    return;
                }

                $.ajax({
                    url: '/api/get-payment-details',
                    type: 'GET',
                    headers: {
                        "Authorization": "Bearer " + authToken
                    },
                    data: {
                        type: type, // send this!
                        customer_id: type === 'customer' ? $('#customer_id').val() : null,
                        vendor_id: type === 'vendor' ? $('#vendor_id').val() : null,
                        month: month,
                        year: year,
                        // vehicle_number: vehicleNumber,
                        selectedSubAdminId: localStorage.getItem("selectedSubAdminId")
                    },
                    success: function(response) {
                        displayPaymentDetails(response);
                    },
                    error: function(xhr) {
                        $('#paymentDetails').html(
                            '<div class="text-danger">Failed to fetch payment details.</div>');
                    }
                });
            }

            function displayPaymentDetails(data) {
                const currency = data.settings.currency_symbol || '₹';
                const currencyPosition = data.settings.currency_position || 'left';

                function formatCurrency(amount) {
                    return currencyPosition === 'left' ? `${currency}${amount}` : `${amount}${currency}`;
                }

                function formatDate(dateString) {
                    if (!dateString) return '-';
                    const date = new Date(dateString);
                    return date.toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    }) + ' ' + date.toLocaleTimeString('en-GB', {
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }

                function capitalize(str) {
                    if (!str) return '-';
                    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
                }

                // ✅ Common product name extractor
                function getProductNames(order) {
                    if (order.items && order.items.length > 0) {
                        return order.items.map(i => i.product?.name || '-').join(', ');
                    } else if (order.products_with_names && order.products_with_names.length > 0) {
                        return order.products_with_names.map(p => p.product_name || '-').join(', ');
                    }
                    return '-';
                }

                let html = '';

                // === Paid Payments ===
                html += `
    <div class="card shadow mb-4">
        <div class="card-header text-dark">
            <h5 class="mb-0 fw-bold">Paid Payments</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-striped mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th>Invoice No.</th>
                            <th>Product(s)</th>
                            <th>Total Amount</th>
                            <th>Paid Amount</th>
                            <th>Payment Date</th>
                            <th>Payment Method</th>
                        </tr>
                    </thead>
                    <tbody>`;
                let totalPaid = 0;
                if (data.paidPayments.length > 0) {
                    data.paidPayments.forEach(function(payment) {
                        const order = payment.order || payment;
                        const productNames = getProductNames(order);

                        html += `
            <tr>
                <td>${order.order_number || order.invoice_number || '-'}</td>
                <td>${productNames}</td>
                <td>${formatCurrency(order.total_amount || order.grand_total || 0)}</td>
                <td>${formatCurrency(payment.total_amount || order.amount_total || 0)}</td>
                <td>${(payment.payment_date || order.created_at)}</td>
                <td>${capitalize(payment.payment_method || order.payment_status || '-')}</td>
            </tr>`;
                        totalPaid += parseFloat(payment.total_amount || order.amount_total || 0);
                    });
                } else {
                    html += `<tr><td colspan="6" class="text-center text-muted">No record available</td></tr>`;
                }
                html += `
    </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-end pe-3 mt-2 mb-2">
        <div style="border: 1px solid #1b2850; border-radius: 5px; padding: 4px 10px; display: inline-block;">
            <span style="font-weight: bold; font-size: 15px; color: #1b2850;">
                Total Paid:
            </span>
            <span style="font-weight: bold; font-size: 15px; color: orange;">
                ${formatCurrency(totalPaid.toFixed(2))}
            </span>
        </div>
    </div>
    </div>`;

                // === Pending Payments ===
                html += `
    <div class="card shadow mb-4">
        <div class="card-header text-dark">
            <h5 class="mb-0 fw-bold">Pending Payments</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-striped mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th>Invoice No.</th>
                            <th>Product(s)</th>
                            <th>Total Amount</th>
                            <th>Remaining Amount</th>
                        </tr>
                    </thead>
                    <tbody>`;
                let totalPending = 0;
                if (data.pendingPayments.length > 0) {
                    data.pendingPayments.forEach(function(payment) {
                        const order = payment.order || payment;
                        const productNames = getProductNames(order);

                        html += `
            <tr>
                <td>${order.order_number || order.invoice_number || payment.invoice_id || '-'}</td>
                <td>${productNames}</td>
                <td>${formatCurrency(order.total_amount || order.grand_total || 0)}</td>
                <td>${formatCurrency(payment.amount_total || order.total_amount || 0)}</td>
            </tr>`;
                        totalPending += parseFloat(payment.amount_total || order.amount_total || 0);
                    });
                } else {
                    html += `<tr><td colspan="4" class="text-center text-muted">No record available</td></tr>`;
                }
                html += `
    </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-end pe-3 mt-2 mb-2">
        <div style="border: 1px solid #1b2850; border-radius: 5px; padding: 4px 10px; display: inline-block;">
            <span style="font-weight: bold; font-size: 15px; color: #1b2850;">
                Total Pending:
            </span>
            <span style="font-weight: bold; font-size: 15px; color: orange;">
                ${formatCurrency(totalPending.toFixed(2))}
            </span>
        </div>
    </div>
    </div>`;

                $('#paymentDetails').html(html);
            }



            $('#viewCsvBtn').on('click', function() {
                const type = $('#type').val();
                const customer_id = $('#customer_id').val();
                const vendor_id = $('#vendor_id').val();
                const month = $('#month').val();
                const year = $('#year').val();
                // const vehicleNumber = $('#vehicle_number').val().trim();

                if (!type) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Missing Type',
                        text: 'Please select a type before exporting.',
                    });
                    return;
                }

                if (type === 'customer') {
                    const selectedValue = $('#customer_id').val();
                    if (!selectedValue) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Missing Customer',
                            text: 'Please select a customer before exporting.',
                        });
                        return;
                    }
                    userId = selectedValue === "all" ? "all" : selectedValue.split('|')[0];
                } else if (type === 'vendor') {
                    const selectedValue = $('#vendor_id').val();
                    if (!selectedValue) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Missing Vendor',
                            text: 'Please select a vendor before exporting.',
                        });
                        return;
                    }
                    userId = selectedValue === "all" ? "all" : selectedValue.split('|')[0];
                }

                // const parts = selectedValue.split('|');
                // const userId = parts[0] !== 'null' ? parts[0] : '';
                // const customerName = parts[1] || '';

                const authToken = localStorage.getItem("authToken");
                const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");
                console.log(selectedSubAdminId);

                Swal.fire({
                    title: 'Generating Excel...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                $.ajax({
                    url: '/api/export-account-ledger',
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + authToken
                    },  
                    data: {
                        type: type,
                        customer_id: customer_id,
                        vendor_id: vendor_id,
                        month: month,
                        year: year,
                        selectedSubAdminId: selectedSubAdminId,
                    },
                    success: function(res) {
                        Swal.close(); // ✅ close the loader
                        if (res.status) {
                            const a = document.createElement('a');
                            a.href = res.file_url;
                            a.download = res.file_name;
                            document.body.appendChild(a);
                            a.click();
                            a.remove();
                        } else {
                            Swal.fire('Error', res.message, 'error');
                        }
                    },
                    error: function(err) {
                        Swal.close();
                        Swal.fire('Error', 'Failed to generate Excel file.', 'error');
                        console.error(err);
                    }
                });

            });


            $('#viewPdfBtn').on('click', function() {
                const type = $('#type').val();
                const customer_id = $('#customer_id').val();
                const vendor_id = $('#vendor_id').val();
                const month = $('#month').val();
                const year = $('#year').val();
                const authToken = localStorage.getItem("authToken");
                const selectedSubAdminId = localStorage.getItem("selectedSubAdminId");

                if (!type) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Missing Type',
                        text: 'Please select a type before exporting.'
                    });
                    return;
                }

                Swal.fire({
                    title: 'Generating PDF...',
                    allowOutsideClick: false,
                    didOpen: () => Swal.showLoading()
                });

                $.ajax({
                    url: '/api/account-ledger/download-pdf',
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer ' + authToken,
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        type: type,
                        customer_id: customer_id,
                        vendor_id: vendor_id,
                        month: month,
                        year: year,
                        selectedSubAdminId: selectedSubAdminId,
                    },
                    success: function(response) {
                        Swal.close();
                        if (response.status && response.file_url) {
                            // ✅ Create temporary link to trigger download
                            const link = document.createElement('a');
                            link.href = response.file_url;
                            link.download = response.file_name || 'account_ledger.pdf';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Download Failed',
                                text: 'File URL not found in response.'
                            });
                        }
                    },
                    error: function(xhr) {
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'Download Failed',
                            text: 'Failed to generate PDF.'
                        });
                    }
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-erp\resources\views/account_ledger/add.blade.php ENDPATH**/ ?>