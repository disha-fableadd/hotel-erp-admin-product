<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Table_no extends Model
{
    use HasFactory;

    protected $table = 'table_no';

    protected $fillable = [
        'table_name',
        'table_type',
        'table_status',
        'order_id',
    ];
}
