<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Role;

class AdminUserSeeder extends Seeder
{
    /**
     * Seed the application's admin user.
     */
    public function run(): void
    {
        if (Schema::hasTable('branches')) {
            DB::table('branches')->updateOrInsert(
                ['id' => 1],
                [
                    'name' => 'Main Branch',
                    'code' => 'BR001',
                    'status' => 'active',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
        
        if (Schema::hasTable('settings')) {
            DB::table('settings')->updateOrInsert(
                ['id' => 1],
                [
                    'name' => 'Hotel ERP',
                    'email' => 'admin@gmail.com',
                    'phone' => '1234567890',
                    'address' => 'Default Address',
                    'currency_position' => 'left',
                    'currency_symbol' => '₹',
                    'logo' => null,
                    'favicon' => null,
                    'low_stock' => 10,
                    'branch_id' => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }

        $admin = User::updateOrCreate(
            ['email' => 'admin@gmail.com'],
            [
                'name' => 'Admin',
                'password' => Hash::make('12345678'),
                'role' => 'admin',
                'status' => 1,
                'isDeleted' => 0,
            ]
        );

        $defaultCustomer = User::updateOrCreate(
            ['id' => 2],
            [
                'name' => 'Default Customer',
                'email' => 'customer@gmail.com',
                'phone' => '1234567891',
                'role' => 'customer',
                'status' => 1,
                'isDeleted' => 0,
                'branch_id' => 1,
            ]
        );

        if (Schema::hasTable('user_details')) {
            DB::table('user_details')->updateOrInsert(
                ['user_id' => 2],
                [
                    'address' => 'Default Address',
                    'city' => 'Default City',
                    'country' => 'India',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }


        if (! Schema::hasTable('roles')) {
            return;
        }

        $adminRole = Role::where('name', 'admin')->where('guard_name', 'web')->first();

        if ($adminRole && method_exists($admin, 'assignRole')) {
            $admin->syncRoles(['admin']);
        } elseif ($adminRole && Schema::hasTable('model_has_roles')) {
            DB::table('model_has_roles')->updateOrInsert(
                [
                    'role_id' => $adminRole->id,
                    'model_type' => User::class,
                    'model_id' => $admin->id,
                ],
                []
            );
        }
    }
}
