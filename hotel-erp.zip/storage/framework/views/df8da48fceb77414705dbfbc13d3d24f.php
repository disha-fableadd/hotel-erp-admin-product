<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Fablead Inventory-Billing Software">
    <meta name="keywords"
        content="inventory management, billing system, invoice generator, purchase orders, inventory control, POS system, admin dashboard">
    <meta name="author" content="Fablead Developers Technolab">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Login</title>

    <link rel="shortcut icon" type="image/x-icon" href="https://fableadtechnolabs.com/favicon-192x192.webp">

    <link rel="stylesheet" href="<?php echo e(env('ImagePath') . 'admin/assets/css/bootstrap.min.css'); ?>">

    <link rel="stylesheet" href="<?php echo e(env('ImagePath') . 'admin/assets/plugins/fontawesome/css/fontawesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo e(env('ImagePath') . 'admin/assets/plugins/fontawesome/css/all.min.css'); ?>">

    <link rel="stylesheet" href="<?php echo e(env('ImagePath') . 'admin/assets/css/style.css'); ?>">
    <style>
        .logo-img {
            margin-left: 9rem;
        }

        @media screen and (max-width: 768px) {
            .login-wrapper .login-content {
                width: 90% !important;
            }

            .logo-img {
                margin-left: 0 !important;
            }
        }
    </style>
</head>
<?php
    use App\Models\Setting;
    $settings = Setting::first();
?>

<body class="account-page">

    <div class="main-wrapper">
        <div class="account-content">
            <div class="login-wrapper">
                <div class="login-content">
                    <div class="login-userset">
                        <div class="login-logo">
                            <img src="<?php echo e($settings?->logo ? env('ImagePath') . '/storage/' . $settings->logo : 'https://fableadtechnolabs.com/static/media/250x150%20(1).b3f5a4db48c7770366ef.webp'); ?>"
                                alt="img" class="logo-img">
                        </div>
                        <div class="login-userheading">
                            <h3>Sign In</h3>
                            <h4>Please login to your account</h4>
                        </div>
                        <form id="loginForm">
                            <div class="form-login">
                                <label>Email</label>
                                <div class="form-addons">
                                    <input type="text" id="email" placeholder="Enter your email address">
                                    <img src="<?php echo e(env('ImagePath') . 'admin/assets/img/icons/mail.svg'); ?>" alt="img">
                                </div>
                                <small id="emailError" class="text-danger"></small>
                            </div>

                            <div class="form-login">
                                <label>Password</label>
                                <div class="pass-group">
                                    <input type="password" id="password" class="pass-input"
                                        placeholder="Enter your password">
                                    <span class="fas toggle-password fa-eye-slash"></span>
                                </div>
                                <small id="passwordError" class="text-danger"></small>
                            </div>

                            <div class="form-login">
                                <div class="alreadyuser">
                                    <!-- <h4><a href="forgetpassword.html" class="hover-a">Forgot Password?</a></h4> -->
                                </div>
                            </div>

                            <div class="form-login">
                                <button type="submit" class="btn btn-login">Sign In</button>
                            </div>

                            <div id="loginMessage" class="text-danger"></div>
                        </form>

                    </div>
                </div>
                <!-- <div class="login-img">
                    <img src="admin/assets/img/login.jpg" alt="img">
                </div> -->
            </div>
        </div>
    </div>
    <footer style="text-align: center; padding: 10px 0; background-color: #f4f4f4; height: 50px;">
        <h1 style="font-size: 14px; font-weight: 600;">© <?= date('Y') ?> Copyright - Fablead Developers Technolab</h1>
    </footer>

    <script src="<?php echo e(env('ImagePath') . 'admin/assets/js/jquery-3.6.0.min.js'); ?>"></script>

    <script src="<?php echo e(env('ImagePath') . 'admin/assets/js/feather.min.js'); ?>"></script>

    <script src="<?php echo e(env('ImagePath') . 'admin/assets/js/bootstrap.bundle.min.js'); ?>"></script>

    <script src="<?php echo e(env('ImagePath') . 'admin/assets/js/script.js'); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).ready(function () {
            $("#loginForm").submit(function (e) {
        e.preventDefault();

        let email = $("#email").val().trim();
        let password = $("#password").val().trim();
        $("#emailError, #passwordError, #loginMessage").text("");

        if (!email) {
            $("#emailError").text("Email is required.");
            return;
        }
        if (!password) {
            $("#passwordError").text("Password is required.");
            return;
        }

        let $submitBtn = $("#loginForm button[type='submit']");
        let originalText = $submitBtn.html();
        $submitBtn.html('<span class="spinner-border spinner-border-sm"></span> Logging in...').prop("disabled", true);

        function performLogin(forceLogin = false) {
            $.ajax({
                url: "/",
                type: "POST",
                dataType: "json",
                data: {
                    email: email,
                    password: password,
                    force: forceLogin ? 1 : 0,
                    _token: $('meta[name="csrf-token"]').attr('content'),
                },
                success: function (response) {
                    console.log("Response:", response);

                    // ⚠️ Show warning popup if already checked in/out
                    if (response.warning && response.status === true && !forceLogin) {
                        Swal.fire({
                            title: "Warning",
                            text: response.message,
                            icon: "warning",
                            showCancelButton: true,
                            confirmButtonText: "Yes, log me in",
                            cancelButtonText: "Cancel"
                        }).then((result) => {
                            if (result.isConfirmed) {
                                performLogin(true);
                            }
                        });
                        return;
                    }

                    // ✅ Successful login
                    if (response.status && response.token) {
                        localStorage.setItem("authToken", response.token);
                        localStorage.setItem("selectedSubAdminId", response.user.id);
                        window.location.href = response.redirect;
                    } else if (response.error) {
                        $("#loginMessage").text(response.error).css("color", "red");
                    }
                },
                error: function (xhr) {
                    console.error("Error:", xhr.responseText);
                    let msg = xhr.responseJSON?.message || xhr.responseJSON?.error || "Login failed.";
                    $("#loginMessage").text(msg).css("color", "red");
                },
                complete: function () {
                    $submitBtn.html(originalText).prop("disabled", false);
                }
            });
        }

        // 🚀 Start normal login (no force)
        performLogin(false);
    });

        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\hotel-erp\resources\views/signin.blade.php ENDPATH**/ ?>